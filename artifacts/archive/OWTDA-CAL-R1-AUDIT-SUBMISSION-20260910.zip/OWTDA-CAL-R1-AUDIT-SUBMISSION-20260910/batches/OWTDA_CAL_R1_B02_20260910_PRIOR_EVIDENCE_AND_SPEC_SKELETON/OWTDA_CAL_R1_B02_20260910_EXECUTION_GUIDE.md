# B02 EXECUTION GUIDE — OW-TDA-CAL-R1 旧证据物化 + 规格骨架

> BATCH_ID：`OWTDA_CAL_R1_B02_20260910_PRIOR_EVIDENCE_AND_SPEC_SKELETON`
> 上游 commit：`b1038b4`；目标 commit：`e683e7a`
> 性质：治理/物化批次 —— 0 行科学代码、0 个 MC、0 RNG 消费。
> 说明：本批把已终止 DMB-R1 归档（只读历史）物化进本代先验目录，并把基线计划投影为
> 4 份 governance 规格骨架。B01 遗留动作（编辑部征稿详情）按用户指示暂缓。

## 1. 变更清单

### A. 旧证据物化 `external_prior_evidence/DMB_R1/`
- `PRIOR_EVIDENCE_SUMMARY.md`：由 `governance/` **git mv** 迁入（对齐计划 §2.1）；
- 归档 25 对象（自 `BPI-DMB-R1-TERMINAL-CLOSURE-20260909.zip`，zip SHA256
  `38790d48a044bde41fd21bc31c18142b19e6decd2398cf1c3f3b8640f9df933d`）：
  23 内容对象 + `SHA256SUMS.txt` + `package_manifest.json`；
- `archive_manifest.json`：物化清单（id_kind `dmb_r1_prior_evidence_archive_v1`，
  23/23 逐字节核验记录、zip 引用与哈希）。

### B. Governance 规格骨架（draft，9/23 冻结时升正式）
`PROTOCOL_v1.0.md`、`METHOD_SPEC_v1.0.md`、`SAP_v1.0.md`、`DATA_SPEC_v1.0.md`、`CHANGELOG.md`；
`PROJECT_CHARTER.md` §5 同步（旧证据位置）。

## 2. 应用路径

```powershell
cd f:/BPI/owtda-calibration
git status --porcelain=v1        # 期望空
(Get-FileHash <dir>\OWTDA_CAL_R1_B02_20260910.patch -Algorithm SHA256).Hash.ToLower()
git apply --check <dir>\OWTDA_CAL_R1_B02_20260910.patch
git apply <dir>\OWTDA_CAL_R1_B02_20260910.patch
```

## 3. 验证命令

```powershell
# 归档内部一致性（23 内容对象）
python -c "import os,hashlib; base='external_prior_evidence/DMB_R1'; sums={l.split()[1]:l.split()[0] for l in open(base+'/SHA256SUMS.txt',encoding='utf-8').read().splitlines()}; ok=sum(1 for p,h in sums.items() if hashlib.sha256(open(os.path.join(base,p),'rb').read()).hexdigest()==h); print('verified',ok,'/',len(sums)); assert ok==len(sums)"
# 物化清单自洽
python -c "import json; m=json.load(open('external_prior_evidence/DMB_R1/archive_manifest.json',encoding='utf-8')); assert m['zip_sha256']=='38790d48a044bde41fd21bc31c18142b19e6decd2398cf1c3f3b8640f9df933d'; assert m['all_content_objects_verified'] is True; print('ARCHIVE_MANIFEST=PASS')"
git status --porcelain=v1        # 期望空
```

## 4. 本地执行方操作

1. 回传 HEAD/status/stash；2. 应用 patch；3. 运行上述验证并原样回传；
4. 无其他本地动作（编辑部征稿详情暂缓，按用户指示 B01 结论）。

## 5. 验收记录（方案方）

- [ ] patch SHA256 sidecar 与重算一致（`e22fc3b1…`）；
- [ ] `git apply --check` PASS；
- [ ] 归档 SHA256SUMS 23/23 通过；
- [ ] `archive_manifest.json` 自洽（zip_sha256、verified=true）；
- [ ] 工作区 clean、stash 空；0 代码/0 MC。

## 6. 下一批预告（B03，未签发）

- 搭建 `src/owtda_cal/` 包 + canonical 工具（canonical_json、H()、HMAC seed 派生、
  file_manifest/array 字节合同）与首批单测（L0）；
- configs/schema 目录与 `config_hash` 合同雏形；
- G0 身份校验器雏形（DMB-R1 终止可验证、project_id 隔离断言）。
