# B02 VALIDATION REPORT — OW-TDA-CAL-R1 旧证据物化 + 规格骨架

> 执行环境：登记主机（Windows 11，f:/BPI/owtda-calibration）
> 日期：2026-09-10
> 结论：**PASS —— 0 缺陷，可签发 B03**

## 1. 批次状态

| 项 | 值 |
|---|---|
| 上游 HEAD | `b1038b4`（B01） |
| 本批 HEAD | `e683e7a feat(governance): B02 materialize DMB-R1 prior evidence archive + spec skeletons` |
| 本批文件 | 33 changed（+10,291 −2），工作区 clean |

## 2. 物化核验

| 项 | 值 |
|---|---|
| zip 存在 + SHA256 | True；`38790d48…df933d`（与交接文档一致） |
| 解压对象数 | 25（23 内容对象 + SHA256SUMS.txt + package_manifest.json） |
| SHA256SUMS 复核 | **23/23 PASS**（物化后二次独立复核） |
| archive_manifest.json | 生成并自洽：`all_content_objects_verified=true`、zip_sha256 匹配 |
| PRIOR_EVIDENCE_SUMMARY.md | git mv `governance/` → `external_prior_evidence/DMB_R1/`（100% rename，0 改动） |

## 3. Patch 验证

| 项 | 值 |
|---|---|
| patch 大小 | 7,595,200 bytes（ASCII，nul=0） |
| patch SHA256 | `e22fc3b15970787cdeb73eb83100230720e50e7a29abdf952a49f687a67c9077` |
| `git apply --check`（b1038b4 worktree） | **PASS** |
| sidecar 一致 | True |

## 4. 新增 Governance 规格（均标 DRAFT）

`PROTOCOL_v1.0.md`（72 行）、`METHOD_SPEC_v1.0.md`（73 行）、`SAP_v1.0.md`（78 行）、
`DATA_SPEC_v1.0.md`（85 行）、`CHANGELOG.md`（28 行）。开放项在各文件列出。

## 5. 未运行项与原因

- pytest：0 代码批次，无可执行测试（非遗漏）。
- 编辑部征稿详情：用户指示暂缓填写，维持 `COLUMN_RECORD_20260910.md` 待确认状态。

## 6. 方案方复审结论

- 旧证据按计划 §2.1 物理隔离于 `external_prior_evidence/DMB_R1/`，字节核验闭环；
- 4 份规格以基线计划为权威源投影，无自创参数；稳定标识/参数与计划逐项一致；
- 迁移、物化、清单生成均在一次性 helper 中完成并已清理（无残留临时文件）；
- 本批符合 DMB-R1 交接"R1 结果登记为 R2/本代开发先验"的治理要求。

**复审：PASS，准予闭合 B02，等待签发 B03。**
