# B11b3 EXECUTION GUIDE — OW-TDA-CAL-R1 全 analysis segments 枚举与 REAL omission 判定

> BATCH_ID：`OWTDA_CAL_R1_B11B3_20260910_FULL_SEGMENTS`
> 上游 commit：`5e13d5a`（B11b2）；目标 commit：`ad1b718` + 证据 `be2ae6e`
> 性质：**L0 实现完善 + 数据事实判定** —— 0 正式 MC、0 正式 RNG 消费。
> 计划依据：§13.2/§13.3、§24 预设分流 1。

## 1. 变更清单

| 文件 | 职责 |
|---|---|
| `src/owtda_cal/pamap2_import.py` | 新增 `SegmentResult`；`ImportResult.analysis_segments` 返回**全部** final analysis segments（按时间编号）；`final_*` 仍为最大段（向后兼容） |
| `tests/test_pamap2_import.py` | 新增 segments 枚举测试（2 段、id 升序、最大段镜像） |
| `configs/real/REAL_DISPOSITION_RC.json` | REAL omission RC（`REAL_OMITTED_BY_DATA_GATE`） |
| `configs/real/DATA_MANIFEST.json` | `timebase_diagnostics` 更新为全段枚举结果 |
| `artifacts/audit/real_task_enumeration_RC.json` | 全段枚举证据 |
| `governance/CHANGELOG.md` | 登记 Data Gate FAIL 与分流处置 |

## 2. 全段枚举结果（确认数据事实）

- 每个受试者均只有 **1 个** final analysis segment（数据无 >0.5 s gap / 无缺失分段）；
- 候选数不变：`3,1,4,3,3,3,3,3,0` → 准入 **8** 受试者、总 **23** 任务；
- **`REAL_DATA_TASK_GATE` = FAIL**（门槛 ≥8 受试者 且 ≥24 任务；差 1）；
- 因此判定为**数据事实**，非实现缺陷，且**不得**通过放宽 3000/500 阈值或准入线解决。

## 3. 处置（计划 §24 分流 1）

- `REAL_OMITTED_BY_DATA_GATE`（stage `REAL_DATA_FROZEN`，reason `TASK_GATE_MIN_TASKS_NOT_MET`）登记为 RC；
- 正式 `REAL_DISPOSITION` append-only 链事件与冻结 reason_code 枚举在 **B14 冻结批**写入；
- **合成主线不受影响**（H0/H1 按原计划继续）；
- 论文层面：真实案例章节按 §1.4 条件删除，局限中说明外部验证尚缺。

## 4. 验证结果（本批实测）

| 项 | 值 |
|---|---|
| pytest 全量 | **297 passed / 0 failed** |
| ruff | **All checks passed** |
| G0 校验器 | **5/5 PASS**（证据 `identity_check_20260910T012615Z.json`） |
| patch | 17,587 B；SHA256 `c20f8fe5ca46399f5b757c316fee6924f6a66449beed0297cd8d2773caf8aafd`；apply check PASS |

## 5. 下一批
REAL 线已定案 → 主线转入 **B13（攻击套件/并行一致性）**，随后 **B14（9/23 共同冻结）**。若你希望先做理论 T2/T3 文本或 smoke 运行，也可调整。
