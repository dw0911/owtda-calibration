# B11b3 VALIDATION REPORT — OW-TDA-CAL-R1 全 segments 枚举与 REAL omission 判定

> 执行环境：登记主机（Windows 11，f:/BPI/owtda-calibration）
> 日期：2026-09-10
> 结论：**实现 PASS（0 缺陷）；数据 Gate 判定 FAIL → 按计划 §24 记 REAL omission（合成主线继续）**

## 1. 批次状态

| 项 | 值 |
|---|---|
| 上游 HEAD | `5e13d5a`（B11b2） |
| 本批代码 commit | `ad1b718` |
| 证据 commit | `be2ae6e`（G0 5/5，sha256 `14526a25…`） |
| 工作区 | clean，stash=0 |

## 2. 质量门（实测）

| 检查 | 结果 |
|---|---|
| pytest 全量 | **297 passed / 0 failed** |
| ruff | **All checks passed** |
| validate_identity.py | **5/5 PASS** |
| patch（17,587 B） | SHA256 `c20f8fe5…`，apply check PASS，sidecar 一致 |

## 3. 实现完善
`ImportResult.analysis_segments` 现返回全部 final analysis segments（时间编号 0..k），`final_*` 保持最大段镜像；测试覆盖 2 段情形与编号/镜像一致性。全段枚举后候选数不变（各受试者仅 1 段），确认 Gate 失败与段枚举无关。

## 4. 数据事实（关键）
| 指标 | 值 | 门槛 |
|---|---|---|
| 准入受试者 | 8 | ≥8 ✅ |
| 候选任务 | **23** | **≥24 ❌** |
| subject109 | 0 候选（`NO_ELIGIBLE_TASK`） | — |

→ `REAL_DATA_TASK_GATE` = FAIL；`REAL_OMITTED_BY_DATA_GATE` RC 已登记（stage `REAL_DATA_FROZEN`，reason `TASK_GATE_MIN_TASKS_NOT_MET`）。

## 5. 合规声明
- 未下调准入线、未放宽 3000/500 阈值、未筛选受试者或任务；
- 未产生任何 prediction/truth 数据；truth 保持封闭；
- 合成主线（H0/H1）不受影响，继续按 §23 排程。

## 6. 方案方复审结论
- 实现完善符合 §13.3 的"同 grid-contiguous analysis segment 内构造"语义；
- REAL 线结论为数据事实，处置符合 §24 分流 1；
- 0 MC、0 正式 RNG 消费。

**复审：PASS，准予闭合 B11b3；主线转入 B13（攻击套件/并行一致性）→ B14（9/23 冻结）。**
