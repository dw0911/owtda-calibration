# B05 VALIDATION REPORT — OW-TDA-CAL-R1 特征管线（BPI/MOMENTS，L0）

> 执行环境：登记主机（Windows 11，f:/BPI/owtda-calibration）
> 环境版本：Python 3.12.10 / numpy 2.2.6 / scipy 1.15.3 / pytest 9.1.1 / ruff 0.16.6 / **ripser 0.6.15**
> 日期：2026-09-10
> 结论：**PASS —— 0 缺陷，可签发 B06**

## 1. 批次状态

| 项 | 值 |
|---|---|
| 上游 HEAD | `7efb85d`（B04） |
| 本批代码 commit | `1566d00` |
| 证据 commit | `e4022a0`（G0 re-check 5/5） |
| 工作区 | clean，stash=0 |
| 新增依赖 | 无（ripser 0.6.15 已在环境） |

## 2. 质量门（实测）

| 检查 | 结果 |
|---|---|
| pytest 全量 | **158 passed / 0 failed**（B05 新增 41 项） |
| ruff（src/tests/audit） | **All checks passed** |
| validate_identity.py | **5/5 PASS**，EXIT=0 |
| patch（29,967 B） | SHA256 `b1d93716…`，`git apply --check` PASS，sidecar 一致 |

## 3. 语义裁定（透明登记）

1. **ripser 无界类语义**（预检阶段实测确认）：H1 无界类 death 被 ripser 0.6.15 **封顶为点云直径**（不是 inf），H0 尾类返回 `[0,inf]`。B05 统一"只删显式 inf 行"，避免误删直径封顶类。
2. **场景坐标尺度是 compute 参数**：BPI cap（N-AR=6/N-CIRCLE=2.5/PAMAP2=6g）、MOMENTS scale（1/1/6g）随场景传入（改变特征向量/矩阵 hash），`feature_config_hash` 只绑冻结参数集（grid/sigma/weight/components）。若冻结审计要求将 cap 纳入 feature config，可后续以 amendment 调整（将产生新 hash，不破坏本批 golden）。
3. `thresh=np.inf` 等价"无数据驱动阈值"；显式 `distance_matrix=False` 消除方形矩阵启发式。

## 4. 开发中修复记录

1. `ripser` 不接受 `verbose` kwarg → 移除；不接受 `thresh=None`（Cython 需数值）→ `np.inf`；
2. BPI 网格广播轴序错误（`eu[:,:,None]*el[None,:,:]` 维度不匹配）→ 修正为 `eu[:,None,:]*el[None,:,:]`，单类 golden 复验一致；
3. 测试预期修正：N-AR 恒定窗口的延迟点云为 3-D → MOMENTS 9 维（原误写 5 维）；
4. ruff import/unused 清理。

## 5. 覆盖的攻击/边界（§19 相关）
- 行置换/重复行 → 点云规范化后 BPI 逐位一致；
- 空通道/单点/两点/共线点 → 预期结构（<2 唯一点返回零向量/均值+零协方差）；
- cap winsor（超大 birth/death 饱和 u=v=1）；
- feature matrix 数组 hash 重放与内容敏感性；config hash 对 grid_rows/σ 敏感；
- 平移 → MOMENTS 仅均值移动、协方差不变。

## 6. 未运行项与原因
- 无正式 MC / blind smoke / PH 缓存层（run 层冻结后）；
- 跨平台（Linux）PH 位一致性由环境锁 + generation 机制承接（L4 独立重建），非本批范围。

## 7. 方案方复审结论
- 特征合同按 METHOD_SPEC §4/§5 冻结参数逐项实现；稳定标识/B=999 无关特征；
- 0 MC、0 正式 RNG 消费；代码全部 L0；golden（单类 intensity、MOMENTS 手算）独立锁定。

**复审：PASS，准予闭合 B05，等待签发 B06（M0/M1 + CUSUM + 双实现）。**
