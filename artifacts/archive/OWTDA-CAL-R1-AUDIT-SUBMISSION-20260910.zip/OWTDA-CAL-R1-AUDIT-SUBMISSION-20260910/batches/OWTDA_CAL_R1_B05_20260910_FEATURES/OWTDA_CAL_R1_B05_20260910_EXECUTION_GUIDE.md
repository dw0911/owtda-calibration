# B05 EXECUTION GUIDE — OW-TDA-CAL-R1 特征管线（BPI/MOMENTS，L0）

> BATCH_ID：`OWTDA_CAL_R1_B05_20260910_FEATURES`
> 上游 commit：`7efb85d`（B04 闭合）；目标 commit：`1566d00` + 证据 `e4022a0`
> 性质：**L0 feature 管线代码** —— 0 正式 MC、0 正式 RNG 消费。
> 环境：**无需新增依赖**（ripser 0.6.15 已装并通过冒烟/兼容性探测）。
> 计划依据：§5（特征合同）、§11（feature-sufficient）、§19（攻击用例）。

## 1. 变更清单

| 模块 | 职责 |
|---|---|
| `src/owtda_cal/pointcloud.py` | 窗口→点云统一管线：拒绝 NaN/Inf → `-0.0→+0.0` → float64 lexsort + 位模式去重 → `point_limit=128`（超限=配置错误，禁随机降采样）→ 多变量直取 / N-AR 延迟嵌入路由 |
| `src/owtda_cal/ph.py` | ripser VR 封装：F2、H0+H1、maxdim=1、`thresh=inf`（无数据驱动阈值）、显式 `distance_matrix=False`；删除 `inf` death；≥2 唯一点才调用 |
| `src/owtda_cal/bpi.py` | `BPI_FIXED20_H01_SIGMA005_GAMMA1_V1` 映射：cap winsor → 20×20 网格 σ=0.05 w(v)=v → H0+H1 各 400 → `/√2` = 800 维；空通道零向量 |
| `src/owtda_cal/moments.py` | `MOMENTS_MEAN_COV_FROB_V1`：除以尺度 a → d 均值 + d 对角协方差 + `√2·S_ab` 字典序（2D→5/3D→9）；常数点云=均值+零协方差 |
| `src/owtda_cal/features.py` | feature spec/config hash、场景坐标尺度映射（N-AR BPI cap=6 / N-CIRCLE=2.5 / PAMAP2=6 g；MOMENTS scale=1/1/6 g）、`feature_matrix_for_windows`（`>f8 [M,p]`）、`feature_sufficient_stats`（a_r、q_r，§11） |
| `tests/test_{pointcloud,ph,bpi,moments,features}.py` | 41 项新测试 |

## 2. 关键契约（本批裁定并冻结）

1. **infinite-death 语义（ripser 实测）**：ripser 0.6.15 对 H1 无界类用**点云直径封顶**（非 inf），H0 尾类返回 `[0,inf]`。实现只删除显式 `inf` 行；H1 直径封顶类保留、进 winsor cap 饱和。
2. **场景坐标尺度作为 compute 参数**：cap/scale 由场景（数据族）决定，作为调用参数传入（进 feature 向量/hash），不进入 `feature_config_hash`（stable_id 唯一绑定冻结参数集）。
3. **`thresh=np.inf`** = 无数据驱动阈值（禁数据驱动 thresh 的工程等价）。
4. BPI 拼接顺序 H0 后 H1，索引 `r*20+l`（C order）。
5. feature-sufficient：`a=M⁻¹ΣY_i`（p 向量）、`q=M⁻¹Σ‖Y_i‖²`（标量，未均值中心化）。

## 3. 验证结果（本批实测）

| 项 | 值 |
|---|---|
| pytest 全量 | **158 passed / 0 failed** |
| ruff | **All checks passed** |
| G0 校验器 | **5/5 PASS**（证据 `identity_check_20260909T185601Z.json`） |
| patch SHA256 | `b1d93716fc7ea35f4d96f99ca1edc6df46db260feb763722476b0d71f423584a` |
| `git apply --check` | PASS |

## 4. 本地复验

```powershell
cd f:/BPI/owtda-calibration
git status --porcelain=v1
git apply --check ..\_incoming\OWTDA_CAL_R1_B05_20260910_FEATURES\OWTDA_CAL_R1_B05_20260910.patch
git apply ..\_incoming\OWTDA_CAL_R1_B05_20260910_FEATURES\OWTDA_CAL_R1_B05_20260910.patch
python -m pytest -q
python audit/validate_identity.py
```

## 5. 下一批预告（B06）
M0/M1 resampler + CUSUM 扫描统计量（候选/plateau/中位索引/定位）+ 两份独立实现（误差 ≤1e-12）与 p 值重放（§3.3/§3.4/§6）。
