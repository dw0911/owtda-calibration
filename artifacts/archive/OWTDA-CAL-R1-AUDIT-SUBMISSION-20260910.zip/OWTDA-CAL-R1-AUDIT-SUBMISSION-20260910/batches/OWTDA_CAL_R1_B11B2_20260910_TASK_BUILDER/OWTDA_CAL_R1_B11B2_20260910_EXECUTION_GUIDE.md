# B11b2 EXECUTION GUIDE — OW-TDA-CAL-R1 PAMAP2 task builder + Data Gate

> BATCH_ID：`OWTDA_CAL_R1_B11B2_20260910_TASK_BUILDER`
> 上游 commit：`0f3dc56`（B11b1）；目标 commit：`55582d3` + 证据 `5e13d5a`
> 性质：**L0/数据实现 + 真实枚举 dry-run** —— 0 正式 MC、0 正式 RNG 消费（仅派生上下文长度）。
> 计划依据：§13.3（task builder）、§13.2（timebase）、§24 预设分流 1。

## 1. 变更清单

| 文件 | 职责 |
|---|---|
| `src/owtda_cal/pamap2_tasks.py` | bout 定义、候选（n≥3000/zero≤500/活动不同/不跨段）、`candidate_identity`+`task_candidate_id`、上下文 L∈{20..30} **无偏 rejection mapping**、任务提取与真值（a/b/τ 区间/relative_s）、`task_signal_hash`、opaque `task_id`（HMAC+isolated salt）、sanitized 目录写入、eligibility 表与 `real_data_task_gate` |
| `tests/test_pamap2_tasks.py` | 17 项新测试 |
| `configs/real/REAL_COMMITMENTS_RC.json` | RC commitments（dataset_hash、task_builder_config_hash、root/salt commitment；明文 secrets 隔离在 repo 外） |
| `configs/real/DATA_MANIFEST.json` | 追加 `timebase_diagnostics`（九受试者逐文件诊断；dataset_hash 不变） |
| `artifacts/audit/real_task_enumeration_RC.json` | 枚举 dry-run 证据（逐受试者计数 + Gate 结果） |

## 2. 真实枚举结果（dry-run，未写 task 目录）

| subject | 101 | 102 | 103 | 104 | 105 | 106 | 107 | 108 | 109 |
|---|---|---|---|---|---|---|---|---|---|
| candidates | 3 | 1 | 4 | 3 | 3 | 3 | 3 | 3 | **0** |

- 准入受试者：**8**；总候选任务：**23**；
- **`REAL_DATA_TASK_GATE` = FAIL**（要求 ≥8 受试者且 ≥24 任务；差 1 个任务，且 subject109 无候选 → `NO_ELIGIBLE_TASK`）；
- 参数：`task_builder_config_hash=bbaaa38b…`、`task_index_generation_id=TI01`、dataset_hash 不变。

## 3. 处置（按计划 §24 预设分流 1）

当前实现只枚举**每个文件的最大 final analysis segment**。§13.3 允许在同一 grid-contiguous analysis segment 内构造任务，因此下一步应扩展 importer 返回**全部** final segments 并重新枚举（B11b3）：
- 若全段枚举后 ≥24 任务且 ≥8 受试者 → Gate PASS，继续 REAL 线；
- 若仍不足 → 最迟 9/17 记 `REAL_OMITTED_BY_DATA_GATE`（唯一允许的非准入原因已记录），**合成主线不受阻**。

**注意**：不得为凑数放宽 3000/500/准入线（计划禁止下调准入线）。

## 4. 验证结果（本批实测）

| 项 | 值 |
|---|---|
| pytest 全量 | **296 passed / 0 failed** |
| ruff | **All checks passed** |
| G0 校验器 | **5/5 PASS**（证据 `identity_check_20260910T012212Z.json`） |
| patch | 32,507 B；SHA256 `5d55c5ea208777eb0e47727c6ea09a22796807f3c32037b1cfef1fcf153b2ba7`；apply check PASS |

## 5. 下一批
**B11b3**：importer 全 segments 输出 + 全量重枚举 +（若 PASS）写 sanitized task 目录与 `TASK_INDEX_SEAL` RC；否则生成 `REAL_DISPOSITION` omission 记录。
