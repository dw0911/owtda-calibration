# B11b2 VALIDATION REPORT — OW-TDA-CAL-R1 PAMAP2 task builder + Data Gate

> 执行环境：登记主机（Windows 11，f:/BPI/owtda-calibration）
> 日期：2026-09-10
> 结论：**PASS（实现无缺陷）—— 但 `REAL_DATA_TASK_GATE` 判定 FAIL（数据事实），触发计划 §24 预设分流**

## 1. 批次状态

| 项 | 值 |
|---|---|
| 上游 HEAD | `0f3dc56`（B11b1） |
| 本批代码 commit | `55582d3` |
| 证据 commit | `5e13d5a`（G0 5/5，sha256 `f7ad3525…`） |
| 工作区 | clean，stash=0 |

## 2. 质量门（实测）

| 检查 | 结果 |
|---|---|
| pytest 全量 | **296 passed / 0 failed**（B11b2 新增 17 项） |
| ruff | **All checks passed** |
| validate_identity.py | **5/5 PASS** |
| patch（32,507 B） | SHA256 `5d55c5ea…`，apply check PASS，sidecar 一致 |

## 3. 真实数据结果（关键）

- 九受试者解析吞吐实测：subject103 252,833 行 / 6.07 s ≈ **41.6k rows/s**（全量约 1–2 分钟，预算充足）；
- 逐受试者候选：`3,1,4,3,3,3,3,3,0` → 准入 **8** 受试者、总 **23** 任务；
- **Gate FAIL**：`{min_subjects:8, min_tasks:24}`；subject109 候选 0 → `NO_ELIGIBLE_TASK`；
- 证据：`artifacts/audit/real_task_enumeration_RC.json`。

## 4. 实现无缺陷证据
- bout/候选约束（n≥3000、zero≤500、活动不同、非零 gap 拒绝、不跨段）正反例通过；
- 上下文 L∈{20..30} 无偏 rejection mapping：120 个候选 ID 全在范围内且 `L_A≠L_B`；确定性通过；
- 任务提取：T=4200、`truth_sample_left=2000`、`right=2101`、relative_s 19.995/20.995、`task_signal_hash` 重算一致；
- sanitized 目录仅 4 文件且 manifest 无 truth/subject/activity/grid 泄漏；
- `task_id` 对 salt/候选/L/signal 任一改变敏感。

## 5. 处置与建议
1. **不调准入线**（计划禁止）；2. 先做 **B11b3 全 segments 枚举**（§13.3 允许同段内构造，当前仅用最大段）；
3. 若仍 <24 → 记 `REAL_OMITTED_BY_DATA_GATE`（9/17 前），合成主线继续。

## 6. 方案方复审结论
- 实现符合 §13.3，真实枚举可复现；Gate 失败属**数据事实**而非实现缺陷；
- RC commitments 与 manifest timebase diagnostics 已就位，9/13 承诺窗口可满足；
- 0 MC、0 正式 RNG 消费。

**复审：PASS（实现），准予闭合 B11b2；等待签发 B11b3（全段枚举）。**
