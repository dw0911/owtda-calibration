# B06 EXECUTION GUIDE — OW-TDA-CAL-R1 扫描统计量 + M0/M1 校准器（L0）

> BATCH_ID：`OWTDA_CAL_R1_B06_20260910_SCAN_CALIBRATE`
> 上游 commit：`e4022a0`（B05）；目标 commit：`3ded17f` + 证据 `2f6610a`
> 性质：**L0 推断层代码** —— 0 正式 MC、0 正式 RNG 消费（仅测试 root key）。
> 计划依据：§3.3-§3.4（统计量与对齐 Gate）、§6（M0/M1）、§12.4（定位映射）。

## 1. 变更清单

| 模块 | 职责 |
|---|---|
| `src/owtda_cal/scan.py` | 候选区间 `[ceil(0.15M), M-ceil(0.15M)]`；T(k)=n_L n_R/M·‖mean diff‖²（**fast + slow 双实现**）；plateau 规则（tol=64·ε64·max(1,|T_max|) → 最长段 → 最左 → lower median）；`estimated_change_raw_time` 定位映射 |
| `src/owtda_cal/calibrate.py` | `dmb_block_length`（q0=⌊W/s⌋+1, 整数立方根）、`dmb_multiplier_series`（三角核、无 wrap/截断）、M0 permutation / M1 高斯新息逐 resample RNG 合同；`calibrate_m0/m1` → p=(1+exceed)/1000, reject⇔exceed≤49；observed statistic M0/M1 共享 |
| `tests/test_scan.py` / `test_calibrate.py` | 22 项新测试 |

## 2. 关键契约

- **observed statistic 单一来源**：M0/M1 都调 `statistic_curve`，互不改变 observed；
- **双实现 ≤1e-12**：fast（前缀和）vs slow（切片重算）逐候选一致；
- **M1 桥与均值差等价**：`U*` 平方范数/((k/M)(1-k/M)) ≡ 加权均值差公式（推导一致），实现直接复用同一 `statistic_curve` 于加权行 `ξ_i·Z_i`；
- **b 规则**：s64/s16/s8@M192 → b=6/6/9（q0 主导）；M48 s64 → 4；整数立方根无浮点；
- **RNG 合同**：M0 每 `(data_unit_id,resample_index)` 恰一次 `permutation(M)`；M1 恰一次 `standard_normal(M+b-1)`；stream_kind 允许混合大小写（Plan 表 `M0_permutation`/`M1_gaussian_innovation`）。

## 3. 验证结果（本批实测）

| 项 | 值 |
|---|---|
| pytest 全量 | **180 passed / 0 failed** |
| ruff | **All checks passed** |
| G0 校验器 | **5/5 PASS**（证据 `identity_check_20260909T190012Z.json`） |
| patch SHA256 | `6ddb246c8aec73e198a9824c60374dfd0d41d27e47b40171d42097e4f3d7b0fd` |
| `git apply --check` | PASS |

## 4. 本地复验

```powershell
cd f:/BPI/owtda-calibration
git status --porcelain=v1
git apply --check ..\_incoming\OWTDA_CAL_R1_B06_20260910_SCAN_CALIBRATE\OWTDA_CAL_R1_B06_20260910.patch
git apply ..\_incoming\OWTDA_CAL_R1_B06_20260910_SCAN_CALIBRATE\OWTDA_CAL_R1_B06_20260910.patch
python -m pytest -q
python audit/validate_identity.py
```

## 5. 下一批预告（B07）
- smoke/scope/index 身份链雏形：`SCOPE_DESIGN` 展开（H0 28 格 × 2,500）、logical/expected index schema、`run_component_set` 字段族；
- 或按排程优先 PAMAP2 数据批次（9/12-13 下载 + hash + 导入器）。可在确认时指定优先级。
