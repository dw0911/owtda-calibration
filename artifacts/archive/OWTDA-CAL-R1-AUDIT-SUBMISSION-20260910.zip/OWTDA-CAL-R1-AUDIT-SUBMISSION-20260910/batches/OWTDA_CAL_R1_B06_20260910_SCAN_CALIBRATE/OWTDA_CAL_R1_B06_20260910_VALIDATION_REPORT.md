# B06 VALIDATION REPORT — OW-TDA-CAL-R1 扫描统计量 + M0/M1 校准器（L0）

> 执行环境：登记主机（Windows 11，f:/BPI/owtda-calibration）
> 环境版本：Python 3.12.10 / numpy 2.2.6 / pytest 9.1.1 / ruff 0.16.6
> 日期：2026-09-10
> 结论：**PASS —— 0 缺陷，可签发 B07**

## 1. 批次状态

| 项 | 值 |
|---|---|
| 上游 HEAD | `e4022a0`（B05） |
| 本批代码 commit | `3ded17f` |
| 证据 commit | `2f6610a` |
| 工作区 | clean，stash=0 |

## 2. 质量门（实测）

| 检查 | 结果 |
|---|---|
| pytest 全量 | **180 passed / 0 failed**（B06 新增 22 项） |
| ruff | **All checks passed** |
| validate_identity.py | **5/5 PASS**，EXIT=0 |
| patch（22,605 B） | SHA256 `6ddb246c…`，apply check PASS，sidecar 一致 |

## 3. 关键验证点（tests 锁定）

- 候选区间：M=192 → [29,163]（135 候选）；M=48 → [8,40]；
- **fast vs slow ≤1e-12**：48×5、96×2、192×800、30×3 随机矩阵逐候选一致；
- plateau：最长段优先、并列取最左、段内 lower median；手工用例（两段 2/3、单峰、三连平台）通过；
- raw-time：`(96, s=64, W=64) → 6144.5`、`(96, s=16, W=64) → 1560.5`（§12.4 手工等式）；
- DMB：W64 s64 M192 → b=6（**与 DMB-R1 冻结 b 一致**）；s8 → 9（q0 主导）；三角核经验协方差 1−|h|/b；
- M0/M1：deterministic、p 网格 0.001、reject⇔exceed≤49、observed=M0/M1 共享；强 shift 在 M0 下 reject=True；
- RNG 流隔离：同 key 同字段重复得同排列/同新息；不同 data_unit_id 得不同排列。

## 4. 开发中修复记录

1. `stream_kind` 正则原限小写开头，与 Plan §15.2 表名（`M0_permutation`/`M1_gaussian_innovation`）冲突 → 放宽为 `[A-Za-z][A-Za-z0-9_]*`；
2. dmb b 期望：s8@M192 的 q0=9 主导（非 6）；
3. `candidate_bounds` 无效 M 用例修正（M=1 使 hi<lo 触发 raise）；ruff 未用变量清理。

## 5. 语义等价说明（§6 M1 bridge）

`||U*(k)||²/((k/M)(1-k/M))`（bridge 表达）与加权均值差公式在代数上恒等，已在实现复用同一 `statistic_curve` 于加权行 `ξ_i·Z_i`，避免双公式漂移；`Z_i=Y_i−Ȳ`（中心化）。

## 6. 未运行项与原因

- 无正式 MC / blind smoke / p 值重放运行框架（后者为 run 层 replay 工具，待 ledger 实现批）。
- B=999 性能剖面（外推预算）属 §9.4 smoke 阶段，非 L0 本批范围。

## 7. 方案方复审结论

- 统计量—理论对齐核心（§3.4 Gate 第 1/2 项）已具备可测锚点：候选端点、plateau、中位索引、raw-time 手工反例；
- M0/M1 观测统计量共享、内层随机化合同与 §6.1/§15.2 一致；
- 0 MC、0 正式 RNG 消费；代码全部 L0。

**复审：PASS，准予闭合 B06，等待签发 B07。**
