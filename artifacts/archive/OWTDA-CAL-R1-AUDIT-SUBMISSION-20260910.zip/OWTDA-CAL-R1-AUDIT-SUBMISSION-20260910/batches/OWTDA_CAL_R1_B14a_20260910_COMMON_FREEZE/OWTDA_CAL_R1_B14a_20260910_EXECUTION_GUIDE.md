# B14a EXECUTION GUIDE — OW-TDA-CAL-R1 共同冻结（规格定稿 + freeze_id + SCOPE_DESIGN + tag）

> BATCH_ID：`OWTDA_CAL_R1_B14a_20260910_COMMON_FREEZE`
> 上游 commit：`22dd3b2`（B13）；冻结点 commit：`caebaeb`
> Git tag：`v1.0-freeze-owtda-cal-r1` → `caebaeb`
> 计划依据：§16.2（freeze 链）、§15.1–§15.4（身份合同）、§23（9/23 共同冻结）
> 性质：**治理冻结批次** —— 0 正式 MC、0 正式 RNG 消费。

## 1. 冻结身份（本次共同冻结的根）

| 对象 | 值 |
|---|---|
| `project_id` | `owtda-cal-r1` |
| `protocol_id` | `OWTDA-CAL-R1-PROTOCOL-v1.0` |
| `evidence_generation_id` | `G01` |
| `protocol_content_hash` | `6c1acb3c4bfca8ca6e7ca01fa18d6ad1082477766f00e622ac0271c08f37f5b6` |
| `scope_spec_hash` | `8b9590b8db80e0ef412ba9aa0413cfa56fb73bdc997f2414189dc84ff48362e4` |
| `estimand_registry_hash` | `d696f2ce5eaa693fd7fdbae764a3f1bfbbf62fb58fb9e0a26fbf7b9d9b19f30a` |
| `analysis_spec_hash` | `1de8b74332892a6f71593f8b2be3b67b8bc094392296643b1fa84c4a395bba2f` |
| `compute_spec_hash` | `4082572e2ca96ae86e9a2d854468743b08817970d982f5e158a6e5f135cb903b` |
| **`freeze_id`** | **`7cb4f85e31394b23f6c9d6bcaa9ce6a7fc7b824b2b5c8fb6b600c9181979322d`** |
| `source_tree_hash` | `183695897e86170585c4aad9d5da3a4627cd7a2835032dba35aad992922c3181`（32 文件） |
| `environment_lock_hash` | `61f5f50a604efa379e1e67cd9b2fbe466acd6e52e73cb424a321c96f4d72b74e` |

`SCOPE_DESIGN`（由 `freeze_id` 派生，行序无关）：
- `SCOPE_DESIGN_NULL_bbecccb5….csv` — 112 行，`scope_design_hash = bbecccb5…a04b`
- `SCOPE_DESIGN_ALT_aebd4f34….csv` — 32 行，`scope_design_hash = aebd4f34…4b35`

## 2. 变更清单（20 文件，+2,169 行）

**新增规格对象**：`SCOPE_SPEC_v1.json`、`PROTOCOL_CONTENT_v1.json`、`ESTIMAND_SPEC_REGISTRY_v1.json`、
`ANALYSIS_SPEC_v1.0.json`、`COMPUTE_SPEC_v1.json`、`COMPUTE_FREEZE.json`、`FREEZE_MANIFEST.json`、
两个 `SCOPE_DESIGN_*.csv`。

**新增代码**：`src/owtda_cal/freeze.py`（spec hash 族、SCOPE_DESIGN 行/CSV/hash、manifest 构建）、
`audit/build_freeze.py`（幂等生成器）、`audit/validate_freeze.py`（22 项链校验）、`tests/test_freeze.py`（19 项）。

**治理状态**：PROTOCOL / METHOD_SPEC / SAP / DATA_SPEC / PROJECT_CHARTER 升 `FROZEN`；CHANGELOG 登记。

## 3. 冻结链（无环顺序，Plan §16.2）

```
SCOPE_SPEC_v1.json ─┐
PROTOCOL_CONTENT_v1.json ─┤
ANALYSIS_SPEC_v1.0.json ──┼─→ freeze_id ─→ SCOPE_DESIGN_<phase>_<hash>.csv
COMPUTE_SPEC_v1.json ─────┘
                            FREEZE_MANIFEST.json（只记录，不回灌）
```
- `ANALYSIS_SPEC` 绑定 `estimand_spec_registry_hash`（registry 先于 analysis spec 生成）；
- `SCOPE_SPEC` 只含科学因子（无 derived/freeze ID）；REAL 只登记 `replicate_source="TASK_INDEX_SEAL"`；
- `FREEZE_MANIFEST` 的 `freeze_id` 不出现在任何被哈希的 spec 中（校验项 `cycle_free`）。

## 4. 验证结果（本批实测）

| 项 | 值 |
|---|---|
| pytest 全量 | **362 passed / 0 failed**（B14a 新增 19） |
| ruff | **All checks passed** |
| `audit/validate_freeze.py` | **ALL_PASS=True**（22 项：5 spec hash + freeze_id + registry 绑定 + 2×3 SCOPE_DESIGN + 8 文档 + cycle + source tree + env lock + 4 状态） |
| `audit/validate_identity.py` | **5/5 PASS** |
| `audit/build_freeze.py` 幂等 | 重跑后全部 hash 与文件字节不变 |
| patch（115,088 B） | SHA256 `ca66cbad…`，apply check PASS |

## 5. 本地复验

```powershell
cd f:/BPI/owtda-calibration
git apply --check ..\_incoming\OWTDA_CAL_R1_B14a_20260910_COMMON_FREEZE\OWTDA_CAL_R1_B14a_20260910.patch
git apply ..\_incoming\OWTDA_CAL_R1_B14a_20260910_COMMON_FREEZE\OWTDA_CAL_R1_B14a_20260910.patch
python -m pytest -q
python audit/build_freeze.py      # 幂等：重跑不改任何 hash
python audit/validate_freeze.py   # 22/22 PASS
python audit/validate_identity.py
```

## 6. 下一批预告（B14b：冻结收尾）
1. `SEED_REGISTRY_v1.0.json`：entries（七元组主键、`root_key_hex` 或 `secret_ref`、`root_key_commitment`、
   `root_entry_hash`），root key 由本地生成并只提交 commitment；
2. `COMPONENT_REGISTRY_v1.json`（component_kind/stable_id/generation/config_hash/code_file_manifest_hash）；
3. `SECRET_COMMITMENT_REGISTRY_v1.0.json`（`candidate_manifest_salt` / `truth_commitment_salt`）；
4. 正式 `REAL_DISPOSITION` append-only 链：genesis + `REAL_OMITTED_BY_DATA_GATE` 事件；
5. `RUN_COMPONENT_SET` 与 G0 扩展校验（registry 主键唯一/排序/commitment 一致性）；
6. 冻结后再次刷新 `FREEZE_MANIFEST` 的 source/component binding 并复核 tag。

> 注意：B14b 及后续若改动 `src/`、`configs/`、`audit/` 下被跟踪文件，`source_tree_hash` 会变化，
> 需重跑 `build_freeze.py` 刷新 manifest（spec hashes 与 `freeze_id` 不变），并在正式 run 前以
> `RUN_COMPONENT_SET` 绑定最终 manifests。
