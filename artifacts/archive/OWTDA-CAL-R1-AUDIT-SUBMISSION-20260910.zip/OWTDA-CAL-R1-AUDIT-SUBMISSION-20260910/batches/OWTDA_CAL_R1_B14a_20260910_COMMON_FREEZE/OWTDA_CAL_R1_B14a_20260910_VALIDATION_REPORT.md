# B14a VALIDATION REPORT — OW-TDA-CAL-R1 共同冻结（规格定稿 + freeze_id + SCOPE_DESIGN + tag）

> 执行环境：登记主机（Windows 11，`f:/BPI/owtda-calibration`）
> 环境：Python 3.12.10 / numpy 2.2.6 / scipy 1.15.3 / ripser 0.6.15 / pytest 9.1.1 / ruff
> 日期：2026-09-10
> 结论：**PASS —— 0 缺陷，共同冻结达成，可签发 B14b（冻结收尾）**

## 1. 批次状态

| 项 | 值 |
|---|---|
| 上游 HEAD | `22dd3b2`（B13） |
| 冻结对象 commit | `e8c48fc` |
| G0 身份证据 commit | `d3ca831` |
| CHANGELOG commit | `7e45a86` |
| 冻结链证据 commit | `caebaeb` |
| Git tag | `v1.0-freeze-owtda-cal-r1` → `caebaeb` |
| 工作区 | clean，stash=0 |

## 2. 冻结身份

- `freeze_id = 7cb4f85e31394b23f6c9d6bcaa9ce6a7fc7b824b2b5c8fb6b600c9181979322d`
- 由四个 spec hash 派生：`protocol_content_hash=6c1acb3c…`、`scope_spec_hash=8b9590b8…`、
  `analysis_spec_hash=1de8b743…`、`compute_spec_hash=4082572e…`；
- `estimand_registry_hash=d696f2ce…` 由 `ANALYSIS_SPEC` 绑定（registry 先生成，满足 §15.2 顺序）；
- `SCOPE_DESIGN`：NULL 112 行（28 cells × 2 feature × 2 method）、ALT 32 行（8 cells × 4）。

## 3. 质量门（实测）

| 检查 | 结果 |
|---|---|
| pytest 全量 | **362 passed / 0 failed** |
| ruff（src/tests/audit） | **All checks passed** |
| `audit/validate_freeze.py` | **ALL_PASS=True**（22 项） |
| `audit/validate_identity.py` | **5/5 PASS** |
| `audit/build_freeze.py` 幂等重跑 | hash 与文件字节不变 |
| patch（115,088 B） | SHA256 `ca66cbad…`，apply check PASS，sidecar 一致 |

## 4. 关键验证点（tests 锁定）

- **spec hash 合同**：`spec_hash(kind, version, spec)` 与手工 `H(...)` 一致；任一值变化 → hash 变化；
- **freeze_id 敏感性**：四个 spec hash 中任一被替换 → `freeze_id` 改变（§19 #1）；
- **protocol_content 文档绑定**：篡改 `documents[].file_sha256` → `protocol_content_hash` 改变；
- **SCOPE_DESIGN 行序/换行无关**：行序打乱后 `scope_design_hash` 与 CSV 文本均不变（§19 #83）；
  值变化（如 `replicate_count`）→ hash 变化；
- **CSV 合同**：固定列序、LF 结尾、无 CR；重复主键、缺列、多列一律拒绝；
- **磁盘对象可重算**：5 个 spec 文件与 2 个 SCOPE_DESIGN CSV 均能从磁盘字节重算出 manifest 记录的 hash；
- **无环**：`freeze_id` 不出现在任何被哈希 spec 中；manifest 自身不含 `manifest_hash`；
- **冻结状态**：4 个治理文档头部含 `FROZEN`。

## 5. 已知边界与后续绑定

1. `source_tree_hash` 覆盖已跟踪的 `src/`、`configs/`、`audit/` 文件（32 个）；
   后续批次改动这些目录会改变该值 —— 需重跑 `build_freeze.py` 刷新 manifest，
   **spec hashes 与 `freeze_id` 不变**；正式 run 前以 `RUN_COMPONENT_SET` 绑定最终 manifests。
2. `environment_lock_hash` 目前覆盖 `pyproject.toml` + `COMPUTE_FREEZE.json`（`uv.lock` 不存在）；
   B14b/正式 run 前若生成 lock 文件需重新绑定。
3. `COMPUTE_FREEZE.json` 记录的 `w_star=8` 为 B13 RC 预研结论；正式 §9.4 判定仍需 blind smoke
   的 `t_0,32`/`t_1,32` 外推与总 RSS/swap/磁盘增量实测（G3）。
4. REAL 线仍为 `REAL_OMITTED_BY_DATA_GATE`（数据事实）；正式 append-only 链事件在 B14b 写入。

## 6. 未运行项与原因
- `SEED/COMPONENT/SECRET_COMMITMENT` registries：B14b（需本地生成 root keys，仅提交 commitment）；
- blind smoke 与正式运行：G3/G4，冻结后按排程执行。

## 7. 方案方复审结论
- 冻结链闭合且无环，`freeze_id` 可重算，`SCOPE_DESIGN` 与 `freeze_id` 派生一致；
- 治理文档状态已升 `FROZEN`，本批 0 科学 MC、0 正式 RNG 消费；
- 全部质量门通过，tag 与冻结点一致。

**复审：PASS，准予闭合 B14a，等待签发 B14b（registries + REAL_DISPOSITION + 冻结收尾）。**
