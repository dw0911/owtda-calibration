# B07 VALIDATION REPORT — OW-TDA-CAL-R1 Scope 与逻辑身份层（L0）

> 执行环境：登记主机（Windows 11，f:/BPI/owtda-calibration）
> 环境版本：Python 3.12.10 / numpy 2.2.6 / pytest 9.1.1 / ruff 0.16.6
> 日期：2026-09-10
> 结论：**PASS —— 0 缺陷，可签发 B08**

## 1. 批次状态

| 项 | 值 |
|---|---|
| 上游 HEAD | `c9208ac`（编辑部咨询取消） |
| 本批代码 commit | `247295d` |
| 证据 | `identity_check_20260909T194247Z.json`（G0 5/5，sha256 `113edb30…`） |
| 工作区 | clean，stash=0 |

## 2. 质量门（实测）

| 检查 | 结果 |
|---|---|
| pytest 全量 | **192 passed / 0 failed**（B07 新增 12 项） |
| ruff | **All checks passed** |
| validate_identity.py | **5/5 PASS** |
| patch（20,252 B） | SHA256 `4bfb79ce…`，apply check PASS，sidecar 一致 |

## 3. 契约验证（tests 锁定）

- `scope_spec_hash`：稳定且 H0/H1 不同；spec 无 freeze/logical derived ID；
- `freeze_id` 链：稳定、protocol_content_hash 任一改变即变；
- logical cell/data/feature/evaluation key：稳定、对 ρ/stride/phase 敏感、key 相互不同；
- H0 28 格 / H1 8 格；行数 280,000 / 51,200；feature rows 140,000 / 25,600；
- SCOPE_DESIGN 主键唯一、`expected==replicate_count`、ALT source-null=4（按 ρ×stride 共享）；
- H0 每格均带 budget_membership；ALT 不携带预算标签。

## 4. 冻结前待决（flag，供 B14 复审）
1. NULL `scenario_id="h0"`、ALT `"shape_change"/"mean_shift"` 的命名登记；
2. 正式 `project_id/protocol_id/freeze_id` 值由 B14 content hash 计算后替换占位；
3. `SCOPE_SPEC`/`SCOPE_DESIGN` 正式文件与 CSV 在 B14 落库（本批只提供确定性构建器）。

## 5. 方案方复审结论
- 本批将 §15.3/§16.2 的 scope/身份链公式转为可测试代码；28/8 格与 280k/51.2k 等计数与计划 §9 逐项一致；
- ALT source-null 语义（按 ρ×stride 共享）与 §12.3 一致；
- 0 MC、0 正式 RNG 消费；未伪造任何正式身份/注册表条目。

**复审：PASS，准予闭合 B07，等待签发 B08。**
