# B07 EXECUTION GUIDE — OW-TDA-CAL-R1 Scope 与逻辑身份层（L0）

> BATCH_ID：`OWTDA_CAL_R1_B07_20260910_SCOPE_ID`
> 上游 commit：`c9208ac`（编辑部咨询取消修订）；目标 commit：`247295d` + 证据
> 性质：**L0 身份/scope 层代码** —— 0 正式 MC、0 正式 RNG 消费；不写正式
> `SCOPE_SPEC/COMPUTE_FREEZE`（冻结批 B14 落库）。计划依据：§15.3、§16.2、§9、§12。

## 1. 变更清单

| 模块 | 职责 |
|---|---|
| `src/owtda_cal/scope.py` | `SCOPE_SPEC`（H0/H1，无 derived ID）+ `scope_spec_hash`；`freeze_id` 链；`experiment_id`/`logical_cell_id`/`logical_data_key`/`logical_feature_key`/`logical_evaluation_key`；H0 28 格 / H1 8 格枚举；`scope_design_rows`（NULL 112 / ALT 32 行）；`scope_counts_summary` |
| `tests/test_scope.py` | 12 项新测试 |

## 2. 关键契约与计数（tests 锁定）

| 量 | 值 |
|---|---|
| H0 logical cells | 7 几何 × 2 DGP × 2 ρ = **28** |
| H1 logical cells | 2 alternative × 2 ρ × 2 stride = **8** |
| data units | H0 70,000 / H1 12,800 |
| evaluation rows | H0 **280,000** / H1 **51,200** |
| feature-sufficient rows | H0 140,000 / H1 25,600 |
| SCOPE_DESIGN 行 | NULL 112 / ALT 32；主键 `(phase,logical_cell_id,feature_id,method_id)` 唯一；`expected==replicate_count` |
| ALT source-null | 按 (ρ,stride) 唯一（两 alternative 共享）：4 个源 N-CIRCLE NULL cell |

命名决策（**冻结时复审**，已 flag）：
- NULL `scenario_id="h0"`；ALT `"shape_change"/"mean_shift"`（§12）；
- scenario_id 永不携带预算标签（预算只存 `budget_membership`）；
- `scope_design_rows` 现在需要占位 `project/protocol/freeze` 参数——**正式值由 B14 用 content hash 计算**，本批不写正式 governance 文件（避免伪造身份）。

## 3. 验证结果（本批实测）

| 项 | 值 |
|---|---|
| pytest 全量 | **192 passed / 0 failed** |
| ruff | **All checks passed** |
| G0 校验器 | **5/5 PASS** |
| patch | 20,252 B；SHA256 `4bfb79ce035d180400859b2764d57316aa4c980c764901d8ba24349e1cfeca35`；apply check PASS |

## 4. 本地复验

```powershell
cd f:/BPI/owtda-calibration
git status --porcelain=v1
git apply --check ..\_incoming\OWTDA_CAL_R1_B07_20260910_SCOPE_ID\OWTDA_CAL_R1_B07_20260910.patch
git apply ..\_incoming\OWTDA_CAL_R1_B07_20260910_SCOPE_ID\OWTDA_CAL_R1_B07_20260910.patch
python -m pytest -q
```

## 5. 下一批预告（B08）
`scientific_row` 双层 schema 族（logical/wire、f64: 视图、round-trip）+ config schema 注册，随后 B11a（DATA_MANIFEST 固化，9/13 承诺窗口）。
