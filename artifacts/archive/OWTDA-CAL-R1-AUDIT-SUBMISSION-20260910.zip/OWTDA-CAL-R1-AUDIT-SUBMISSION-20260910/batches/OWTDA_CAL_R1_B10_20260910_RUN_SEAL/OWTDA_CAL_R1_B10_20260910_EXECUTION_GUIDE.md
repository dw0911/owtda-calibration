# B10 EXECUTION GUIDE — OW-TDA-CAL-R1 run 编排与 seal 状态机（L0）

> BATCH_ID：`OWTDA_CAL_R1_B10_20260910_RUN_SEAL`
> 上游 commit：`c25a7df`（B09）；目标 commit：`794a092` + 证据 `c82d5d0`
> 性质：**L0 编排/密封机制代码** —— 0 正式 MC、0 正式 RNG 消费。
> 计划依据：§15.3-§15.4（expected indexes/shard/RUN_SEAL）、§16.2（PHASE_SEAL/链）、§2.3。

## 1. 变更清单

| 模块 | 职责 |
|---|---|
| `src/owtda_cal/indexes.py` | expected 三层索引构建/校验（排序、唯一、跨层一致性）、`index_content_hash`；shard plan 构建/哈希；`RUN_COMPONENT_SET` strict 校验+哈希（upstream role 顺序按 phase）；`RUN_SEAL`/`PHASE_SEAL` payload 构建/哈希；域分离 ID-set hash |
| `src/owtda_cal/chains.py` | 链 genesis、事件哈希、**CAS append（独占锁文件）**、tip 读取；phase-state / validity 事件构建 |
| `src/owtda_cal/shardio.py` | shard staging（三件套）→ fsync → 原子 rename → `SHARD_COMMITTED` CAS；幂等重提交；`ORPHAN_FINAL` 重算比对修复；attempts 原子单调分配 |
| `tests/test_{indexes,chains,shardio}.py` | 28 项新测试 |

## 2. 关键契约

- 单对象哈希：`SHA256(canonical_json(obj_without_own_hash)+LF)`；索引内容哈希对 exact JSONL bytes；
- expected 行：data/feature/evaluation 三层各自键唯一 + 排序；跨层一致性（同 logical data/feature → 同 concrete ID）；
- RUN_COMPONENT_SET：字段集严格、refs `(role,stable_id,generation_id)` 唯一且排序、upstream role 顺序按 phase（NULL `[]` / ALT / REAL_PREDICTION / REAL_EVALUATION）；
- RUN_SEAL：shard commit refs 唯一排序、`feature_empty_by_contract ⇒ feature_row_count==0`；
- 链：`append_cas` 校验 tip 后才写、fsync、锁文件释放；stale tip 拒；
- shard：同 shard 重复提交幂等（返回原 commit，不重复写）；冲突 commit records 阻断；ORPHAN 重算一致才补 commit，不一致保留两份并阻断。

## 3. 验证结果（本批实测）

| 项 | 值 |
|---|---|
| pytest 全量 | **257 passed / 0 failed** |
| ruff | **All checks passed** |
| G0 校验器 | **5/5 PASS**（证据 `identity_check_20260910T005328Z.json`） |
| patch | 51,894 B；SHA256 `26e1c3d88794d100a6d40d6020d050cf7e3d841cfaa0d048a06f19540dead2d9`；apply check PASS |

## 4. 已知边界（冻结前待强化，已登记）
1. `append_cas` 为**单主机**独占锁实现（正式运行同机，符合 §9.4 参考环境）；
2. `allocate_attempt` 的号段在锁外计算（单进程/串行运行安全；并行 worker 下需在锁内重算——B13 攻击/并行批处理时强化）；
3. shard manifest 的 nested schema/id-set 校验器在本批为结构级，完整 §15.4 replay 校验随 run 实现批补齐。

## 5. 下一批预告
**B11 主体（PAMAP2 importer/task builder → REAL_DATA_TASK_GATE，9/17）** 或 **B13（攻击套件/并行一致性）**。按排程 9/13 commitments 与 9/17 Data Gate 为硬时点，建议优先 B11 主体。
