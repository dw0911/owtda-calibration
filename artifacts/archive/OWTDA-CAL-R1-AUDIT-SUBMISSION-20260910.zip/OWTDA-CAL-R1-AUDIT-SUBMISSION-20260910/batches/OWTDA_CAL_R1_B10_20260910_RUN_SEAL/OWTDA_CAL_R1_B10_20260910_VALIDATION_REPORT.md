# B10 VALIDATION REPORT — OW-TDA-CAL-R1 run 编排与 seal 状态机（L0）

> 执行环境：登记主机（Windows 11，f:/BPI/owtda-calibration）
> 日期：2026-09-10
> 结论：**PASS —— 0 缺陷，可签发 B11 主体/B13**

## 1. 批次状态

| 项 | 值 |
|---|---|
| 上游 HEAD | `c25a7df`（B09） |
| 本批代码 commit | `794a092` |
| 证据 commit | `c82d5d0`（G0 5/5，sha256 `065381d9…`） |
| 工作区 | clean，stash=0 |

## 2. 质量门（实测）

| 检查 | 结果 |
|---|---|
| pytest 全量 | **257 passed / 0 failed**（B10 新增 28 项） |
| ruff | **All checks passed** |
| validate_identity.py | **5/5 PASS** |
| patch（51,894 B） | SHA256 `26e1c3d8…`，apply check PASS，sidecar 一致 |

## 3. 覆盖的契约点（tests 锁定）
- 三层索引排序/唯一/跨层一致性；坏键与非 hex 拒绝；
- shard plan 排序与 `shard_id` 公式；重复 row / 非法 row_type 拒；
- RUN_COMPONENT_SET 字段集、refs 唯一排序、phase→upstream roles 强制；ALT 缺 source-null 拒；
- RUN_SEAL / PHASE_SEAL 构建与哈希；`feature_empty_by_contract` 一致性；
- 链 CAS：首 append、stale tip 拒、pre-containing hash 字段拒、锁释放；
- shard：首提交三件套落地 + manifest scientific_hash、幂等重提交不重复、冲突 commit 记录阻断、ORPHAN 等值补 commit、ORPHAN 不一致阻断、attempts 单调分配。

## 4. 已知边界（透明登记）
1. `append_cas` 单主机锁语义；正式运行为单机参考环境；
2. `allocate_attempt` 号段在锁外计算（并行 worker 需锁内重算，B13 强化）；
3. manifest nested schema/ID-set 的完整 replay 校验留待 run 实现批。

## 5. 方案方复审结论
- 编排/密封机制与 §15.3–15.4/§16.2 一致，构成 smoke seal（9/21）与 freeze（9/23）的可复用基建；
- ORPHAN/CAS/幂等等 §15.4 关键规则具备可测锚点；
- 0 MC、0 正式 RNG 消费；未写任何正式 run 目录。

**复审：PASS，准予闭合 B10，等待签发 B11 主体（PAMAP2 importer/task builder）。**
