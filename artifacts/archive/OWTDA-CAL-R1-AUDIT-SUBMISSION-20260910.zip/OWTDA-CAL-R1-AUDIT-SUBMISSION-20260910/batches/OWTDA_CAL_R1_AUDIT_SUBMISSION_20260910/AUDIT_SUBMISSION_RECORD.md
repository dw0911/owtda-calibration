# OWTDA-CAL-R1-AUDIT-SUBMISSION-20260910 — 审计提交说明

- 生成时间（UTC）：2026-09-10T14:25:09Z
- 归档：`artifacts/archive/OWTDA-CAL-R1-AUDIT-SUBMISSION-20260910.zip`（5,267,467 B，315 个对象）
- ZIP SHA256：`8839454e6c6c48707da28277c714a1fc414ebfe715b44c563e0bcbd52a15d2e5`
- `package_manifest.json` SHA256：`3337f284d82ddaf555af780913faa31d49e04e2e80bcfb608e3bc6451dc456b6`
- 构建期自校验：**627 个成员逐一复核，mismatch = 0**
- 运行期 HEAD：`52ad45aa3f80d6424658c43a47f2879df5fb8841`；工作区 clean = **False**

## 1. 本包覆盖的实验

| 批次 | 内容 | 证据等级 | 状态 |
|---|---|---|---|
| B13 | attack suite + compute budget RC | L0 | 已闭合 |
| B14a/B14b | 共同冻结 + registries + REAL disposition | L0 | 已闭合 |
| B15a | run 身份层（RUN_COMPONENT_SET/bindings） | L0 | 已闭合 |
| B15b | SMOKE_NULL（S01） | L0 | **已作废**（F-B15c-1） |
| B15c | H1 alternative DGP + SMOKE_NULL/ALT（S02）+ §9.4 完整判定 + `w*` 扫描 | L0 | 待审计 |

## 2. Gate 判定

| gate | status | 摘要 |
|---|---|---|
| `G0-FREEZE-CHAIN-AND-IDENTITY` | **PASS** | 冻结链、三类 registry、SCOPE_DESIGN（NULL/ALT，冻结不变）、run 身份（RUN_COMPONENT_SET/RUN_INPUT_BINDINGS）重算闭合。 |
| `G3-BLIND-SMOKE-BOTH-PHASES` | **PASS** | 两 phase 盲 smoke（S02）：计数、零错误、零缺字段、formal ID 零泄漏、身份闭合、provenance 绑定、代次一致全部达标。 |
| `SECTION-9-4-COMPUTE-BUDGET` | **PASS** | t_H0=22.842 h ≤ 192 h、t_H1=4.731 h ≤ 76.8 h、t_core=27.573 h ≤ 268.8 h；RAM ≤ 24 GiB、swap 增量为 0、磁盘 ≤ 0.8×F_free、open_runs=0。 |
| `W-STAR-CONFIRMATION` | **FAIL_UNCONFIRMED** | 冻结 w*=8；扫描（replicates=8）选择 [12]；payload 在所有 worker 数下逐位一致。 |
| `H1-ALTERNATIVE-CONSTRUCT-CONTRACTS` | **PASS** | H1 两 alternative 的 RNG 消费形状、变点规则、连续噪声、共享 draw、null signature 回归、身份分层由单元/契约测试锁定（**L0 证据**）。 |
| `SOURCE-REVISION-ADMISSIBILITY` | **BLOCKED_PENDING_OPERATOR_ACTION** | 归档内容可按 hash 逐字节验证，但审计受理所需的**不可变 revision** 尚未建立：B15c 变更处于已暂存未提交状态。 |

## 3. 关键数字

- `freeze_id`：`7cb4f85e31394b23f6c9d6bcaa9ce6a7fc7b824b2b5c8fb6b600c9181979322d`（未变）
- `source_tree_hash`：`0cd15a9676961622e9c203f8f9fbd9c51d1d61566affe3a3c0282f2176015ee6`（45 文件）
- `smoke_config_hash`：`fc4c54b9023d0194b3d805500f50f21dc999a46a6633eb331d02211673800be0`
- SMOKE_NULL：896 / 3,584 / 73,600，`t_0,32 = 842.03 s` → `t_H0_hat = 22.842 h`
- SMOKE_ALT：256 / 1,024 / 49,152，`t_1,32 = 272.52 s` → `t_H1_hat = 4.731 h`
- `t_core_hat = 27.573 h`；peak RSS 1.393 GiB；swap 增量 0；磁盘 386.1 MiB；`open_runs=0`
- **`w*` 扫描**：payload 全 worker 数逐位一致；吞吐最高 w=12（H0 +8.1%、H1 +6.3%）

## 4. 需审计裁定的事项

见同目录 `OPEN_ISSUES_AND_DECISIONS.md`（问题 8 项 + 待决断 5 项）。
其中两项为受理/科学前置：**D-5 具名 commit** 与 **D-1 w\* 裁定**。
