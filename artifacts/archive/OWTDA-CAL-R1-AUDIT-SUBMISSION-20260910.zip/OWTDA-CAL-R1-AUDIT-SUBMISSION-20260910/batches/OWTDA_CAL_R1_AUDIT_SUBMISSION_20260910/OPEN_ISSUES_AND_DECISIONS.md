# OWTDA-CAL-R1-AUDIT-SUBMISSION-20260910 — 问题与待决断登记

生成时间（UTC）：2026-09-10T14:25:09Z

## A. 遇到的问题

| ID | 级别 | 类别 | 标题 | 状态 | 关联决断 |
|---|---|---|---|---|---|
| F-B15c-1 | HIGH | contract_violation_inherited_from_B15b | B15b 的 smoke runner 借用 formal 身份域与 formal 流 | FIXED_IN_B15c | D-2 |
| F-B15c-2 | MEDIUM | contract_extension | §15.2 流表缺少 smoke 版 shift_direction | IMPLEMENTED_AMENDMENT_RECORD_PENDING | D-3 |
| F-B15c-3 | LOW | validator_staleness | audit/validate_freeze.py 硬编码组件数 6 | FIXED_IN_B15c | — |
| F-B15c-4 | MEDIUM | process_hazard | source_tree_hash 仅覆盖 git ls-files 命中的文件 | DOCUMENTED | D-4 |
| O-1 | HIGH | unclosed_governance_decision | w* 扫描未确认冻结值（measured 12 vs frozen 8） | OPEN_DECISION | D-1 |
| O-2 | HIGH | admissibility_blocker | 归档 revision 尚未提交（工作区 dirty） | OPEN_OPERATOR_ACTION | D-5 |
| O-3 | MEDIUM | measurement_noise | H0 wall 抖动与 w=10 swap 观测 | NOTED | D-1 |
| O-4 | INFO | disposition | REAL 线 OMITTED_BY_DATA_GATE（23 < 24 任务） | DISPOSITIONED | — |

### 明细

#### F-B15c-1 — B15b 的 smoke runner 借用 formal 身份域与 formal 流

- 级别/类别：HIGH / `contract_violation_inherited_from_B15b`
- 状态：`FIXED_IN_B15c`
- 说明：smoke.py 调用 cells.master_replicate_id / physical_cell_id / base_series_id / data_unit_id 与 scope.logical_cell_id / logical_data_key / logical_feature_key / logical_evaluation_key；流 kind 为 null_initial / null_innovation / null_observation_noise，命名域为 {data_generation_id, DGP_family, master_replicate_id}；ledger 缺 experiment_id。违反 Plan §16（smoke 独立身份域，禁止借用 formal logical IDs）、§9.3（stream_kind 必须 smoke_ 前缀）、§15.2（smoke 字段表）。
- 影响：B15b 的 S01 smoke 运行证据全部作废（superseded/）；B15b 的 G3 PASS 判定在smoke 身份维度失效，其余维度不受影响。
- 证据：`superseded/SUPERSEDED_INDEX.json`、`repo/governance/CHANGELOG.md`、`repo/src/owtda_cal/smoke_ids.py`

#### F-B15c-2 — §15.2 流表缺少 smoke 版 shift_direction

- 级别/类别：MEDIUM / `contract_extension`
- 状态：`IMPLEMENTED_AMENDMENT_RECORD_PENDING`
- 说明：新增 smoke_shift_direction（字段同其它 smoke 数据流 {smoke_generation_id, phase, DGP_family, replicate_id}），恰一次 rng.random(float64)，仅 mean-shift 消费。属 spec 增行。
- 影响：建议登记 AMENDMENT_REGISTRY.jsonl（该文件当前尚不存在）。
- 证据：`repo/src/owtda_cal/dgp.py`、`repo/governance/CHANGELOG.md`

#### F-B15c-3 — audit/validate_freeze.py 硬编码组件数 6

- 级别/类别：LOW / `validator_staleness`
- 状态：`FIXED_IN_B15c`
- 说明：新增 H1 数据组件（SYNTHETIC_CIRCLE_BASED_H1_V1）后该断言失效；已改为与 components.component_definitions() 比对，避免 registry 静默过期。
- 证据：`repo/audit/validate_freeze.py`

#### F-B15c-4 — source_tree_hash 仅覆盖 git ls-files 命中的文件

- 级别/类别：MEDIUM / `process_hazard`
- 状态：`DOCUMENTED`
- 说明：新模块若未 git add，则不进入 FREEZE_MANIFEST.source_tree_hash（冻结清单静默漏项）；且在 freeze/run 身份重建后改动 src/configs/audit 会使已产出的 smoke 证据 provenance 失效。
- 影响：已在 B15c EXECUTION_GUIDE §4 写明顺序纪律（先 add → 再 build → 再 run）。
- 证据：`repo/audit/build_freeze.py`、`repo/audit/build_run_admission.py`

#### O-1 — w* 扫描未确认冻结值（measured 12 vs frozen 8）

- 级别/类别：HIGH / `unclosed_governance_decision`
- 状态：`OPEN_DECISION`
- 说明：payload 在所有 worker 数下逐位一致；吞吐 w=12 相对 w=8 为 H0 +8.1%、H1 +6.3%，超过 §9.4 的 2% 并列阈值，规则指向 w*=12。
- 影响：w_star 属 COMPUTE_SPEC ⇒ 改动将改变 compute_spec_hash → freeze_id → SCOPE_DESIGN 与全部合成身份（等价于重新冻结）；但不改变任何已达成 Gate 的结论。
- 证据：`repo/artifacts/audit/worker_sweep_RC.json`

#### O-2 — 归档 revision 尚未提交（工作区 dirty）

- 级别/类别：HIGH / `admissibility_blocker`
- 状态：`OPEN_OPERATOR_ACTION`
- 说明：Plan §20.1 要求批次结束回传新 HEAD 与空工作区证明；审计规格阻断冻结域 dirty 文件。本包以 source_tree_hash + 逐对象 sha256 锚定内容，commit 不改变文件内容，故提交后本包全部 sha256 仍然有效。
- 证据：`source/git_state.json`、`submission/ADMISSION_RECORD.json`

#### O-3 — H0 wall 抖动与 w=10 swap 观测

- 级别/类别：MEDIUM / `measurement_noise`
- 状态：`NOTED`
- 说明：H0 三次 S02 实测 808.43 / 798.99 / 842.03 s（±2.7%）；SMOKE_ALT w=10 采样出现 3.7 MB swap 增长（RSS 1.67 GiB，非本 run 触发），按 §9.4「无 swap」判为不合格。
- 证据：`repo/artifacts/audit/worker_sweep_RC.json`

#### O-4 — REAL 线 OMITTED_BY_DATA_GATE（23 < 24 任务）

- 级别/类别：INFO / `disposition`
- 状态：`DISPOSITIONED`
- 说明：数据事实而非实现缺陷；合成主线不受影响；REAL 链 tip 未变。
- 证据：`repo/governance/REAL_DISPOSITION.jsonl`

## B. 待提交的决断

| ID | 决断 | 建议 | 阻断 |
|---|---|---|---|
| D-1 | w* 取 8（冻结）还是 12（实测最优）？ | 先以 32-replicate 全长复核 w=12 的优势，再决定是否重新冻结。 | B15d 正式 run 的 compute 身份 |
| D-2 | F-B15c-1 是否需要对 B15b 判定作正式撤回（recission）？ | 登记一条 invalidation 事件，保持链式可追溯。 | D-3（登记基础设施） |
| D-3 | 是否为 §15.2 增行（smoke_shift_direction）与 §9.3 代次提升（S01→S02）登记 amendment？ | 建立 registry 并登记（二者均属 spec 级变更）。 | D-2 |
| D-4 | 是否将 src/owtda_cal/smoke_ids.py 纳入冻结源域 / 组件 code_files？ | 维持现状（smoke 制品永不进入 formal phase）。 | — |
| D-5 | 提交具名 commit 以建立不可变审计 revision？ | 允许提交（不重建），compute_git_commit 语义在 B15d 统一处理。 | 审计受理；B15d |

### 明细

#### D-1 — w* 取 8（冻结）还是 12（实测最优）？

- 选项 1：采纳 12：需 COMPUTE_SPEC amendment + 重新冻结（freeze_id 变更、SCOPE_DESIGN 重生成、tag 迁移），并在正式 run 前完成
- 选项 2：维持 8：记录豁免理由（例如以 32-replicate 全长重复测量为准），不重新冻结
- 后果：两选项均不改变任何已达成 Gate 的结论（wall Gate 对 12 只会更宽松）；决策只影响 compute 身份与正式 run 的实际并行度。
- 建议：先以 32-replicate 全长复核 w=12 的优势，再决定是否重新冻结。
- 阻断：B15d 正式 run 的 compute 身份

#### D-2 — F-B15c-1 是否需要对 B15b 判定作正式撤回（recission）？

- 选项 1：在 CHANGELOG 记录 B15b smoke 判定部分失效（本包已披露），不另立文书
- 选项 2：登记 INVALIDATION_REGISTRY.jsonl 事件（该文件尚未建立）
- 后果：影响 B15b 在审计链上的状态标记与其可引用性。
- 建议：登记一条 invalidation 事件，保持链式可追溯。
- 阻断：D-3（登记基础设施）

#### D-3 — 是否为 §15.2 增行（smoke_shift_direction）与 §9.3 代次提升（S01→S02）登记 amendment？

- 选项 1：建立 AMENDMENT_REGISTRY.jsonl 并登记两条
- 选项 2：仅在 CHANGELOG 记录（现状）
- 后果：决定 spec 偏离是否以结构化形式进入审计链。
- 建议：建立 registry 并登记（二者均属 spec 级变更）。
- 阻断：D-2

#### D-4 — 是否将 src/owtda_cal/smoke_ids.py 纳入冻结源域 / 组件 code_files？

- 选项 1：维持现状：smoke 基础设施仅由 run 级 source_tree_hash 覆盖（推荐）
- 选项 2：纳入 identity_core：使每个组件 code manifest 覆盖 smoke 身份域
- 后果：后者将改变全部组件 hash 与 run 身份（需重建 + 重跑 smoke）。
- 建议：维持现状（smoke 制品永不进入 formal phase）。
- 阻断：—

#### D-5 — 提交具名 commit 以建立不可变审计 revision？

- 选项 1：允许（推荐）：内容不变，本包 sha256 全部继续有效，仅新增 revision 锚点
- 选项 2：允许并重建 manifest：使 compute_git_commit = 批次 commit，需重跑两 phase smoke（约 19 min）
- 选项 3：暂不提交：本包保持 PENDING（审计受理将受阻）
- 后果：影响审计受理（audit_spec §4 阻断 dirty 冻结域）。
- 建议：允许提交（不重建），compute_git_commit 语义在 B15d 统一处理。
- 阻断：审计受理；B15d
