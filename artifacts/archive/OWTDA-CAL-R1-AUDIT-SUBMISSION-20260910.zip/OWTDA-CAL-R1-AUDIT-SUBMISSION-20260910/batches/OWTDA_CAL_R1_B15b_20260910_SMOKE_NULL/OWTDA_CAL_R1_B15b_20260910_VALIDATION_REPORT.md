# B15b VALIDATION REPORT — OW-TDA-CAL-R1 G3 blind smoke（SMOKE_NULL）

> 执行环境：登记主机（Windows 11，`f:/BPI/owtda-calibration`；8 workers）
> 环境：Python 3.12.10 / numpy 2.2.6 / scipy 1.15.3 / ripser 0.6.15 / pytest 9.1.1 / ruff
> 日期：2026-09-10
> 结论：**PASS —— 0 缺陷；G3（H0 部分）达标，§9.4 H0 wall/RAM/磁盘三项 PASS，可签发 B15c**

## 1. 批次状态

| 项 | 值 |
|---|---|
| 上游 HEAD | `3cbd84a`（B15a） |
| 本批 commit | `52ad45a` |
| 冻结 tag | `v1.0-freeze-owtda-cal-r1` → `e16222f`（**未移动**） |
| 工作区 | clean，stash=0 |

## 2. 执行结果

**SMOKE_NULL（8 workers）**：wall **1019.56 s**、data units **896**、evaluation rows **3,584**、
PH 窗口 **73,600**、未解释 error **0**、缺字段 **0**、禁止聚合输出 **无**。

**§9.4 H0 分段**：`t_0,32 = 1019.56 s` → `t_H0_hat = 27.657 h ≤ 192 h` ✓

**资源实测（2-replicate 采样）**：总 peak RSS（父 + 8 workers）= **1.486 GB** ≤ 24 GiB ✓；
run 期间 swap 增量 **0 bytes** ✓；`estimated_peak_disk = 230.4 MiB ≤ 0.8 × 455.6 GiB` ✓。

## 3. 质量门（实测）

| 检查 | 结果 |
|---|---|
| pytest 全量 | **415 passed / 0 failed**（B15b 新增 11） |
| ruff | **All checks passed** |
| `audit/validate_admission.py` | **10/10 PASS**（G3 合规 5 项 + wall/RAM/swap/磁盘 + open_runs） |
| `audit/validate_runs.py` | ALL_PASS（28 项） |
| `audit/validate_freeze.py` | ALL_PASS（33 项） |
| patch（2,751,760 B，含 smoke ledger） | SHA256 `7945b8db…`，apply check PASS |

## 4. 关键验证点

- **计数契约**：实测 896/3,584/73,600 与 `smoke.expected_smoke_counts()` 完全一致（测试与证据双重锁定）；
- **PH 窗口唯一性**：每个 master 的 575 唯一窗口只计算一次，128 master × 575 = 73,600（不做机械全量扫描）；
- **blind 保证**：`SmokeResult.report()` 的键集合固定，不含 `rejection_rate`/`power`/`ranking`/`p_value`/`reject`；
  `SMOKE_CONFIG` 明示 `feeds_parameter_selection=false`；
- **smoke 根隔离**：`smoke_root_key(SMOKE_NULL)` 必须命中唯一 `stream_family=smoke` 条目；
  对正式 `NULL` phase 调用直接拒绝（formal root 不得挂到 smoke executor）；
- **provenance 绑定**：smoke 证据记录 `run_component_set_hash`/`scope_design_hash`/`source_tree_hash`/
  `environment_lock_hash`，并由 `validate_admission.py` 与 manifest 逐项比对；
- **顺序纪律**：先冻结代码状态（`build_freeze` → `build_run_admission`）再运行 smoke，
  使证据绑定最终 `source_tree_hash`；此后不再改动 `src/`/`configs/`/`audit/`。

## 5. 开发中修复（透明披露）

1. **smoke replicates 32（非 128）**：B15a 的数值错误已在本批修正（含删除旧 smoke 对象并重建）；
2. **N-AR 窗口维度**：`raw_prefix` 返回 `[T,1]`，而 delay embedding 需 1-D → 改用 `raw_prefix_1d`；
3. **component `code_files` 遗漏**：补齐 `scan.py` 等 resampler 依赖；
4. **并行粒度**：由"每 master"改为"每 master×feature"（并行度 128 → 256，wall 43 min → 17 min），
   **不改变任何浮点运算顺序**（`scan.statistic_curve` 的 fast/reference 双实现未改动）；
5. ruff 清理（未使用 import、冗余 `int(round(...))`）。

## 6. 已知边界

1. H1 分段 Gate（`t_1,32`）与 `t_core` 判定需 SMOKE_ALT（B15c）；本批 `t_H1` 数字为占位，**非** Gate 判定；
2. `w*` 仍取 B13 的 RC 结论（8）；最终确认在 B15c 与 §9.4 完整判定一同给出；
3. smoke 行不含 run-level provenance 字段（smoke 非 scientific row；provenance 由证据文件的
   `provenance` 块绑定 `RUN_COMPONENT_SET`）——正式 scientific rows 仍须逐字携带四项 provenance（B16）；
4. 本批运行**不产生任何论文数字**；smoke 永不进入论文。

## 7. 方案方复审结论
- G3 计数、盲法与零错误要求全部达标；§9.4 的 wall/RAM/swap/磁盘四项均 PASS 且余量充足（wall 余量约 7×）；
- 冻结科学内容未变（`freeze_id`、五类 spec、`SCOPE_DESIGN_NULL/ALT`、REAL 链 tip）；两处修正已透明披露；
- 本批为本代首次科学计算，0 论文数字、0 正式 RNG 消费（全部使用 smoke root 与 `smoke_` stream）。

**复审：PASS，准予闭合 B15b；等待签发 B15c（H1 alternative DGP + SMOKE_ALT + §9.4 完整判定 + w* 确认）。**
