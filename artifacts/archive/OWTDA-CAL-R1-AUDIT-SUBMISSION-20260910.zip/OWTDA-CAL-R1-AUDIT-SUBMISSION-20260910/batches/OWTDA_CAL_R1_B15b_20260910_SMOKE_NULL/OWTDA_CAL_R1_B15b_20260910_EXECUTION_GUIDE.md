# B15b EXECUTION GUIDE — OW-TDA-CAL-R1 G3 blind smoke（SMOKE_NULL）

> BATCH_ID：`OWTDA_CAL_R1_B15b_20260910_SMOKE_NULL`
> 上游 commit：`3cbd84a`（B15a）；目标 commit：`52ad45a`
> 冻结 tag 未移动：`v1.0-freeze-owtda-cal-r1` → `e16222f`
> 计划依据：§9.3（smoke 计数与盲法）、§9.4（wall/RAM/磁盘 Gate）、G3、G4 前置
> 性质：**本代首次运行科学计算**（blind smoke；不产生任何论文结果）

## 1. 本批的两项修正（透明披露）

1. **smoke 规模修正**：每格 replicates 应为 **32**（计划 §9.3：H0 = 28×32 = 896 data units、
   3,584 rows、128 master paths × 575 = 73,600 PH 窗口；`t_{0,32}`/`t_{1,32}` 的下标即 32）。
   B15a 误写为 128；本批修正 `R0_SMOKE=32` 与 `SMOKE_CONFIG_v1.json`，**删除**旧 smoke 的
   SCOPE_DESIGN CSV / RUN_COMPONENT_SET / bindings 后重建。
2. **component 代码清单完整性**：原 `code_files` 遗漏 resampler 依赖 `scan.py` 与
   `seeding.py`/`canonical.py`/`identity.py`/`hashing.py`；已补齐并重建 COMPONENT_REGISTRY。

两项均**不改变** `freeze_id`、五类 spec hash、`SCOPE_DESIGN_NULL/ALT`、三类 registry 的条目集合与 REAL 链 tip；
改变的只是 smoke 规模参数与 component 的代码清单（及其派生的 run 身份）。

## 2. 重建后的 run 身份

| phase | RUN_COMPONENT_SET | scope design | bindings |
|---|---|---|---|
| `SMOKE_NULL` | `aad291fc9570639467de0246cf7125561e7bc210d83b3f6347d58907b608fd73` | `SCOPE_DESIGN_SMOKE_NULL_92589b2d….csv`（112 行 / 32 reps） | `08eb1360…`（9 行） |
| `SMOKE_ALT` | `4a31e21b0c3d5f2d1e87384840331607607b913eb6bf2472fc1b39135ffe3188` | `SCOPE_DESIGN_SMOKE_ALT_94e1903e….csv`（32 行 / 32 reps） | `08eb1360…`（9 行） |
| `NULL` | `7f021ed43d12cec3fe36a2ad016916c224a8e31d12a08a793e9eca64dcc18b73` | `SCOPE_DESIGN_NULL_bbecccb5….csv`（冻结不变） | `9a8a2e54…`（8 行） |

`source_tree_hash = 97e32eeb37646011fce249681dda4599de595cb7a8e1bc51f75e6fc704f79ddd`；
`smoke_config_hash = 630f01ccffc9aa31670ea79062b7e4d0e8e82bb89b88b874f060462c2d14d3da`。

## 3. G3 smoke 实跑结果（8 workers）

| 项 | 计划值 | 实测 |
|---|---|---|
| data units | 896 | **896** ✓ |
| evaluation rows | 3,584 | **3,584** ✓ |
| PH windows（唯一窗口） | 73,600 | **73,600** ✓ |
| 未解释 error | 0 | **0** ✓ |
| 缺必需字段 | 0 | **0** ✓ |
| 禁止聚合输出 | 无 | **无** ✓ |
| wall time | — | **1019.56 s**（`t_0,32`） |

行仅作运行证据写入 `artifacts/smoke/SMOKE_NULL/evaluation_rows_w8_r32.jsonl`（2.47 MB），**永不进入论文**。

## 4. §9.4 预算 Gate（H0 部分）

| Gate | 判定 | 依据 |
|---|---|---|
| wall | **PASS** | `t_H0_hat = 1.25 × (2500/32) × t_0,32 = 27.657 h ≤ 192 h` |
| RAM | **PASS** | 总 peak RSS（父 + 8 workers）= **1.486 GB ≤ 24 GiB** |
| swap | **PASS** | run 期间 swap 增量 = **0 bytes** |
| 磁盘 | **PASS** | `estimated_peak_disk = 230.4 MiB ≤ 0.8 × 455.6 GiB` |
| open runs | **PASS** | `open_runs = 0` |

> H1 分段 Gate 需 `t_1,32`（SMOKE_ALT，B15c）—— 本批的 `t_H1` 数字只是占位，**不是** Gate 判定。

## 5. 新增代码

| 文件 | 职责 |
|---|---|
| `src/owtda_cal/smoke.py` | SMOKE_NULL runner：master×feature 粒度并行；每 master 的 575 唯一窗口恰好计算一次；`stream_kind` 全部 `smoke_` 前缀；只输出 wall/计数/错误（blind） |
| `audit/run_smoke.py` | 执行 smoke、写 ledger、产出 `artifacts/audit/smoke_RC.json`（含 provenance 与 §9.4 H0 外推） |
| `audit/validate_admission.py` | G4 前置：G3 合规 + §9.4 三项 Gate（含父子进程总 RSS 与 swap 增量采样）+ `open_runs=0` |
| `tests/test_smoke.py` | 11 项：冻结计数、575 起点、blind 输出白名单、smoke root 隔离、禁止输出 |
| `src/owtda_cal/calibrate.py` | `stream_kind` 参数化（默认值不变，正式路径行为不变） |

## 6. 本地复验

```powershell
cd f:/BPI/owtda-calibration
git apply --check ..\_incoming\OWTDA_CAL_R1_B15b_20260910_SMOKE_NULL\OWTDA_CAL_R1_B15b_20260910.patch
git apply ..\_incoming\OWTDA_CAL_R1_B15b_20260910_SMOKE_NULL\OWTDA_CAL_R1_B15b_20260910.patch
python -m pytest -q
python audit/build_freeze.py ; python audit/build_run_admission.py
python audit/run_smoke.py --workers 8        # ~17 min，重跑得到同一 t_0,32 量级
python audit/validate_admission.py           # 10/10 PASS
python audit/validate_runs.py ; python audit/validate_freeze.py
```

## 7. 下一批预告（B15c：SMOKE_ALT + §9.4 完整判定）
1. 实现 H1 alternative DGP（§12.1 形状变化 `X_t=F(U_t)+0.08η_t (t>τ)`、§12.2 mean shift `+δv·1(t>τ)`, δ=0.5）
   与 `build_null_signature` 回归（H1 必须精确回到对应 N-CIRCLE H0 的 `null_model_config_hash`）；
2. SMOKE_ALT 实跑（256 data units / 1,024 rows / 49,152 PH 窗口）→ `t_1,32`；
3. §9.4 完整判定：`t_H1_hat = 1.25 × (1600/32) × t_1,32`、`t_core = t_H0 + t_H1`（分段 Gate 独立判定）；
4. `w*` 最终确认（吞吐最高 + payload 逐位一致 + RSS/swap 合规，并列 2% 取小）；
5. G4 admission 前置收尾与 NULL phase 的 expected indexes（ID-only pass）。
