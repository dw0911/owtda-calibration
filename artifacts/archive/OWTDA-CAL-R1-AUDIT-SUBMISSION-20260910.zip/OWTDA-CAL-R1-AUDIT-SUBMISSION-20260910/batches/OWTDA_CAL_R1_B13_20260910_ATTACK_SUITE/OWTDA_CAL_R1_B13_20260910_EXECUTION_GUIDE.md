# B13 EXECUTION GUIDE — OW-TDA-CAL-R1 攻击套件 + 并行一致性 + 预算复核（L0）

> BATCH_ID：`OWTDA_CAL_R1_B13_20260910_ATTACK_SUITE`
> 上游 commit：`be2ae6e`（B11b3）；目标 commit：`6105d9f` + 证据 `22dd3b2`
> 性质：**L0 攻击/确定性代码 + 预算预研** —— 0 正式 MC、0 正式 RNG 消费。
> 计划依据：§19（93 项攻击）、§9.4（预算 Gate）、G2（确定性）。

## 1. 变更清单

| 文件 | 职责 |
|---|---|
| `src/owtda_cal/parallel.py` | `ordered_map`/`feature_matrix_parallel`（有序重组，任意 worker 数逐位重现 `workers=1`）、`feature_chunk` 公开 worker、`scan_for_global_numpy_random` 静态攻击 |
| `src/owtda_cal/calibrate.py` | 暴露规则函数 `p_value`/`reject_from_exceed`/`resample_exceeds`（使 §19 #29/#30/#34 可独立重放）；内部改用之（行为不变） |
| `tests/test_parallel.py` | 9 项（workers 一致性、提交顺序无关、chunk 无关、空输入、全局 RNG 扫描） |
| `tests/test_attacks.py` | 37 项跨模块攻击（映射 §19 编号，含身份/RNG/窗口/特征/推断/ledger/REAL） |
| `audit/compute_budget.py` | §9.4 预算复核：workers{1,4,8} **稳态**吞吐（池 warmup 排除启动）、payload 逐位一致、peak RSS、F: 磁盘、H0/H1/core 外推、w*_rc 选择（并列 2% 取小） |
| `governance/ATTACK_SUITE_v1.0.md` | 93 项攻击登记（状态 + 覆盖位置 + 后续闭合计划） |
| `artifacts/audit/compute_budget_RC.json` | 预算证据 |

## 2. 预算复核读数（本机，RC 预研）

| workers | 稳态 ms/窗口 | H0 外推 | payload 逐位一致 | wall gate |
|---|---|---|---|---|
| 1 | 1.819 | 2.91 h | — | PASS |
| 4 | 0.506 | 0.81 h | ✓ | PASS |
| 8 | **0.293** | **0.47 h** | ✓ | PASS |

- peak RSS（父进程）157.6 MB ≤ 24 GiB ✓；F: free 455.6 GiB；
- **w\*_rc = 8**（吞吐最高、payload 一致、wall gate PASS）；
- 阈值：`t_H0 ≤ 192 h`、`t_H1 ≤ 76.8 h`、`t_core ≤ 268.8 h`（§9.4）——当前余量极大。

> 正式 §9.4 判定须用 blind smoke 的 `t_0,32`/`t_1,32` 外推，并实测总 peak RSS、swap 与持久化磁盘增量；本表为 RC 预研，不含这三项。

## 3. 攻击套件状态（B13 时点）

| 状态 | 数量 |
|---|---|
| COVERED | 41 |
| PARTIAL | 20 |
| DEFERRED | 32 |

- 新增覆盖能力：有序并行确定性（#8/#9）、全局 RNG 静态攻击（#12）、规则级边界（#29/#30/#34）；
- DEFERRED 全部依赖尚未实现的 run/ledger/release/分析器批次；闭合计划见 `ATTACK_SUITE_v1.0.md`。

## 4. 验证结果（本批实测）

| 项 | 值 |
|---|---|
| pytest 全量 | **343 passed / 0 failed** |
| ruff | **All checks passed** |
| G0 校验器 | **5/5 PASS**（证据 `identity_check_20260910T013300Z.json`） |
| patch | 59,042 B；SHA256 `efdee1444c35b80a720866b6fbd7df5890c6beadf6846a7b94d0adb4db50beb7`；apply check PASS |

## 5. 本地复验

```powershell
cd f:/BPI/owtda-calibration
git apply --check ..\_incoming\OWTDA_CAL_R1_B13_20260910_ATTACK_SUITE\OWTDA_CAL_R1_B13_20260910.patch
git apply ..\_incoming\OWTDA_CAL_R1_B13_20260910_ATTACK_SUITE\OWTDA_CAL_R1_B13_20260910.patch
python -m pytest -q
python audit/compute_budget.py
python audit/validate_identity.py
```

## 6. 下一批预告（B14：9/23 共同冻结）
`protocol_content_hash`/`freeze_id` 计算与冻结、`SCOPE_SPEC_v1.json` 与 `SCOPE_DESIGN_*.csv` 落库、
`COMPUTE_FREEZE.json`（含 environment lock、w*、版本、BLAS/线程变量）、SEED/COMPONENT registry 正式条目与
root-key commitments、REAL `REAL_DISPOSITION` 链事件（`REAL_OMITTED_BY_DATA_GATE`）、Git tag、G0 扩展校验。
