# B13 VALIDATION REPORT — OW-TDA-CAL-R1 攻击套件 + 并行一致性 + 预算复核（L0）

> 执行环境：登记主机（Windows 11，f:/BPI/owtda-calibration）
> 环境：Python 3.12.10 / numpy 2.2.6 / scipy 1.15.3 / pytest 9.1.1 / ruff 0.16.6 / ripser 0.6.15
> 日期：2026-09-10
> 结论：**PASS —— 0 缺陷，可签发 B14（9/23 共同冻结）**

## 1. 批次状态

| 项 | 值 |
|---|---|
| 上游 HEAD | `be2ae6e`（B11b3） |
| 本批代码 commit | `6105d9f` |
| 证据 commit | `22dd3b2`（G0 5/5，sha256 `e879fb3e…`） |
| 工作区 | clean，stash=0 |

## 2. 质量门（实测）

| 检查 | 结果 |
|---|---|
| pytest 全量 | **343 passed / 0 failed**（B13 新增 46 项） |
| ruff（src/tests/audit） | **All checks passed** |
| validate_identity.py | **5/5 PASS** |
| patch（59,042 B） | SHA256 `efdee144…`，apply check PASS，sidecar 一致 |

## 3. 关键验证点（tests 锁定）

**并行确定性（§19 #8/#9）**
- `feature_matrix_parallel` 在 workers=2/3 下与 workers=1 **逐位相等**（BPI 800 维、MOMENTS）；
- 打乱提交顺序后按逆置换逐行核对相等；`chunk_size` 1 vs 4 结果相等；空输入形状正确；
- `ordered_map` 保持输入顺序（workers=2）；`workers=0` 拒绝。

**全局 RNG 静态攻击（§19 #12）**
- `scan_for_global_numpy_random(src, tests)` 返回空；白名单仅 `Generator`/`PCG64DXSM`/`SeedSequence`/`default_rng`。

**规则级边界（§19 #29/#30/#34）**
- `p_value(exceed)*1000 == 1+exceed`（0/1/49/50/999）；`reject_from_exceed(49)=True`、`(50)=False`；
- `resample_exceeds(0.5,0.5)=True`，`resample_exceeds(nextafter(0.5,0),0.5)=False`（精确 `>=`）。

**跨模块攻击（37 项）**：身份冻结失效、字段三态、NFC/十进制/reserved key、四 family seed 无交集、
1000 次派生无碰撞 + intentional alias、ρ/stride 不改变 innovation、family 级 root 隔离、stream_kind 分离、
M0/M1 逐 resample 共享、窗口公式/边界/反例、点云置换/重复/远端扰动、双环与共线结构、平移旋转缩放（rtol 1e-10）、
cap/grid/thresh 分离、空图与退化协议、CUSUM 双实现 ≤1e-12、observed 跨方法一致、DMB 三角核端点、
candidate/plateau 方法无关、共享 s16 格唯一、budget 不影响物理 hash、REAL 泄露字段拒绝、
row hash 自排除与非有限拒绝、method generation 局部性、array 端序等价与 header 敏感、
dataset_hash 顺序无关与作用域、task builder 边界、task_id 敏感性、ORPHAN/CAS 幂等与冲突阻断。

## 4. 预算复核（RC 预研，非正式 §9.4 判定）

| workers | 稳态 ms/窗口 | H0 外推 | payload 一致 | wall gate |
|---|---|---|---|---|
| 1 | 1.819 | 2.91 h | — | PASS |
| 4 | 0.506 | 0.81 h | ✓ | PASS |
| 8 | 0.293 | 0.47 h | ✓ | PASS |

- **w\*_rc = 8**；阈值 192/76.8/268.8 h，余量极大；
- 父进程 peak RSS 157.6 MB（≤24 GiB）；F: free 455.6 GiB；
- **未测**：总 peak RSS（含 workers）、swap、持久化磁盘增量 → 需 blind smoke（G3）实测。

## 5. 攻击套件登记

`governance/ATTACK_SUITE_v1.0.md`：93 项 → **COVERED 41 / PARTIAL 20 / DEFERRED 32**，
含后续闭合批次映射。DEFERRED 全部依赖 run/ledger/release/分析器批次（尚未实现），
无"实现缺陷导致的未覆盖"。

## 6. 未运行项与原因
- blind smoke（4,608 rows）与正式 admission：属 G3/G4，需 run 编排 + 冻结（B14 之后）；
- Linux 重建（L4）、release 打包攻击（§19 #42/#43/#90/#93）：属后续批次。

## 7. 方案方复审结论
- 并行路径满足 G2"workers=1 与 w* scientific payload 一致 + 顺序打乱一致"；
- 全局 RNG 禁令可自动化执法（静态扫描），满足 §19 #12；
- 预算预研显示计算余量极大（H0 单核 2.91 h vs 上限 192 h），预算风险低；
- 0 MC、0 正式 RNG 消费；未修改任何科学契约（calibrate 重构保持行为一致，343 项测试回归通过）。

**复审：PASS，准予闭合 B13，等待签发 B14（9/23 共同冻结）。**
