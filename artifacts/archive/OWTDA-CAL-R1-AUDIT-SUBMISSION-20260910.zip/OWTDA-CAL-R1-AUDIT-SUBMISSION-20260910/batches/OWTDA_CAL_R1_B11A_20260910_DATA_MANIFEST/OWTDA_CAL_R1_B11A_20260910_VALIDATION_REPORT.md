# B11A VALIDATION REPORT — OW-TDA-CAL-R1 PAMAP2 DATA_MANIFEST 固化（身份层）

> 执行环境：登记主机（Windows 11，f:/BPI/owtda-calibration）
> 日期：2026-09-10
> 结论：**PASS —— 0 缺陷，可签发 B09**

## 1. 批次状态

| 项 | 值 |
|---|---|
| 上游 HEAD | `4054f7c`（B08） |
| 本批代码 commit | `dd23c04` |
| 证据 commit | `06e5899`（G0 5/5，sha256 `8dfd49b1…`） |
| 工作区 | clean，stash=0 |

## 2. 质量门（实测）

| 检查 | 结果 |
|---|---|
| pytest 全量 | **215 passed / 0 failed** |
| ruff | **All checks passed** |
| validate_identity.py | **5/5 PASS** |
| patch（10,307 B） | SHA256 `f85a825d…`，apply check PASS，sidecar 一致 |

## 3. dataset_hash 锁定

```
dataset_hash = eb0e11f9c20a0498ffc5f69017b5fd7744f4d46232b8adf52f1b9352525fc33b
```
由九个 `Protocol/subject101.dat..subject109.dat` 的 {path,size,file_sha256}（排序）经
`H("pamap2_protocol_dataset", manifest_entries=…)` 计算；生成后独立重算一致（verify_ok=True）。

provenance（不进 dataset_hash）：outer zip `76b3580b…`、inner zip `6c2282b5…`、readme `99a0339f…`；
DOI 10.24432/C5NW2H；raw 文件不随发布包分发。

## 4. 测试锚点（tests/test_realdata.py）
- 恰九条 entries、顺序不敏感；缺 1 条/坏 path（含 `PAMAP2_Dataset/` 前缀）/缺字段均拒；
- `dataset_hash` golden 结构 = `H("pamap2_protocol_dataset", …)`；内容（sha/size）任一改变即变。

## 5. 未运行项与原因
- `timebase_diagnostics`/importer/task builder 属 B11 主体（数据下载已就绪，识别为 9/13 commitments 后批）。
- raw Protocol 文件（约 1.3 GB）不入 git；仅 manifest/哈希入库。

## 6. 方案方复审结论
- 科学 dataset_hash 只锚定九个 Protocol 文件、与 §13.2 一致；ZIP/readme provenance 分离；
- 该哈希即 9/13 需提交的 dataset 身份（首次 task enumeration 前 commitments 可直接引用）。

**复审：PASS，准予闭合 B11A，等待签发 B09。**
