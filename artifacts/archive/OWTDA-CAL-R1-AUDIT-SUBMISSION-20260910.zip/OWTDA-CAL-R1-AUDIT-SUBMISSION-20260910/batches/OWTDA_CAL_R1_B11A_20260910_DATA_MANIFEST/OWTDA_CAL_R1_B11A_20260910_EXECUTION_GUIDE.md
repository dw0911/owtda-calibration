# B11A EXECUTION GUIDE — OW-TDA-CAL-R1 PAMAP2 DATA_MANIFEST 固化（身份层）

> BATCH_ID：`OWTDA_CAL_R1_B11A_20260910_DATA_MANIFEST`
> 上游 commit：`4054f7c`（B08）；目标 commit：`dd23c04` + 证据 `06e5899`
> 性质：**L0 数据身份固化** —— 0 正式 MC、0 正式 RNG 消费。
> 计划依据：§13.2（dataset_hash 只覆盖九个 Protocol 文件）、§25 E（raw 不随包分发）。
> 前置：PAMAP2 已下载/解构并核验（B11A 前置工作，数据在 `f:/BPI/owtda-data/pamap2/`）。

## 1. 变更清单

| 文件 | 职责 |
|---|---|
| `src/owtda_cal/realdata.py` | 九文件 entries 生成与校验（`Protocol/subject101..109.dat`）、`dataset_hash = H("pamap2_protocol_dataset", manifest_entries=…)` |
| `configs/real/DATA_MANIFEST.json` | 科学 `dataset_hash` 输入与值、来源/DOI/许可、outer/inner zip 与 readme 的 SHA256（provenance-only，不进 dataset_hash）、布局/字段映射/活动集、RC 状态与冻结目标 |
| `tests/test_realdata.py` | 7 项新测试 |

## 2. 关键契约

- **dataset_hash = `eb0e11f9c20a0498ffc5f69017b5fd7744f4d46232b8adf52f1b9352525fc33b`**（九文件 {path,size,sha} 排序后 H）；ZIP/readme 只作 provenance；
- 字段映射：列 1 timestamp、列 2 activityID、22–24 chest ±16g xyz；25–27（±6g）禁用；
- 本 RC 对齐 9/17 `REAL_DATA_TASK_GATE`；raw 文件不随发布包分发（复现者按 DOI 获取并核对）；
- `timebase_diagnostics` 待 importer 批（B11 主体）填充，届时 manifest 冻结。

## 3. 验证结果（本批实测）

| 项 | 值 |
|---|---|
| pytest 全量 | **215 passed / 0 failed** |
| ruff | **All checks passed** |
| G0 校验器 | **5/5 PASS**（证据 `identity_check_20260909T215556Z.json`） |
| patch | 10,307 B；SHA256 `f85a825de550195b2a4d8479fff1371d5c2c66de628fa8871a56edb1914d9d66`；apply check PASS |

## 4. 本地复验

```powershell
cd f:/BPI/owtda-calibration
git apply --check ..\_incoming\OWTDA_CAL_R1_B11A_20260910_DATA_MANIFEST\OWTDA_CAL_R1_B11A_20260910.patch
git apply ..\_incoming\OWTDA_CAL_R1_B11A_20260910_DATA_MANIFEST\OWTDA_CAL_R1_B11A_20260910.patch
python -m pytest -q
python -c "import json; m=json.load(open('configs/real/DATA_MANIFEST.json',encoding='utf-8')); print(m['dataset_hash'])"
```

## 5. 下一批预告
- **B09（smoke/registry 雏形 + workers 基准/吞吐探针）** 或 **B11 主体（importer/task builder、REAL_DATA_TASK_GATE 9/17）**。建议继续主线 B09，B11 主体在 9/13 commitments 后衔接。
