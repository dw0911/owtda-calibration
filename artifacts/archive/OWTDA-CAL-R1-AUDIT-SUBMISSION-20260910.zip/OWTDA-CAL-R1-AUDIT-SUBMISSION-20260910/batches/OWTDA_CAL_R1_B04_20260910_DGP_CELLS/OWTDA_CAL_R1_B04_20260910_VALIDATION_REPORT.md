# B04 VALIDATION REPORT — OW-TDA-CAL-R1 H0 布局与 DGP 生成器（L0）

> 执行环境：登记主机（Windows 11，f:/BPI/owtda-calibration）
> 环境版本：Python 3.12.10 / numpy 2.2.6 / scipy 1.15.3 / pytest 9.1.1 / ruff 0.16.6
> 日期：2026-09-10
> 结论：**PASS —— 0 缺陷，可签发 B05/B06**

## 1. 批次状态

| 项 | 值 |
|---|---|
| 上游 HEAD | `ec0656b`（B03） |
| 本批代码 commit | `76da477`（+794 行，4 文件） |
| 证据 commit | `7efb85d`（identity re-check JSON） |
| 工作区 | clean，stash=0 |

## 2. 质量门（实测）

| 检查 | 结果 |
|---|---|
| pytest 全量 | **117 passed / 0 failed** |
| ruff（src/tests/audit） | **All checks passed** |
| validate_identity.py | **5/5 PASS**，EXIT=0（证据 sha256 `0b9efd87…`） |

## 3. 关键数值断言（tests 内锁定）

- fixed-M `T=64+191s`：{12288, 6176, 3120, 1592}；fixed-T `M`：{48, 96, 192, 383}（s=64/32/16/8）；
- 7 唯一几何；s16/T3120 共享格 `budget_membership=[FIXED_M, FIXED_T]`；
- 575 起点：fixed-T s8 段 383（0..3056）、fixed-M s32 新增 96（3072..6112）、s64 新增 96（6144..12224）；
- N-AR AR(1)：ρ=0 lag-1≈0、ρ=0.8 lag-1≈0.8、方差≈1（全长 12,288，容差 0.05）；
- N-CIRCLE：边际均值≈0、方差≈0.5、半径≈1（0.08 噪声尺度）；
- 延迟嵌入手工反例通过。

## 4. 契约验证（透明）

- ρ=0 与 ρ=0.8 同一 replicate：`innovation_hash` 相等、`raw_series_hash` 不同（创新共享、路径不同）；
- `rho=0.8`(float) 在 spec 中拒绝（canonical decimal 契约）；`"0.8"` 与 `0` 正常；
- array hash 全部走 `>f8` 大端字节合同。

## 5. 开发中修复记录

1. 575 起点 map 的 FIXED_T 标记边界（初版 `>=3056` 误去 3056 标签）→ 改为按集合成员判定；
2. cell 几何测试遗漏 shared(s16,T3120) 的 fixed-M 成员（KeyError）→ 修正断言；
3. 统计断言改用全长 12,288 + 容差 0.05，避免 seed 抽样偶然；
4. ruff：`dict()`/列表 `[0]`/import 排序清理。

## 6. 未运行项与原因

- 无正式 MC/盲法 smoke；未产生任何正式数据或 seed registry 条目（0 RNG 消费，仅测试 root key）。
- H1（ALT）生成器与 size-standardization join 留待后续批（需 effect 配置与 phase 身份链）。

## 7. 方案方复审结论

- 几何/575 布局与计划 §8 数值表逐项一致（G1 相关项已具备测试锚点）；
- DGP 实现遵循 §7：burn-in 1000、innovation `[13288]`、窗口局部规则、ρ-free 创新；
- 所有身份经 `H()` canonical payload（rho 以十进制文本）；
- 0 MC、0 正式 RNG 消费；代码全部 L0。

**复审：PASS，准予闭合 B04，等待签发 B05/B06。**
