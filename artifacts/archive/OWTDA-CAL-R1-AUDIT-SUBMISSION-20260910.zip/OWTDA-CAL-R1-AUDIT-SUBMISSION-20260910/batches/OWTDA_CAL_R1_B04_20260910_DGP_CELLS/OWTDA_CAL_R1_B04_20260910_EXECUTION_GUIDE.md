# B04 EXECUTION GUIDE — OW-TDA-CAL-R1 H0 布局与 DGP 生成器（L0）

> BATCH_ID：`OWTDA_CAL_R1_B04_20260910_DGP_CELLS`
> 上游 commit：`ec0656b`（B03 闭合）；目标 commit：`76da477` + 证据 `7efb85d`
> 性质：**L0 数据层代码** —— 0 正式 MC、0 正式 RNG 消费（只用测试 root key 验证生成器）。
> 计划依据：§7（DGP）、§8（双矩阵/575-start）、§15.2-§15.4（RNG/身份/字节合同）。

## 1. 变更清单

| 文件 | 职责 |
|---|---|
| `src/owtda_cal/cells.py` | fixed-M/fixed-T 几何（7 唯一格）、`T=W+s(M-1)`/`M=⌊(T-W)/s⌋+1`、575 唯一起点 map、`physical/base/data_unit/master_replicate/cluster` ID |
| `src/owtda_cal/dgp.py` | N-AR/N-CIRCLE data-model spec + `data_model_config_hash`、H0 NULL master 生成（burn-in、innovation `[13288]`、N-CIRCLE noise `[12288,2]`）、`raw_series_hash`、窗口局部延迟嵌入 `(x_t,x_{t+3},x_{t+6})` |
| `tests/test_cells.py` | 几何数值表、575 起点（383/96/96）、7 唯一格/共享格、ID 敏感性与 canonical rho |
| `tests/test_dgp.py` | spec/hash、确定性、ρ 间共享创新、AR(1) 自相关/方差、N-CIRCLE 边际、raw hash、延迟嵌入手工用例 |

## 2. 关键契约

- **创新 ρ-free**：innovation 的 stream 字段不含 ρ → 同一 replicate 在 ρ=0/0.8 共享创新
  （`innovation_hash` 相同），raw series 不同（`raw_series_hash` 不同）。
- **canonical ρ**：spec/ID 一律以十进制文本进入（`"0"`/`"0.8"`；`0.8` float 被拒——契约如此）。
- **布局数**：7 唯一几何（fixed-M 4 + fixed-T 3 增量），575 起点 = fixed-T s8(383) + fixed-M s32 新增(96) + fixed-M s64 新增(96)。
- **字节合同**：innovation `synthetic_latent_innovation_v1 >f8 [13288]`；raw `synthetic_raw_series_v1 >f8 [T,d]`（N-AR [T,1]、N-CIRCLE [T,2]）；噪声 `synthetic_observation_noise_v1 >f8 [12288,2]`。
- **RNG golden 边界**：HMAC→seed 已冻结；PCG 输出仅同版本断言（NumPy 升级须升 generation）。

## 3. 验证结果（本批实测）

| 项 | 值 |
|---|---|
| pytest 全量 | **117 passed / 0 failed**（含 B03 87 + B04 30） |
| ruff（src/tests/audit） | **All checks passed** |
| G0 校验器 | **5/5 PASS**（证据 `identity_check_20260909T183857Z.json`，sha256 `0b9efd87…`） |
| patch SHA256 | `f726662ba1abb34bb37a83eb22606b86a91b6203db3615bb01074b2eb4a3e51e` |
| `git apply --check`（ec0656b worktree） | PASS |

## 4. 本地执行方复验

```powershell
cd f:/BPI/owtda-calibration
git status --porcelain=v1
(Get-FileHash ..\_incoming\OWTDA_CAL_R1_B04_20260910_DGP_CELLS\OWTDA_CAL_R1_B04_20260910.patch -Algorithm SHA256).Hash.ToLower()
git apply --check ..\_incoming\OWTDA_CAL_R1_B04_20260910_DGP_CELLS\OWTDA_CAL_R1_B04_20260910.patch
git apply ..\_incoming\OWTDA_CAL_R1_B04_20260910_DGP_CELLS\OWTDA_CAL_R1_B04_20260910.patch
python -m pytest -q
python audit/validate_identity.py
```

## 5. 下一批预告（B05/B06）
- B05：BPI/MOMENTS feature 管线（窗口→点云去重→PH/解析→800/5/9 维向量；`feature_config_hash`）；
- B06：M0/M1 resampler 与扫描统计量/CUSUM 双实现（≤1e-12）与 p 值重放。
