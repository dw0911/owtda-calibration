# B03 EXECUTION GUIDE — OW-TDA-CAL-R1 身份核心（L0）

> BATCH_ID：`OWTDA_CAL_R1_B03_20260910_IDENTITY_CORE`
> 上游 commit：`fcac40e`（计划基线入库）；目标 commit：`2e93785` + 证据 `ec0656b`
> 性质：**L0 基础代码批次** —— 0 正式/盲法 MC、0 RNG 消费（仅测试 RNG 派生函数）。
> 前置：B01/B02 已闭合（用户确认）；计划基线 `OWTDA_CAL_R1_COMPLETE_PLAN_v1.0.md`
> （SHA256 `dca49727…`）已入库并为本批与后续批次的上游。

## 1. 变更清单

### `src/owtda_cal/`（身份基础层，Plan §15.2–§15.4）
| 模块 | 职责 |
|---|---|
| `canonical.py` | canonical JSON（键排序/无空白/ASCII 字段名/NFC/禁 float）、canonical decimal text（禁指数/前导+/尾零，`-0→"0"`）、单对象 content hash |
| `identity.py` | `H(id_kind, **fields)`（`^[a-z][a-z0-9_]*$`）、`config_hash`、`file_manifest_hash`、`expected_id_set_hash`、`root_entry_hash` |
| `seeding.py` | `derive_seed_hex/int`、`make_rng`（PCG64DXSM）、`root_key_commitment` |
| `hashing.py` | `file_sha256`、`array_bytes/array_hash`（大端 `>f8/>i8` 字节合同、`-0.0` 归一、finite 校验）、`f64_view` |
| `__init__.py` | 版本、`PROJECT_ID=owtda-cal-r1`、域常量与导出 |

### 测试与审计
- `tests/`：4 组 golden 测试（87 项）。
- `audit/validate_identity.py`：G0 校验器雏形（5 项：旧归档 SHA256SUMS、archive_manifest、
  Charter/Claim Matrix、计划基线哈希、工作区干净）。
- `configs/schema/README.md`；`pyproject.toml` 增 `pythonpath` 与 ruff 豁免说明。

## 2. 验证结果（本批实测）

| 项 | 值 |
|---|---|
| `python -m pytest -q` | **87 passed / 0 failed** |
| `python -m ruff check src tests audit` | **All checks passed** |
| `python audit/validate_identity.py` | **5/5 PASS**（EXIT=0），证据 `artifacts/audit/identity_check_20260909T183006Z.json` |
| patch SHA256 | `c279c646d92ab06bd71a8c7bb1f691ad42d56a3babf085075da872db4139b0f9` |
| `git apply --check`（fcac40e worktree） | PASS |
| 工作区 | clean；stash=0 |

## 3. 本地执行方复验命令

```powershell
cd f:/BPI/owtda-calibration
git status --porcelain=v1            # 期望空
(Get-FileHash ..\_incoming\OWTDA_CAL_R1_B03_20260910_IDENTITY_CORE\OWTDA_CAL_R1_B03_20260910.patch -Algorithm SHA256).Hash.ToLower()
git apply --check ..\_incoming\OWTDA_CAL_R1_B03_20260910_IDENTITY_CORE\OWTDA_CAL_R1_B03_20260910.patch
git apply ..\_incoming\OWTDA_CAL_R1_B03_20260910_IDENTITY_CORE\OWTDA_CAL_R1_B03_20260910.patch
python -m pytest -q
python audit/validate_identity.py
```

## 4. 设计与契约要点（供审阅）

- **canonical decimal**：仅接受 `int/str/Decimal`；`float` 一律拒绝；`str` 必须已是 canonical 形式
  （`"0.8"` 可、`"0.80"/"+0.8"/"-0"/"1e2"` 拒）。
- **RNG golden 边界**：HMAC→seed 为纯标准库契约（逐位稳定）；RNG *输出* 仅断言同版本确定性与流分离，
  numpy 版本记入 fixtures——按 Plan §15.2，NumPy 升级若改变输出须提升 component generation（B03 未冻结任何输出 golden）。
- **array 字节**：先 native 归一化（finite、`-0.0→+0.0`）再 `astype` 到大端，规避 NumPy ufunc 回退 native 字节序。

## 5. 下一批预告（B04/B05，未签发）
- B04：DGP 生成器与窗口/延迟嵌入（N-AR/N-CIRCLE、`data_model_config_hash`、RNG consumption golden）；
- B05：feature 管线（BPI/MOMENTS）与 `scientific_row` 双层 schema/expected index 族。
