# B03 VALIDATION REPORT — OW-TDA-CAL-R1 身份核心（L0）

> 执行环境：登记主机（Windows 11，f:/BPI/owtda-calibration）
> 环境版本：Python 3.12.10 / numpy 2.2.6 / scipy 1.15.3 / pytest 9.1.1 / ruff 0.16.6
> 日期：2026-09-10
> 结论：**PASS —— 0 缺陷，可签发 B04/B05**

## 1. 批次状态

| 项 | 值 |
|---|---|
| 上游 HEAD | `fcac40e`（计划基线入库） |
| 本批代码 commit | `2e93785`（+1,216 行，12 文件） |
| 证据 commit | `ec0656b`（identity_check JSON） |
| 工作区 | clean，stash=0 |

## 2. 质量门（实测输出摘要）

| 检查 | 结果 |
|---|---|
| pytest 全量 | **87 passed, 0 failed**（0.3 s） |
| ruff（src/tests/audit） | **All checks passed** |
| validate_identity.py | **5/5 PASS**，EXIT=0 |

### G0 校验明细
```
[PASS] prior_archive_sha256sums: verified 23/23; missing/bad=[]
[PASS] archive_manifest: zip_sha256=match; objects=25; verified=True
[PASS] charter_claim_matrix: charter_ok=True; claims_ok=True
[PASS] plan_baseline_hash: sha256=dca49727…
[PASS] workspace_clean: porcelain_empty=True; stash_empty=True
```
证据：`artifacts/audit/identity_check_20260909T183006Z.json`（SHA256 `eca7984e…`）。

## 3. Patch 验证

| 项 | 值 |
|---|---|
| patch 大小 | 48,761 bytes（ASCII，nul=0） |
| patch SHA256 | `c279c646d92ab06bd71a8c7bb1f691ad42d56a3babf085075da872db4139b0f9` |
| `git apply --check`（fcac40e worktree） | **PASS** |
| sidecar 一致 | True |

## 4. 开发中修复记录（透明披露）

1. dtype 码 kind 解析：初版按 `[-1]` 取字符（错），修正为 `[1]`（如 `>f8`→kind `f`）。
2. `H`/`stream_kind` 增加 `^[a-z][a-z0-9_]*$` 格式约束（拦截含空格等非登记值）。
3. **array 大端 bug**：初版在 `>f8` 数组上做 `np.where`，NumPy ufunc 将非本机字节序结果回退为本机字节序，
   导致输出小端字节；修复为先 native 归一化、最后 `astype` 大端。golden_f64/golden_i8 复验通过。
4. 测试数据修正：`a/b.txt` 实为合法子目录路径（非坏例），移出拒绝用例；reserved-key 注入 `stream_kind`/`id_kind`
   在调用点即 TypeError（同属拒绝），测试断言与注释更新。
5. ruff：`subprocess.run` 补 `check=False`；`TRY004`/`RUF022` 在 pyproject 显式豁免并说明理由。

## 5. 未运行项与原因

- 无（本批无正式 MC / 大计算；G0 全项在冻结前随 COMPUTE_FREEZE 等闭合，见 GUIDE）。

## 6. 方案方复审结论

- 身份基础层严格按 Plan §15.2–§15.4 实现：canonical/ID/seed/array 全部 golden 锁定；
- RNG 输出未冻结 golden（版本敏感，遵 Plan §15.2 升级规则）；
- 字节合同的关键 bug（大端回退）在 golden 测试中被捕获并修复，golden 测试价值得到验证；
- 0 科学 MC、0 正式 RNG 消费；代码全部 L0（单测/攻击/解析反例/校验器）。

**复审：PASS，准予闭合 B03，等待签发 B04/B05。**
