# B14b EXECUTION GUIDE — OW-TDA-CAL-R1 冻结收尾（registries + REAL_DISPOSITION）

> BATCH_ID：`OWTDA_CAL_R1_B14b_20260910_REGISTRIES_AND_REAL_DISPOSITION`
> 上游 commit：`caebaeb`（B14a）；目标 commit：`72a77fd`（内容）→ `e16222f`（证据）
> Git tag：`v1.0-freeze-owtda-cal-r1` → `e16222f`
> 计划依据：§15.1（seed/root registry）、§15.3（component registry）、§2.3/§16.2（REAL_DISPOSITION）
> 性质：**治理冻结收尾** —— 0 正式 MC、0 正式 RNG 消费（仅生成/校验身份与链）。

## 1. 冻结身份（在 B14a 基础上）

`freeze_id` 不变：`7cb4f85e31394b23f6c9d6bcaa9ce6a7fc7b824b2b5c8fb6b600c9181979322d`

| 新登记对象 | 值 |
|---|---|
| `SEED_REGISTRY_v1.0.json` | 13 entries（七元组 ASCII 排序） |
| `seed_registry_snapshot_hash` | `331c4a284c9a42d9319aa1d74e8ad2ec5750036fc0d486c8f24a9f37a70289d9` |
| `COMPONENT_REGISTRY_v1.json` | 6 entries（2 data + 2 feature + 2 method） |
| `component_registry_snapshot_hash` | `71cac3b27700cd3e75c0f657edf539cf433a330d5fd3354067404c4a3b602214` |
| `SECRET_COMMITMENT_REGISTRY_v1.0.json` | `entries=[]`、`reveal_events=[]` |
| `secret_registry_snapshot_hash` | `ca01d46ee912af54d1f00e13d0087599412d68f72df49614cfc3ddc18b020bc0` |
| `REAL_DISPOSITION.jsonl` tip | `6a8ee23b10621f06f15ce914759a27f37c9345d5a0c1c7850cd0a1075bef299c` |
| `reason_object_hash` | `71144c331f108d0e3ff5def4fe977a0acf1887e65393ce69541b713b4c2e125f` |
| `source_tree_hash` | `a8cd6fe0472256215ad46d686a13cc6a6def957d8964136fa6cbde3fb9ddcddc` |
| `environment_lock_hash` | `61f5f50a604efa379e1e67cd9b2fbe466acd6e52e73cb424a321c96f4d72b74e`（不变） |

**SEED_REGISTRY 13 entries**：`SMOKE_NULL/smoke/S01`、`SMOKE_ALT/smoke/S01`、
`NULL/{null_data,data_generation_id=D01}`、`NULL/{null_M0,null_M1}/M01`、
`ALT/{h1_data}/D01`、`ALT/{h1_M0,h1_M1}/M01`、
`REAL_TASK_BUILD/{real_task,real_task_id_salt}/T01`、`REAL_PREDICTION/{real_M0,real_M1}/M01`、
`ANALYSIS/analysis_bootstrap/A01`。

**COMPONENT_REGISTRY 6 entries**：`SYNTHETIC_N_AR_V1`、`SYNTHETIC_N_CIRCLE_V1`（data/D01）、
`BPI_FIXED20_H01_SIGMA005_GAMMA1_V1`、`MOMENTS_MEAN_COV_FROB_V1`（feature/F01）、
`M0_NAIVE_PERM_B999_V1`、`M1_DMB_R1_TRI_EXTIID_B999_V1`（method/M01）。
`config_hash` 使用**不含 run 参数**的生成器/特征/方法配置（`rho` 与 `W/s/T/M` 属 run 配置），
`code_file_manifest_hash` 为逐文件 `{path,size,file_sha256}` 清单。

## 2. 秘密处理（重要）

| 类别 | 处理 |
|---|---|
| 合成/分析 root keys（11 项） | **明文入库**（计划 §16.1 要求提交 Git 以保证空环境可重建） |
| `real_task`、`real_task_id_salt`（2 项） | 仅登记 `secret_ref` + `root_key_commitment`；明文存于 **git-ignored** `secrets/REAL_TASK_SECRETS.local.json` |

- `secrets/` 已加入 `.gitignore`；本批 `git ls-files secrets` = 0（确认未入库）；
- **该本地文件必须备份**：一旦丢失，`root_key_commitment` 无法重算，REAL 线若重启必须提升
  `task_index_generation_id`（`T01` → `T02`）并重走 task-build admission；
- REAL 当前为 `REAL_OMITTED_BY_DATA_GATE`，故 `SECRET_COMMITMENT_REGISTRY` 为空
  （task index 未形成，禁止铸造 candidate/truth salt）。

## 3. REAL_DISPOSITION 链

```
genesis H("real_disposition_genesis", project_id, protocol_id, freeze_id, evidence_generation_id)
  └─ event#1 REAL_OMITTED_BY_DATA_GATE | REAL_DATA_FROZEN | TASK_GATE_MIN_TASKS_NOT_MET
              task_index_seal_hash=null | truth_unsealed=false | tip 6a8ee23b…
```
`reason_object`（`REAL_DISPOSITION_REASON_71144c33….json`）：准入 8 受试者（需 8）、
23 任务（需 24）、`subject109` 无候选、`thresholds_unchanged=true`、`gate.pass=false`。
链写入用 CAS（`expected_tip=None` + 独占锁 + fsync），验证器重放 hash 链、拒绝断链/分叉/
非法枚举与非法字段组合。

## 4. 变更清单（14 文件，+1,373 行）

**新增**：`governance/SEED_REGISTRY_v1.0.json`、`governance/COMPONENT_REGISTRY_v1.json`、
`governance/SECRET_COMMITMENT_REGISTRY_v1.0.json`、`governance/REAL_DISPOSITION.jsonl`、
`governance/REAL_DISPOSITION_REASON_71144c33….json`、
`src/owtda_cal/components.py`、`src/owtda_cal/disposition.py`、`tests/test_disposition.py`。

**修改**：`src/owtda_cal/registry.py`（`seed_entry` 的 `secret_ref` 模式要求显式 commitment）、
`audit/build_freeze.py`（registries + 链生成）、`audit/validate_freeze.py`（33 项校验）、
`governance/FREEZE_MANIFEST.json`（registry 快照与 REAL 链 tip）、`CHANGELOG.md`、`.gitignore`。

## 5. 验证结果（实测）

| 项 | 值 |
|---|---|
| pytest 全量 | **377 passed / 0 failed**（B14b 新增 15） |
| ruff | **All checks passed** |
| `audit/validate_freeze.py` | **ALL_PASS=True（33 项）** |
| `audit/validate_identity.py` | **5/5 PASS** |
| `audit/build_freeze.py` 幂等 | 重跑后 hash、root keys、链 tip 全部不变 |
| patch（66,833 B） | SHA256 `ff095689…`，apply check PASS |

## 6. 本地复验

```powershell
cd f:/BPI/owtda-calibration
git apply --check ..\_incoming\OWTDA_CAL_R1_B14b_20260910_REGISTRIES_AND_REAL_DISPOSITION\OWTDA_CAL_R1_B14b_20260910.patch
git apply ..\_incoming\OWTDA_CAL_R1_B14b_20260910_REGISTRIES_AND_REAL_DISPOSITION\OWTDA_CAL_R1_B14b_20260910.patch
python -m pytest -q
python audit/build_freeze.py     # 幂等；不重建 root keys、不追加链事件
python audit/validate_freeze.py  # 33/33 PASS
python audit/validate_identity.py
```

## 7. 下一批预告（B15：G3 blind smoke + run admission）
1. `RUN_COMPONENT_SET_<hash>.json`（§16.2 strict schema：四类 refs、scope_design_hash、
   registry snapshot、environment lock、compute git commit）；
2. `RUN_INPUT_BINDINGS` 与三类 expected indexes（data/feature/evaluation）生成器；
3. blind smoke（H0 3,584 / H1 1,024 evaluations）——只检查 wall/字段/错误，不输出拒绝率；
4. §9.4 正式预算判定（`t_0,32`/`t_1,32` 外推 + 总 RSS/swap/磁盘增量）与 `w*` 最终确认；
5. G0–G4 扩展校验与 admission 前置检查（`open_runs=0`）。
