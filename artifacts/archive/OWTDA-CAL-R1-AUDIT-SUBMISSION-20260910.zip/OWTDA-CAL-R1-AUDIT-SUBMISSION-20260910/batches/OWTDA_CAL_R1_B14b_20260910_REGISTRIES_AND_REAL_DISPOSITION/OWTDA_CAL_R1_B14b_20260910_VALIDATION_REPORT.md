# B14b VALIDATION REPORT — OW-TDA-CAL-R1 冻结收尾（registries + REAL_DISPOSITION）

> 执行环境：登记主机（Windows 11，`f:/BPI/owtda-calibration`）
> 环境：Python 3.12.10 / numpy 2.2.6 / scipy 1.15.3 / ripser 0.6.15 / pytest 9.1.1 / ruff
> 日期：2026-09-10
> 结论：**PASS —— 0 缺陷，共同冻结（B14a+B14b）闭合，可签发 B15（blind smoke + admission）**

## 1. 批次状态

| 项 | 值 |
|---|---|
| 上游 HEAD | `caebaeb`（B14a） |
| 内容 commit | `72a77fd` |
| CHANGELOG commit | `8a817c8` |
| 证据 commit | `e16222f` |
| Git tag | `v1.0-freeze-owtda-cal-r1` → `e16222f` |
| 工作区 | clean，stash=0 |

## 2. 交付与身份

| 对象 | 结果 |
|---|---|
| `SEED_REGISTRY_v1.0.json` | 13 entries，七元组唯一且 ASCII 排序；snapshot `331c4a28…` |
| `COMPONENT_REGISTRY_v1.json` | 6 entries（data/feature/method ×2），snapshot `71cac3b2…` |
| `SECRET_COMMITMENT_REGISTRY_v1.0.json` | 空 entries/reveal_events（REAL omitted 前不得铸造 salt），snapshot `ca01d46e…` |
| `REAL_DISPOSITION.jsonl` | genesis + 1 event，tip `6a8ee23b…`，`truth_unsealed=false` |
| `REAL_DISPOSITION_REASON_71144c33….json` | reason 重算一致；8 受试者/23 任务/需 24；`gate.pass=false` |
| `FREEZE_MANIFEST.json` | 增记三类 snapshot 与 REAL 链 tip；`source_tree_hash=a8cd6fe0…` |

## 3. 质量门（实测）

| 检查 | 结果 |
|---|---|
| pytest 全量 | **377 passed / 0 failed** |
| ruff（src/tests/audit） | **All checks passed** |
| `audit/validate_freeze.py` | **ALL_PASS=True（33 项）** |
| `audit/validate_identity.py` | **5/5 PASS** |
| `audit/build_freeze.py` 幂等重跑 | root keys 复用、链不追加、全部 hash 不变 |
| `git ls-files secrets` | **0**（隔离秘密未入库） |
| patch（66,833 B） | SHA256 `ff095689…`，apply check PASS，sidecar 一致 |

## 4. 关键验证点（tests 锁定）

- **reason 对象**：hash 稳定、任一值（如 `eligible_tasks`）变化即改变、未知 `reason_code` 拒绝；
- **event 合同**：字段集合恰为冻结枚举；`REAL_DEFERRED` 必须绑定 `task_index_seal_hash` 且
  `truth_unsealed=false`；`REAL_OMITTED_BY_DATA_GATE` 必须保持 truth 封闭；未知 status/stage/reason 拒绝；
- **链重放**：单事件/双事件链通过；篡改 `reason_code` → hash 重放失败；父指针错误 → 拒绝；
  同父双 child（fork/断链）→ 拒绝；空链 → 拒绝；
- **磁盘链**：`REAL_OMITTED_BY_DATA_GATE` / `REAL_DATA_FROZEN` / truth 封闭；reason 文件可重算；
- **registry**：`seed_entry` 的 `secret_ref` 模式必须显式提供 commitment（禁止"零 commitment"占位）；
  REAL 两 family 的 `root_key_hex` 必须为 `null`。

## 5. 已知边界

1. **本地秘密备份**：`secrets/REAL_TASK_SECRETS.local.json` 是 REAL 线重启的唯一凭据；
   丢失须提升 `task_index_generation_id` 并重走 task-build admission。
2. `RUN_COMPONENT_SET`、`RUN_INPUT_BINDINGS` 与 expected indexes 属 G4 admission 批次（B15）。
3. `w*=8` 仍为 RC 预研；正式 §9.4 判定需 blind smoke 的 `t_0,32`/`t_1,32` 与总 RSS/swap/磁盘增量。
4. `source_tree_hash` 覆盖已跟踪 `src/`+`configs/`+`audit/`；后续批次改动需重跑 `build_freeze.py`
   刷新 manifest（spec hashes、`freeze_id`、registry 内容与链 tip 均不变）。

## 6. 未运行项与原因
- blind smoke（H0 3,584 / H1 1,024）与正式 admission：G3/G4，B15；
- REAL 线：`REAL_OMITTED_BY_DATA_GATE`（数据事实），合成主线继续。

## 7. 方案方复审结论
- 三类 registry 与 REAL 处置链全部按 §15.1/§15.3/§16.2 落库并可通过 bytes 重算；
- 隔离秘密未入库，REAL commitment 已冻结且与本地秘密一致；
- 共同冻结（B14a+B14b）闭合，tag 指向最终冻结点；0 科学 MC、0 正式 RNG 消费。

**复审：PASS，准予闭合 B14b；等待签发 B15（blind smoke + RUN_COMPONENT_SET + admission 前置）。**
