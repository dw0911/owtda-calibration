# B01 VALIDATION REPORT — OW-TDA-CAL-R1 项目脚手架

> BATCH_ID：`OWTDA_CAL_R1_B01_20260910_SCAFFOLD`
> 执行环境：登记主机（Windows 11，f:/BPI/owtda-calibration）
> 日期：2026-09-10
> 结论：**PASS —— 0 缺陷，可签发 B02**

## 1. 批次前状态（回传）

| 项 | 值 |
|---|---|
| 上游 HEAD | `b11a92f chore(scaffold): initialize owtda-calibration repository` |
| 工作区 | clean（`git status --porcelain=v1` 空） |
| stash | 0 |

## 2. 应用结果

| 项 | 值 |
|---|---|
| 本批 HEAD | `b1038b4 feat(governance): B01 project charter, claim matrix, prior evidence, manuscript skeleton (OW-TDA-CAL-R1)` |
| patch SHA256（sidecar） | `78003ab518dc2706f68a73b0959dcbe540c01ac17b98ca64fa8c127d2ec5d5ff` |
| `git apply --check`（在 `b11a92f` worktree） | PASS |
| 补丁大小 | 25,098 bytes（ASCII，无 BOM/NUL） |
| 工作区 | clean |

## 3. 验证输出（原样摘要）

```
CLAIM_MATRIX csv 解析：rows=9（header+8 claims），cols=6，claim_id=C1..C8，status 全 UNTESTED → PASS
```

## 4. 变更清单（本批新增 6 文件 + scaffold 5 文件）

| 文件 | 大小 | 行数 |
|---|---:|---:|
| governance/PROJECT_CHARTER.md | 9,540 | 162 |
| governance/CLAIM_MATRIX_v1.0.csv | 2,545 | 9 |
| governance/PRIOR_EVIDENCE_SUMMARY.md | 2,483 | 44 |
| manuscript/OUTLINE.md | 3,599 | 62 |
| manuscript/WRITING_CONSTRAINTS.md | 2,337 | 43 |
| manuscript/COLUMN_RECORD_20260910.md | 2,116 | 30 |

scaffold（commit `b11a92f`）：README.md、LICENSE、CITATION.cff、pyproject.toml、.gitignore、.gitattributes。

## 5. 未运行项与原因

- pytest：本批 0 代码，无可执行测试（声明非遗漏）。
- 期刊公告详情/截止日确认：公告列表页不展开正文，已登记为本地浏览器动作（9/11 前闭合）。

## 6. 方案方复审结论

- 项目身份已与旧代（`bpi-scan`/DMB-R1）隔离；`project_id=owtda-cal-r1` 登记；
- Claim Matrix 8 项预注册状态均 `UNTESTED`，支持规则/未支持写法冻结；
- 旧证据 L1 披露（含终止归档 SHA256 `38790d48…df933d`）就位；
- 字节身份安全已配置（`.gitattributes * -text`）；
- 本批符合计划 §23「9/10 建新仓库/Charter/Claim Matrix/论文骨架」交付。

**复审：PASS，准予闭合 B01，等待签发 B02。**
