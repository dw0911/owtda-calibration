# B01 EXECUTION GUIDE — OW-TDA-CAL-R1 项目脚手架

> BATCH_ID：`OWTDA_CAL_R1_B01_20260910_SCAFFOLD`
> 方案方签发日期：2026-09-10
> 范围：9/10 排程交付「建新仓库、Charter、Claim Matrix、论文骨架、投稿栏目记录」
> 科学性质：**纯治理/文档批次——0 行科学代码、0 个正式/盲法 MC**，无 RNG 消费。

## 1. 批次目标与验收

| # | 交付 | 验收标准 |
|---|---|---|
| 1 | 新 git 仓库 `owtda-calibration`（scaffold commit `b11a92f`） | `git init`、`.gitattributes` 全 `-text`（字节身份安全）、工作区干净 |
| 2 | `governance/PROJECT_CHARTER.md` | 含 `project_id=owtda-cal-r1`、四生存点、证据分级、状态机、批次纪律、日程 |
| 3 | `governance/CLAIM_MATRIX_v1.0.csv` | C1–C8 恰 8 行 claim；状态全 `UNTESTED`；6 列；strict CSV 可解析 |
| 4 | `governance/PRIOR_EVIDENCE_SUMMARY.md` | 披露 DMB-R1 终止 SHA256 与 4 组旧数值；声明 L1 地位 |
| 5 | `manuscript/OUTLINE.md`、`WRITING_CONSTRAINTS.md` | §22 十章骨架 + §21 图表计划；禁用措辞 9 条 |
| 6 | `manuscript/COLUMN_RECORD_20260910.md` | 期刊核查记录；待确认项进入 9/11 编辑部咨询 |
| 7 | 批次四件套 | guide + patch + VALIDATION_REPORT + patch.sha256 齐全 |

## 2. 应用路径

上游（基准）commit：`b11a92f`
本批目标 commit：`b1038b4`
patch：`OWTDA_CAL_R1_B01_20260910.patch`（SHA256 见 sidecar，`git apply --check` 已 PASS）

```powershell
# 仅当工作区 status 与 stash 均为空
cd f:/BPI/owtda-calibration
(Get-FileHash ..\_incoming\OWTDA_CAL_R1_B01_20260910_SCAFFOLD\OWTDA_CAL_R1_B01_20260910.patch -Algorithm SHA256).Hash.ToLower()
git apply --check ..\_incoming\OWTDA_CAL_R1_B01_20260910_SCAFFOLD\OWTDA_CAL_R1_B01_20260910.patch
git apply ..\_incoming\OWTDA_CAL_R1_B01_20260910_SCAFFOLD\OWTDA_CAL_R1_B01_20260910.patch
git status --porcelain=v1
```

## 3. 本地执行方操作

1. 回传 `git rev-parse HEAD` / `git status --porcelain=v1` / `git stash list`；
2. 应用 patch（见上）；
3. 执行验证命令并原样回传输出：

```powershell
python -c "import csv; rows=list(csv.reader(open('governance/CLAIM_MATRIX_v1.0.csv',encoding='utf-8'))); assert len(rows)==9 and len(rows[0])==6 and [r[0] for r in rows[1:]]==['C1','C2','C3','C4','C5','C6','C7','C8']; assert all(r[5]=='UNTESTED' for r in rows[1:]); print('CLAIM_MATRIX=PASS')"
git status --porcelain=v1   # 期望空
```

4. 用浏览器补全 `manuscript/COLUMN_RECORD_20260910.md` 第 2 节（公告详情/截止日/格式/附件/投稿入口），9/11 前随编辑部咨询摘要回传。

## 4. 验收记录（方案方）

- [ ] patch SHA256 sidecar 与重算一致；
- [ ] `git apply --check` PASS；
- [ ] CSV=C8 行、6 列、状态 UNTESTED；
- [ ] 工作区 clean、stash 空；
- [ ] 本批 0 代码/0 MC（无需 pytest 运行）。

## 5. 下一批预告（B02，未签发）

- 物化 `external_prior_evidence/DMB_R1/`（终止归档 25 对象 + SHA256 核验）；
- 将 Plan v1.0 转写为 governance 正式文档骨架（PROTOCOL/METHOD_SPEC/SAP/DATA_SPEC 目录）；
- 视编辑部咨询结果补栏目记录。B02 仅在 B01 VALIDATION_REPORT 复审闭合后签发。
