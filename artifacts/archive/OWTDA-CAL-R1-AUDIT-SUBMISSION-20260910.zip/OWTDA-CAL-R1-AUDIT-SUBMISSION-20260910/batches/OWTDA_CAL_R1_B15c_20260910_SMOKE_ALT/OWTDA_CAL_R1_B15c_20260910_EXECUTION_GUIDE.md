# B15c EXECUTION GUIDE — OW-TDA-CAL-R1 H1 alternative DGP + G3 blind smoke（SMOKE_ALT）

> BATCH_ID：`OWTDA_CAL_R1_B15c_20260910_SMOKE_ALT`
> 上游 commit：`52ad45a`（B15b）；目标 commit：见 `VALIDATION_REPORT`
> 冻结 tag 未移动：`v1.0-freeze-owtda-cal-r1` → `e16222f`
> 计划依据：§12.1–§12.4（H1 构造/功效）、§9.2–§9.4（smoke 与预算 Gate）、§15.2–§15.3（流表与主键）、§16（身份域）
> 性质：**H1 alternative 首次实现 + 首次实跑**（blind smoke；不产生任何论文结果）

## 1. 本批交付

1. **H1 alternative DGP**（`src/owtda_cal/dgp.py`）：`CIRCLE_BASED_H1` 的两种 alternative
   （`shape_change`／`mean_shift`），共享 N-CIRCLE 的 AR/copula latent 路径与观测噪声，
   `tau = floor(T/2)` 处切换确定性骨架；
2. **`build_null_signature(rho, W, s, T, M)`**：H0 与 H1 共用同一 null 模型身份函数，
   H1 cell 将 effect 置零后精确回到对应 N-CIRCLE H0 的 `null_model_config_hash`；
3. **smoke 独立身份域**（新增 `src/owtda_cal/smoke_ids.py`）：实现 §16 全部 12 个
   `smoke_*` ID 与 smoke 流字段构造函数；
4. **SMOKE_ALT runner**：256 data units / 1,024 evaluation rows / 49,152 PH 窗口；
5. **§9.4 完整判定**：`t_0,32`、`t_1,32`、`t_H0_hat`、`t_H1_hat`、`t_core_hat` + RAM/swap/磁盘；
6. **`w*` 确认扫描**（`audit/run_worker_sweep.py`）。

## 2. 透明披露：本批的三项合同修正

### 2.1 F-B15c-1（源自 B15b 的 smoke 身份域/流合同违规，本批修复）

Plan §9.3／§15.2／§16 要求 smoke 使用**完全独立的身份域与流**：

- §16：「smoke 使用完全独立的身份域，禁止借用 formal logical IDs」；
- §9.3：「所有流的 `stream_kind` 必须以 `smoke_` 开头」；
- §15.2：smoke 数据流字段必须是 `{smoke_generation_id, phase, DGP_family, replicate_id}`，
  方法流字段必须是 `{smoke_generation_id, phase, smoke_data_unit_id, resample_index}`。

B15b 的 `smoke.py` 实际调用了 **formal** 身份函数（`cells.master_replicate_id` /
`physical_cell_id` / `base_series_id` / `data_unit_id`、`scope.logical_cell_id` /
`logical_data_key` / `logical_feature_key` / `logical_evaluation_key`），并使用 formal
流 kind（`null_initial` / `null_innovation` / `null_observation_noise`，字段为
`{data_generation_id, DGP_family, master_replicate_id}`）。**三者同时不满足** §9.3／§15.2／§16；
B15b 的 10 项 Gate 未覆盖该维度，故未被拦截。

本批修复：新增 `src/owtda_cal/smoke_ids.py`（§16 全部 ID）+ smoke 流 kind/字段构造，
`smoke.py` 全量改走 smoke 命名空间；`audit/run_smoke.py` 新增
**formal ID 泄漏检查**（§16「validator 必须拒绝任何 formal logical/concrete ID 混入 smoke」），
作为 G3 证据的一项。**B15b 的 S01 smoke 证据被本批 S02 取代。**

### 2.2 smoke generation `S01` → `S02`（Plan §9.3 umbrella 规则）

§9.3：*「任一 DGP、feature、method、schema、RNG consumption、runner 或 smoke reference
environment 的代码/配置变化，都必须把 `smoke_generation_id` 从 `S01` 整体提升并重跑两类
smoke」*。本批新增 H1 DGP → 提升为 `S02` 并**重跑两 phase**（否则同一 generation 会跨两个实现）。

- ✓ `smoke_generation_id` 进入全部 `smoke_*` ID 与 `SMOKE_CONFIG` / run 身份；
- ✓ phase root key **保持不变**（generation 经流 payload 进入派生，不另铸新密钥）；
- ✓ `smoke.SMOKE_GENERATIONS_SUPERSEDED = ("S01",)` 记录被取代代次。

### 2.3 §15.2 流表新增一行：`smoke_shift_direction`

§12.2 mean shift 需要独立的 shift 方向流，§15.2 已登记 formal 行
`shift_direction`（`{data_generation_id, master_replicate_id}`），但 smoke 对应行为表外。
本批按同一规则补齐 **`smoke_shift_direction`**，字段与其它 smoke 数据流一致
`{smoke_generation_id, phase, DGP_family, replicate_id}`，**恰执行一次**
`rng.random(dtype=np.float64)`，仅由 mean-shift alternative 消费（shape 变体该字段为 null）。
属于 §15.2 合同的**增行**（未新增表外字段），在此显式披露。

三项均**不改变** `freeze_id`、五类 spec hash、`SCOPE_DESIGN_NULL/ALT` 行与 hash、
REAL 链 tip；改变的只是 smoke 规模/身份域、component 条目集合（+1 个 H1 数据组件）
与其派生的 run 身份。

## 3. H1 DGP 合同实现（§12.1/§12.2）

| 项 | 实现 |
|---|---|
| `DGP_family` | `CIRCLE_BASED_H1`（两种 alternative 同族） |
| latent | 与 N-CIRCLE 同一路径：`G` 为平稳高斯 AR(1)（`initial_index=-1000`，丢 1000 burn-in），`U_t = Φ(G_t)` |
| shape change | `t ≤ τ`：`C(u)=(cos2πu,sin2πu)`；`t > τ`：`F(u)=(sin2πu,sin4πu)` |
| mean shift | `X_t = C(U_t) + 0.5·v·1(t>τ) + 0.08η_t`，`v=(cos2πV,sin2πV)`，`V~U(0,1)` |
| 变点 | `τ = ⌊T/2⌋`（T=12288→6144；T=3120→1560），落在 k=96/97 窗口中心中点 |
| 噪声 | 两侧连续同一 `η_t`（`[12288,2]` float64 C-order），不重抽 |
| 身份 | 共享 `master_replicate_id`/`cluster_id`；`data_model_config_hash` 因 `scenario_id` 不同而不同 |
| null 回归 | 每 cell 以自身 `ρ,W,s,T,M` 调 `build_null_signature` |

流（formal，`phase=ALT`，root family `h1_data`）：`h1_initial`（shape `()`）、
`h1_innovation`（`[13288]`）、`h1_observation_noise`（`[12288,2]`）、`shift_direction`
（每次一个 `float64`），命名域均为 `{data_generation_id, master_replicate_id}`
（即明确排除 alternative/ρ/s/T/M，实现预注册的共同创新）。

## 4. 重建后的 run 身份

| phase | RUN_COMPONENT_SET | scope design | bindings |
|---|---|---|---|
| `SMOKE_NULL` | `8614dee622e1…`（完整值见 `FREEZE_MANIFEST.run_admission`） | `SCOPE_DESIGN_SMOKE_NULL_92589b2d….csv`（112 行 / 32 reps） | `d4914fdc…`（10 行） |
| `SMOKE_ALT` | `89298ac17c7c…` | `SCOPE_DESIGN_SMOKE_ALT_94e1903e….csv`（32 行 / 32 reps） | `d4914fdc…`（10 行） |
| `NULL` | `96a8b3e5b6fe…` | `SCOPE_DESIGN_NULL_bbecccb5….csv`（冻结不变） | `f15ef443…`（9 行） |

`source_tree_hash = 0cd15a9676961622e9c203f8f9fbd9c51d1d61566affe3a3c0282f2176015ee6`（45 文件，
含本批新增的 `smoke_ids.py`/`run_worker_sweep.py`/新测试）；
`smoke_config_hash = fc4c54b9023d0194b3d805500f50f21dc999a46a6633eb331d02211673800be0`；
COMPONENT_REGISTRY 新增 `SYNTHETIC_CIRCLE_BASED_H1_V1`（data，6 → 7 条）。

> **顺序纪律（重要）**：`source_tree_hash` 取自 `git ls-files src/ configs/ audit/`，
> 新增文件必须先 `git add` 再 `build_freeze`/`build_run_admission`，否则新模块不进入冻结清单；
> 且重建之后不得再改动 `src/`/`configs/`/`audit/`，否则本批 smoke 证据的 provenance 失效。

## 5. G3 smoke 实跑结果（8 workers，`smoke_generation_id=S02`）

| 项 | SMOKE_NULL 计划 | 实测 | SMOKE_ALT 计划 | 实测 |
|---|---|---|---|---|
| data units | 896 | **896** ✓ | 256 | **256** ✓ |
| evaluation rows | 3,584 | **3,584** ✓ | 1,024 | **1,024** ✓ |
| PH 窗口（唯一） | 73,600 | **73,600** ✓ | 49,152 | **49,152** ✓ |
| 未解释 error | 0 | **0** ✓ | 0 | **0** ✓ |
| 缺必需字段 | 0 | **0** ✓ | 0 | **0** ✓ |
| 禁止聚合输出 | 无 | **无** ✓ | 无 | **无** ✓ |
| formal ID 泄漏 | 0 | **0** ✓ | 0 | **0** ✓ |
| 身份闭合（cell/unit/eval） | 28/896/3,584 | **一致** ✓ | 8/256/1,024 | **一致** ✓ |
| wall time | — | **842.03 s**（`t_0,32`） | — | **272.52 s**（`t_1,32`） |

行仅作运行证据（`artifacts/smoke/<phase>/evaluation_rows_w8_r32.jsonl`），**永不进入论文**。
（H0 三次 S02 实测 808.43 / 798.99 / 842.03 s，±2.7% 抖动。）

## 6. §9.4 完整预算 Gate

| Gate | 判定 | 依据 |
|---|---|---|
| wall H0 | **PASS** | `t_H0_hat = 1.25 × (2500/32) × 842.03 s = 22.842 h ≤ 192 h` |
| wall H1 | **PASS** | `t_H1_hat = 1.25 × (1600/32) × 272.52 s = 4.731 h ≤ 76.8 h` |
| wall core | **PASS** | `t_core_hat = 27.573 h ≤ 268.8 h` |
| RAM | **PASS** | 总 peak RSS（父 + 8 workers，两 phase 取最大）= **1.393 GiB ≤ 24 GiB** |
| swap | **PASS** | 两 phase 采样 run 期间 swap 增量 = **0 bytes** |
| 磁盘 | **PASS** | `estimated_peak_disk = 386.1 MiB ≤ 0.8 × 455.6 GiB` |
| open runs | **PASS** | `open_runs = 0` |

`audit/validate_admission.py` → **23/23 PASS**（`artifacts/audit/admission_precheck_RC.json`）。

## 7. `w*` 确认：**未确认，需 amendment 决策**

见 `artifacts/audit/worker_sweep_RC.json`（两 phase × workers {1,4,8,10,12}，replicates=8）：

| workers | H0 吞吐（win/s） | H1 吞吐（win/s） | payload 与 w=8 逐位一致 |
|---|---|---|---|
| 1 | 36.2 | 79.0 | ✓ |
| 4 | 127.5 | 270.0 | ✓ |
| **8（冻结）** | 179.6 | 380.4 | ✓（基准） |
| 10 | 177.4 | 380.2（swap +3.5 MB → 不合格） | ✓ |
| **12** | **194.1** | **404.3** | ✓ |

- ✓ `worker_consistency = bitwise_identical_payload` **成立**（全部 10 组 payload 逐位一致）；
- ✓ 全部满足 peak RSS ≤ 24 GiB（最大 2.0 GiB）；
- ✗ **吞吐最高为 w=12**：相对 w=8 为 H0 **+8.1%**、H1 **+6.3%**，均超过 §9.4 的 2% 并列阈值，
  故 §9.4 规则指向 `w* = 12`，**与冻结的 `COMPUTE_SPEC.w_star = 8` 不符**
  （`frozen_w_star_confirmed = false`，`amendment_required = true`）。

**未作单方面修改**：`w_star` 是 `compute_spec_hash` → `freeze_id` → `SCOPE_DESIGN_NULL/ALT` 与
全部合成 cell/run 身份的输入，改动等价于重新冻结（tag `v1.0-freeze-owtda-cal-r1`）。
两 phase 的 wall Gate 对 w=12 只会更宽松（更快），**没有任何 Gate 结论依赖于该选择**；
这是纯身份/合同决策，见 `VALIDATION_REPORT` §5。需用户裁定（采纳 12 并走 amendment + 重新冻结，
或维持 8 并记录豁免理由）。

## 8. 本地复验

```powershell
cd f:/BPI/owtda-calibration
git apply --check ..\_incoming\OWTDA_CAL_R1_B15c_20260910_SMOKE_ALT\OWTDA_CAL_R1_B15c_20260910.patch
git apply ..\_incoming\OWTDA_CAL_R1_B15c_20260910_SMOKE_ALT\OWTDA_CAL_R1_B15c_20260910.patch
git add -A src tests audit        # 必须先纳入新文件，source_tree_hash 才覆盖 smoke_ids.py 等
python -m pytest -q                              # 471 passed（新增 56）
python -m ruff check .                           # All checks passed
python audit/build_freeze.py ; python audit/build_run_admission.py
python audit/run_smoke.py --phase both --workers 8   # ~19 min，重跑得同量级 t_0,32/t_1,32
python audit/validate_admission.py               # 23/23 PASS
python audit/run_worker_sweep.py --replicates 8  # ~72 min（w* 确认，后台建议）
python audit/validate_runs.py ; python audit/validate_freeze.py   # ALL_PASS
python audit/validate_identity.py                # commit 后 workspace_clean 才 PASS
```

## 9. 下一批预告（B15d）

1. **`w*` amendment 决策**（采纳 12 或维持 8），及其对 `freeze_id`/SCOPE_DESIGN 的重新冻结代价；
2. NULL/ALT phase 的 **expected indexes（ID-only pass）** 与 G4 admission 收尾；
3. 正式 H0/H1 run 的 runner 与 phase seal 链（`parent_phase_seal_hash` 绑定）；
4. H1 size-standardized power 分析路径（§12.3：N-CIRCLE H0 经验 0.95 分位数 + 两层 cluster bootstrap）。
