# B15c VALIDATION REPORT — OW-TDA-CAL-R1 H1 alternative DGP + G3 blind smoke（SMOKE_ALT）

> 执行环境：登记主机（Windows 11，`f:/BPI/owtda-calibration`；w=8）
> 环境：Python 3.12.10 / numpy 2.2.6 / scipy 1.15.3 / ripser 0.6.15 / pytest 9.1.1 / ruff
> 日期：2026-09-10
> 结论：**PASS（附 1 个 governance 决策点）—— H1 DGP 与 SMOKE_ALT 达标，§9.4 完整判定 23/23
> PASS；但 `w*` 扫描未确认冻结的 `w*=8`（指向 12），需 amendment 决策。**

## 1. 批次状态

| 项 | 值 |
|---|---|
| 上游 HEAD | `52ad45a`（B15b） |
| 本批改动 | 未提交（工作区含完整补丁；`validate_identity.workspace_clean` 因未提交而失败） |
| 冻结 tag | `v1.0-freeze-owtda-cal-r1` → `e16222f`（**未移动**） |
| `freeze_id` | `7cb4f85e…9322d`（**未变**） |
| 五类 spec hash | 全部未变 |
| `SCOPE_DESIGN_NULL/ALT` | 行与 hash 未变 |
| REAL 链 tip | 未变 |

## 2. 执行结果

**SMOKE_NULL（8 workers，S02）**：wall **842.03 s**、896 data units、3,584 evaluation rows、
73,600 PH 窗口、未解释 error **0**、缺字段 **0**、formal ID 泄漏 **0**、身份闭合 **28/896/3,584** ✓

**SMOKE_ALT（8 workers，S02）**：wall **272.52 s**、256 data units、1,024 evaluation rows、
49,152 PH 窗口、未解释 error **0**、缺字段 **0**、formal ID 泄漏 **0**、身份闭合 **8/256/1,024** ✓

**§9.4 完整判定**：`t_H0_hat = 22.842 h ≤ 192 h` ✓、`t_H1_hat = 4.731 h ≤ 76.8 h` ✓、
`t_core_hat = 27.573 h ≤ 268.8 h` ✓（余量 8.4× / 16.2× / 9.8×）；
总 peak RSS **1.393 GiB ≤ 24 GiB** ✓；swap 增量 **0** ✓；
`estimated_peak_disk = 386.1 MiB ≤ 0.8 × 455.6 GiB` ✓；`open_runs = 0` ✓。

**`w*` 扫描**：payload 全 worker 数逐位一致 ✓；吞吐最高 **w=12**（H0 +8.1%、H1 +6.3% vs w=8）
→ `frozen_w_star_confirmed = false`，`amendment_required = true`（见 §5）。

## 3. 质量门（实测）

| 检查 | 结果 |
|---|---|
| pytest 全量 | **471 passed / 0 failed**（新增 56：`test_h1_dgp.py` 36、`test_smoke_ids.py` 14、`test_smoke.py` +6） |
| ruff | **All checks passed** |
| `audit/validate_admission.py` | **23/23 PASS** |
| `audit/validate_runs.py` | ALL_PASS |
| `audit/validate_freeze.py` | ALL_PASS（组件条目检查改为与 `components.component_definitions()` 一致） |
| `audit/validate_identity.py` | 仅 `workspace_clean` FAIL（工作区未提交；提交后应 PASS） |

## 4. 关键验证点

- **H1 构造效度（§12.1/§12.2）**：shape 变体在 `τ` 前逐点落在单位圆、后落在 `y²=4x²(1−x²)`
  （figure-eight 恒等式，误差 < 1e-12）；mean 变体两侧差为精确常量 `0.5·v`（`|v|=1`）；
  两变体两侧边际 `E=0, Cov=½I`（带内）；
- **变点对齐**：`τ=⌊T/2⌋` 精确等于 k=96/97 窗口中心中点（s=64→6144、s=16→1560）；
- **RNG 消费合同（§15.2）**：`h1_initial` shape `()`、`h1_innovation` `[13288]`、
  `h1_observation_noise` `[12288,2]`、`shift_direction` 恰一次 `random(float64)`，
  全部 float64 C-order；`shift_direction` 仅 mean-shift 消费，shape 变体为 null；
- **共享与隔离**：alternative/ρ 不进入 base stream（同 replicate 的 innovation/noise
  hash 完全相同、latent 因 ρ 不同而不同）；两个 alternative 共享 `master_replicate_id`
  但 physical/data-unit 身份不同（`data_model_config_hash` 因 `scenario_id` 而异）；
- **null 回归（§7）**：`build_null_signature(rho,W,s,T,M)` 与 scenario/phase 无关，
  H1 cell 置零 effect 后与对应 N-CIRCLE H0 cell 的 `null_model_config_hash` 相同；
  改动 noise 律 / burn-in / rotation / generator version / 几何均使其改变（6 项参数化测试）；
- **smoke 身份隔离（§16）**：ledger 全部 ID 由 `smoke_ids.py` 生成；formal ID 泄漏检查
  （H0 180 个 / H1 66 个候选 formal ID 与 ledger 值集求交）为 0；
  `smoke_generation_id` 进入全部 smoke ID（S01≠S02）；
- **顺序纪律**：新文件先 `git add` 再重建冻结对象（`source_tree_hash` 覆盖 45 文件），
  之后不再改动 `src/`/`configs/`/`audit/`，使 smoke 证据绑定最终 `RUN_COMPONENT_SET`
  （`SMOKE_NULL=8614dee622e1…`、`SMOKE_ALT=89298ac17c7c…`）。

## 5. 决策点：`w*`（frozen 8 vs measured 12）

- §9.4 规则：取吞吐最高者，并列 2% 内取小；实测 w=12 领先 6–8%，**超出 2% 阈值**；
- `w_star` 是 `COMPUTE_SPEC` 的一部分 ⇒ `compute_spec_hash` ⇒ `freeze_id` ⇒
  `SCOPE_DESIGN_NULL/ALT` ⇒ 全部合成 cell/base/data-unit/run 身份，**改动等价于重新冻结**
  （含 tag 与 amendment 链）；
- **本批未作任何单方面修改**：仍以冻结 w=8 产出全部 smoke 与 §9.4 证据；
- 影响面：wall Gate 对 w=12 只会更宽松（更快），**无任何 Gate 结论依赖该选择**；
  该决策只影响 compute 身份与后续正式 run 的实际并行度。
- 建议：若采纳 12，则按 §16.2 走 `AMENDMENT_REGISTRY` + 重新冻结（`freeze_id` 变更、
  SCOPE_DESIGN 重生成），并在正式 run 之前完成；若维持 8，则记录豁免理由
  （例如以 32-replicate 全长重复测量为准）。

## 6. 缺陷与修复（透明披露）

| ID | 类别 | 说明 | 处置 |
|---|---|---|---|
| F-B15c-1 | B15b 遗留 · 合同违规 | smoke runner 借用 **formal** 身份函数与 formal 流 kind/字段（违反 §16/§9.3/§15.2）；ledger 缺 `experiment_id` | 本批新增 `smoke_ids.py`（§16 全部 ID）并改走 smoke 命名空间；新增 formal-ID 泄漏 validator；B15b 的 S01 证据作废 |
| F-B15c-2 | 合同新增 | §15.2 表缺 smoke 版 `shift_direction` 行 | 新增 `smoke_shift_direction`（字段同其它 smoke 数据流，仅表内字段） |
| F-B15c-3 | 治理对象漂移 | `validate_freeze.py` 硬编码组件数 6，且模块不在 `identity_core` | 改为与 `components.component_definitions()` 比对（新增组件后不再静默过期） |
| F-B15c-4 | 顺序脆弱性 | `source_tree_hash` 只覆盖 `git ls-files` 命中的文件，新模块未被 `git add` 时会遗漏 | 已在 `EXECUTION_GUIDE` 显式写出顺序纪律（先 add、后 build、再 run） |

B15b 的 10 项 Gate 未覆盖身份域维度，故 F-B15c-1 未被拦截；本批 G3 检查由 10 项扩至
每个 phase 8 项（计数 / 零错误 / 零缺字段 / 无泄漏 / 盲法 / provenance / 代次 / 身份闭合）。

## 7. 已知边界

1. `w*` 决策未闭合（§5），冻结值暂仍为 8；
2. smoke 声明的 `peak_rss` 为 2-replicate 采样的总 RSS（父 + workers）；w=12 全长实测
   H0 为 2.046 GiB、H1 为 1.971 GiB，仍在 24 GiB 内；
3. `validate_identity.workspace_clean` 在提交前必然 FAIL（本批未提交）；
4. 本批**不产生任何论文数字**；smoke 永不进入论文；H1 的 size-standardized power
   与正式 run 在 B15d 及之后。

## 8. 复审结论

- H1 两种 alternative 的 DGP、身份分层、流合同与 null 回归全部按 §12/§15/§16 实现并测试锁定；
- G3 两 phase 计数、盲法、零错误、零泄漏、身份闭合全部达标；§9.4 完整判定 23/23 PASS，
  余量充足（wall 8.4×–16.2×）；
- 修复了 B15b 的 smoke 身份域/流合同违规（F-B15c-1），并显式登记两处合同增行/变更；
- 冻结科学内容未变（`freeze_id`、五类 spec、`SCOPE_DESIGN_NULL/ALT`、REAL 链 tip、
  冻结 tag 未移动）。

**复审：PASS，准予闭合 B15c；`w*` 决策（8 vs 12）提交用户裁定后再签发 B15d。**
