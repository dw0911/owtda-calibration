# B09 VALIDATION REPORT — OW-TDA-CAL-R1 registry 雏形 + 吞吐探针（L0）

> 执行环境：登记主机（Windows 11，f:/BPI/owtda-calibration）
> 日期：2026-09-10
> 结论：**PASS —— 0 缺陷，可签发 B10/B11**

## 1. 批次状态

| 项 | 值 |
|---|---|
| 上游 HEAD | `06e5899`（B11A） |
| 本批代码 commit | `38804fb` |
| 证据 commit | `c25a7df`（G0 5/5，sha256 `245fe014…`） |
| 工作区 | clean，stash=0 |

## 2. 质量门（实测）

| 检查 | 结果 |
|---|---|
| pytest 全量 | **229 passed / 0 failed**（B09 新增 21 项） |
| ruff | **All checks passed** |
| validate_identity.py | **5/5 PASS** |
| patch（20,782 B） | SHA256 `e69ba79f…`，apply check PASS，sidecar 一致 |

## 3. 契约验证（tests 锁定）
- SEED entry：root_key_commitment 与独立重算一致、root_entry_hash = §15.1 H()、root/secret_ref 二选一、复合键重复（即使 bytes 不同）拒绝；
- stream_family×phase 白名单；**smoke 不得用 formal 域、formal 不得用 smoke 域**；
- COMPONENT entry hash = `H("component_registry_entry",…)`、同键不同 bytes 拒绝；
- SECRET entry 与 secret_kind 枚举；snapshot hash 排序去重 golden。

## 4. 预算读数（单核，探索性）
- PH+BPI/窗口：1.77 ms（circle）/1.05 ms（AR）；
- H0 PH 全量外推 ≈2.25 h；内层重采样 ≈0.27 ms/次 → 3.3e8 次 ≈25 core-hours；
- 显著低于 §9.4 上限（H0≤192 h/H1≤76.8 h）——预算风险低，但仍以 G3（w*、RAM/磁盘）实测复核为准。

## 5. 未运行项与原因
- 未写任何正式 registry 文件（B14 freeze 时以真实 root keys 登记）；
- 并行 workers 一致性/缩放属 G2/G3（B10/B13）；探针为 L0 探索性工具。

## 6. 方案方复审结论
- registry 三族与 §15.1–15.3 一致，为 freeze/admission 提供可复用校验；
- 预研表明正式计算预算充裕；主实现链（B10）可继续。

**复审：PASS，准予闭合 B09，等待签发 B10。**
