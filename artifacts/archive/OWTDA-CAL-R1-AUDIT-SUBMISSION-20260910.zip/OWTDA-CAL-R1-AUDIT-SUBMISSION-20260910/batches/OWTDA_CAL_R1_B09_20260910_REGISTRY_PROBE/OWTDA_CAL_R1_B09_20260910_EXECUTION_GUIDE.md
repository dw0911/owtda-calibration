# B09 EXECUTION GUIDE — OW-TDA-CAL-R1 registry 雏形 + 吞吐探针（L0）

> BATCH_ID：`OWTDA_CAL_R1_B09_20260910_REGISTRY_PROBE`
> 上游 commit：`06e5899`（B11A）；目标 commit：`38804fb` + 证据 `c25a7df`
> 性质：**L0 治理/预研代码** —— 0 正式 MC、0 正式 RNG 消费（探针仅用测试 root）。
> 计划依据：§15.1-§15.3（registry）、§9.4（预算）、§15.2（smoke-formal 域隔离）。

## 1. 变更清单

| 模块 | 职责 |
|---|---|
| `src/owtda_cal/registry.py` | SEED_REGISTRY/COMPONENT_REGISTRY/SECRET_COMMITMENT_REGISTRY entries 构造+校验（复合主键唯一、append-only 语义）、`registry_snapshot_hash`、stream_family×phase 白名单、smoke-formal 域隔离 |
| `src/owtda_cal/probe.py` | 吞吐探针：BPI 每窗口 PH 耗时（circle/AR）、M1 B=999 短时测、按 §9 预算外推（探索性，未含并行缩放） |
| `tests/test_registry.py` / `test_probe.py` | 21 项新测试 |

## 2. 预算读数（单核、探索性，主机 Windows 11/i5-12600KF）

| 量 | 值 |
|---|---|
| BPI+PH / 窗口（circle / N-AR） | 1.77 ms / 1.05 ms |
| H0 PH 全量单核外推 | ≈ **2.25 h** |
| H1 PH 全量单核外推 | ≈ 0.96 h |
| 内层 T_b*（M1, M=48） | ≈ 0.27 ms/次 → 3.3e8 次 ≈ **25 core-hours** |
| §9.4 预算 | H0 ≤192 h / H1 ≤76.8 h（充裕，预计非瓶颈） |

> 结论（待 G3 smoke 以 w* 实测复核）：PH 与大头内层重采样均远低于预算上限；并行缩放与 RAM/磁盘仍须 9/20–22 smoke 阶段实测。

## 3. 验证结果（本批实测）

| 项 | 值 |
|---|---|
| pytest 全量 | **229 passed / 0 failed** |
| ruff | **All checks passed** |
| G0 校验器 | **5/5 PASS**（证据 `identity_check_20260909T215843Z.json`） |
| patch | 20,782 B；SHA256 `e69ba79f1a878d04adcc39e219e64c3127a85787ac18ccf1e4953f64819164ea`；apply check PASS |

## 4. 本地复验

```powershell
cd f:/BPI/owtda-calibration
git apply --check ..\_incoming\OWTDA_CAL_R1_B09_20260910_REGISTRY_PROBE\OWTDA_CAL_R1_B09_20260910.patch
git apply ..\_incoming\OWTDA_CAL_R1_B09_20260910_REGISTRY_PROBE\OWTDA_CAL_R1_B09_20260910.patch
python -m pytest -q
```

## 5. 下一批预告
- **B10（run 编排与 seal 状态机）**：RUN_SEAL/PHASE_SEAL、append-only chains/CAS、attempts/恢复、ORPHAN 规则——是 smoke seal（9/21）与 freeze（9/23）的直接依赖；
- 或 **B11 主体（importer/task builder，REAL_DATA_TASK_GATE 9/17）**。按推进序列建议 B10。
