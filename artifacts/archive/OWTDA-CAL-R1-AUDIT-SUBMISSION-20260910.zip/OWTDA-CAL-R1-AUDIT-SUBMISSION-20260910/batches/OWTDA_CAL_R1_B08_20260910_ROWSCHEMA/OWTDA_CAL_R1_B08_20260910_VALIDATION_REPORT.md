# B08 VALIDATION REPORT — OW-TDA-CAL-R1 scientific_row 双层 schema（L0）

> 执行环境：登记主机（Windows 11，f:/BPI/owtda-calibration）
> 环境版本：Python 3.12.10 / numpy 2.2.6 / pytest 9.1.1 / ruff 0.16.6
> 日期：2026-09-10
> 结论：**PASS —— 0 缺陷，可签发 B11a/B09**

## 1. 批次状态

| 项 | 值 |
|---|---|
| 上游 HEAD | `c481a4f`（B07） |
| 本批代码 commit | `3a6c50e` |
| 证据 commit | `4054f7c`（G0 5/5，sha256 `62a7e1fa…`） |
| 工作区 | clean，stash=0 |

## 2. 质量门（实测）

| 检查 | 结果 |
|---|---|
| pytest 全量 | **208 passed / 0 failed**（B08 新增 16 项） |
| ruff | **All checks passed** |
| validate_identity.py | **5/5 PASS** |
| patch（17,666 B） | SHA256 `0be9f645…`，apply check PASS，sidecar 一致 |

## 3. 契约验证（tests 锁定）

- 三态：required value 缺失/为 None 拒；required null 缺失或非 None 拒；forbidden 出现拒；未知字段拒；
- NaN/Inf float 拒；float `f64:` hash-view 与 struct 大端独立一致；
- `row_payload_hash`：删除自身字段后独立重算一致；64 hex、稳定、内容敏感；
- wire：float 字符串格式校验（bad/非法 hex 拒）；**普通字符串 `f64:0000000000000000` 不被误解码**；
- round-trip：`0.1+0.2`、`1/3` 等 float 逐位还原；wire canonical bytes round-trip；
- schema JSON 可加载、field role 校验（float 必须是 value role、未知 role 拒）。

## 4. 冻结前说明

- 本批为通用机制 + 样例；正式全字段 schema 族待 ledger/index 批注册（§16.1 条件矩阵展开）。
- 未产生任何正式行/ledger/registry；0 MC、0 正式 RNG 消费。

## 5. 方案方复审结论
- 双层 logical/wire 机制与 §15.4/§16.1 一致，为 run/ledger 批提供可复用 row 身份基建；
- round-trip/误解码/自身-hash 排除等 Plan 攻击点（§19 #59/#74）已具备可测锚点。

**复审：PASS，准予闭合 B08，等待签发 B11a（DATA_MANIFEST 固化）或 B09（smoke/registry 雏形）。**
