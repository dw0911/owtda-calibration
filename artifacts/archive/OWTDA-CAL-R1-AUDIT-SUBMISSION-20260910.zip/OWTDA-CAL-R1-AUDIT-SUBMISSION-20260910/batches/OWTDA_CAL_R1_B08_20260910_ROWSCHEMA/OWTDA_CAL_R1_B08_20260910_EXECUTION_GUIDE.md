# B08 EXECUTION GUIDE — OW-TDA-CAL-R1 scientific_row 双层 schema（L0）

> BATCH_ID：`OWTDA_CAL_R1_B08_20260910_ROWSCHEMA`
> 上游 commit：`c481a4f`（B07）；目标 commit：`3a6c50e` + 证据 `4054f7c`
> 性质：**L0 schema 机制代码** —— 0 正式 MC、0 正式 RNG 消费。
> 计划依据：§15.4（双层 schema/float round-trip/row hash）、§16.1（required value/null/forbidden）。

## 1. 变更清单

| 文件 | 职责 |
|---|---|
| `src/owtda_cal/rowschema.py` | `RowSchema`（field roles `value/null/forbidden`、未知字段拒绝、float 路径有限性）；`logical_hash_view`/`row_payload_hash`（f64: 16hex）；`encode_to_wire`/`decode_from_wire`/`validate_wire`（`^f64:[0-9a-f]{16}$`）；`round_trip`（bit-for-bit + wire bytes） |
| `configs/schema/demo_synthetic_eval_v1.schema.json` | 样例 schema（value/null/forbidden 混合 + 3 个 float 路径），供加载/测试与后续 full schema 族扩展模板 |
| `tests/test_rowschema.py` | 16 项新测试 |

## 2. 关键契约

- **三态必填**：`value`（存在且非 None）、`null`（存在且 None——禁止静默省略或混用）、`forbidden`（不得出现）；未知字段一律拒绝；
- **float 路径定向**：只有 schema 标出的 float 字段做 `f64:` 编码/解码；普通字符串 `f64:…` 永不误解码；
- **hash**：删除仅自身 `row_payload_hash` → canonical hash-view → SHA256；`scientific_result_hash` 先插入再计算 row hash（§16 顺序）；
- **round-trip**：decode(encode(logical)) float 逐位相同；encode/decode wire 的 canonical bytes 相等。

## 3. 验证结果（本批实测）

| 项 | 值 |
|---|---|
| pytest 全量 | **208 passed / 0 failed** |
| ruff | **All checks passed** |
| G0 校验器 | **5/5 PASS**（证据 `identity_check_20260909T214825Z.json`） |
| patch | 17,666 B；SHA256 `0be9f645accbaeba08c452174be43142a96366482541d157c17f3989f6f2a09e`；apply check PASS |

## 4. 本地复验

```powershell
cd f:/BPI/owtda-calibration
git apply --check ..\_incoming\OWTDA_CAL_R1_B08_20260910_ROWSCHEMA\OWTDA_CAL_R1_B08_20260910.patch
git apply ..\_incoming\OWTDA_CAL_R1_B08_20260910_ROWSCHEMA\OWTDA_CAL_R1_B08_20260910.patch
python -m pytest -q
```

## 5. 说明与下一批
- 本批交付的是**通用 schema 机制 + 样例**；正式 `scientific_row` 全字段族（§16.1 条件矩阵展开）将在 ledger/index 实现批随实际行类型注册（demo schema 为扩展模板）。
- 下一批：**B11a（DATA_MANIFEST 固化，9/13 承诺窗口）** 或按你指示继续 B09（smoke/registry 雏形）。
