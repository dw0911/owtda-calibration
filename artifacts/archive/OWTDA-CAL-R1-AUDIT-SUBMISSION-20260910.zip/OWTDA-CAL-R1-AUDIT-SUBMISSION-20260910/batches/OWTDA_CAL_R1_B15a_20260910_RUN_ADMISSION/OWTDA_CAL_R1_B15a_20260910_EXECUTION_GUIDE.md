# B15a EXECUTION GUIDE — OW-TDA-CAL-R1 run 身份层（RUN_COMPONENT_SET / bindings / indexes / seal）

> BATCH_ID：`OWTDA_CAL_R1_B15a_20260910_RUN_ADMISSION`
> 上游 commit：`e16222f`（B14b）；目标 commit：`3cbd84a`
> 冻结 tag 未移动：`v1.0-freeze-owtda-cal-r1` → `e16222f`
> 计划依据：§16.2（RUN_COMPONENT_SET/run_instance_id）、§15.3（expected indexes）、§9.3/§9.4（smoke 规模）
> 性质：**run 身份层（L0）** —— 0 科学 MC、0 正式 RNG 消费。

> B15 已拆为 **B15a（本批，身份层）** 与 **B15b（G3 blind smoke 实际运行 + §9.4 预算判定 + G4 admission）**。

## 1. 新增对象与身份

| phase | scope design | rows / reps | bindings | RUN_COMPONENT_SET hash |
|---|---|---|---|---|
| `SMOKE_NULL` | `SCOPE_DESIGN_SMOKE_NULL_9cf9a492….csv` | 112 / 128 | 9 行 | `914bef208f55d40b70db04532d7e9a0549437d97bc0f8ec40cf69f060e2fdcc5` |
| `SMOKE_ALT` | `SCOPE_DESIGN_SMOKE_ALT_f0423c34….csv` | 32 / 128 | 9 行 | `82b8e297f7f76dc3ec759c53c22d4496e394727ac733577286bc5743ff76004e` |
| `NULL` | `SCOPE_DESIGN_NULL_bbecccb5….csv`（B14a 冻结） | 112 / 2500 | 8 行 | `0257738c79b6a3e1c1684e576e18855b0ffb71f631e88142edc4b3971b2122e3` |

- `SMOKE_CONFIG_v1.json`（新）：`config_hash = f06c92369390920c9a5d3e987de7a35990bb500d0ced1629856e242a705b275c`；
  `replicates_per_cell=128`、`smoke_evaluations={SMOKE_NULL:3584, SMOKE_ALT:1024}`（28×128 / 8×128）、
  `forbidden_outputs=[rejection_rate_summary, parameter_selection]`、`feeds_parameter_selection=false`；
- `RUN_INPUT_BINDINGS_8db97341….jsonl`（9 行）被两个 smoke phase 共用（bindings 只依赖 config + component 身份）；
- `source_tree_hash` 刷新为 `8f01a58f4660be2c09395ccfa83689dc5332cc027ed00017724e485609ebd762`。

**ALT（正式）的 component set 按设计延后**：其 `parent_phase_seal_hash` 必须是权威 H0 phase seal，
在 H0 运行前不存在；校验器显式断言 `alt_deferred_until_h0_seal`。

## 2. 冻结不变声明（重要）

本批**未改变任何被哈希的冻结科学内容**：

| 对象 | 状态 |
|---|---|
| `freeze_id` | `7cb4f85e…`（不变） |
| 五类 spec hash（protocol/scope/estimand/analysis/compute） | 全部不变 |
| `SCOPE_DESIGN_NULL/ALT` 行与 hash | 不变（`scope_design_rows` 默认分支行为保持） |
| 三类 registry（seed 13 / component 6 / secret 0） | 不变 |
| REAL_DISPOSITION 链 tip | `6a8ee23b…`（不变） |
| `FREEZE_MANIFEST.json` | 增记 `smoke_config_hash` 与 `run_admission`，并刷新 `source_tree_hash`（§16.2 允许冻结时另行绑定最终 source manifests） |

## 3. 新增代码

| 文件 | 职责 |
|---|---|
| `src/owtda_cal/runs.py` | `RUN_COMPONENT_SET`（严格字段白名单；四类 refs 按 `(role,stable_id,generation_id)` 排序、唯一、同 `(role,stable_id)` 单代）、`RUN_INPUT_BINDINGS`（JSONL 字节 + content hash）、三类 expected index（全 64-hex、主键唯一、排序、三层闭合）、`run_instance_id`、`RUN_SEAL` payload/hash、三个独立 domain 的 id-set hash |
| `src/owtda_cal/scope.py` | 新增 `SMOKE_NULL`/`SMOKE_ALT`（同格结构、128 reps、独立 phase 身份、`source_null` 指向 `SMOKE_NULL`） |
| `audit/build_run_admission.py` | 幂等生成 smoke/NULL 的 design CSV、bindings、component set 与 manifest 块 |
| `audit/validate_runs.py` | G4 前置校验（28 项）：文件字节重算、字段白名单、refs 排序、design/bindings/hash 三方一致、ALT 延后规则 |
| `tests/test_runs.py` | 27 项：ref 唯一性/多代拒绝、字段白名单（下游字段不可能进入）、bindings 字节与 hash、index 闭合与不一致拒绝、id-set 域隔离、`run_instance_id` 敏感性、seal 字段与 shard 排序 |

## 4. 验证结果（实测）

| 项 | 值 |
|---|---|
| pytest 全量 | **404 passed / 0 failed**（B15a 新增 27） |
| ruff | **All checks passed** |
| `audit/validate_runs.py` | **ALL_PASS=True（28 项）** |
| `audit/validate_freeze.py` | **ALL_PASS=True（33 项）** |
| patch（128,123 B） | SHA256 `88961f70…`，apply check PASS |

## 5. 本地复验

```powershell
cd f:/BPI/owtda-calibration
git apply --check ..\_incoming\OWTDA_CAL_R1_B15a_20260910_RUN_ADMISSION\OWTDA_CAL_R1_B15a_20260910.patch
git apply ..\_incoming\OWTDA_CAL_R1_B15a_20260910_RUN_ADMISSION\OWTDA_CAL_R1_B15a_20260910.patch
python -m pytest -q
python audit/build_freeze.py           # 幂等
python audit/build_run_admission.py    # 幂等
python audit/validate_runs.py          # 28/28 PASS
python audit/validate_freeze.py        # 33/33 PASS
```

## 6. 下一批预告（B15b：G3 blind smoke + §9.4 预算 + G4 admission）
1. `src/owtda_cal/smoke.py`：SMOKE_NULL/SMOKE_ALT runner（数据 → 窗口 → PH → 特征 → M0/M1 校准 → 行写入 shard），
   使用 `smoke` root family（`S01`），只输出 wall/字段计数/错误，**不输出拒绝率汇总**；
2. `smoke` phase seal 与 `open_runs=0` 检查；
3. §9.4 正式预算判定：由 smoke wall time 外推 `t_0,32`/`t_1,32` → `t_H0/t_H1/t_core` 上限，
   并实测总 peak RSS、swap、持久化磁盘增量（`estimated_peak_disk <= 0.8 * F_free`）；
4. `w*` 最终确认（吞吐最高 + payload 逐位一致 + RSS/swap 合规）；
5. G4 admission 前置：NULL phase 的 `RUN_INPUT_BINDINGS`/expected indexes 生成与 `open_runs=0`。
