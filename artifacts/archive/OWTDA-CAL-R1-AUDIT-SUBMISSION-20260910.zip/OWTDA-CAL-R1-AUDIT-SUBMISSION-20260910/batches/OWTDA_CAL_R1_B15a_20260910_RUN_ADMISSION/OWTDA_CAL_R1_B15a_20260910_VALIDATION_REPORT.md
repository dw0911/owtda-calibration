# B15a VALIDATION REPORT — OW-TDA-CAL-R1 run 身份层

> 执行环境：登记主机（Windows 11，`f:/BPI/owtda-calibration`）
> 环境：Python 3.12.10 / numpy 2.2.6 / scipy 1.15.3 / ripser 0.6.15 / pytest 9.1.1 / ruff
> 日期：2026-09-10
> 结论：**PASS —— 0 缺陷；run 身份层闭合，可签发 B15b（blind smoke + 预算 + admission）**

## 1. 批次状态

| 项 | 值 |
|---|---|
| 上游 HEAD | `e16222f`（B14b） |
| 本批 commit | `3cbd84a` |
| 冻结 tag | `v1.0-freeze-owtda-cal-r1` → `e16222f`（**未移动**） |
| 工作区 | clean，stash=0 |

## 2. 交付

- `src/owtda_cal/runs.py`（375 行）、`src/owtda_cal/scope.py`（smoke phase 支持）、
  `audit/build_run_admission.py`、`audit/validate_runs.py`、`tests/test_runs.py`；
- `governance/SMOKE_CONFIG_v1.json`、`SCOPE_DESIGN_SMOKE_NULL_9cf9a492….csv`、
  `SCOPE_DESIGN_SMOKE_ALT_f0423c34….csv`、
  `RUN_COMPONENT_SET_{914bef20, 82b8e297, 0257738c}.json`、`RUN_INPUT_BINDINGS_{8db97341, 36997f4a}.jsonl`；
- `FREEZE_MANIFEST.json` 增记 `smoke_config_hash` 与 `run_admission`。

## 3. 质量门（实测）

| 检查 | 结果 |
|---|---|
| pytest 全量 | **404 passed / 0 failed** |
| ruff（src/tests/audit） | **All checks passed** |
| `audit/validate_runs.py` | **ALL_PASS=True（28 项）** |
| `audit/validate_freeze.py` | **ALL_PASS=True（33 项）** |
| patch（128,123 B） | SHA256 `88961f70…`，apply check PASS，sidecar 一致 |

## 4. 关键验证点（tests 锁定）

- **字段白名单**：`RUN_COMPONENT_SET` 字段集合恰为冻结枚举；`run_seal_hash`、`phase_seal_hash`、
  `run_instance_id`、`expected_index_hash` 等下游字段**无法**进入（构造即拒绝）；
- **refs 合同**：按 `(role, stable_id, generation_id)` 排序；重复键、同 `(role, stable_id)` 多代、
  非 64-hex hash、额外字段一律拒绝；
- **bindings**：JSONL 以 LF 结尾且无 CR，content hash = SHA256(exact bytes)，行数一致；
- **expected indexes**：每字段 64-hex；主键唯一；按主键 ASCII 排序；三层闭合
  （data↔feature 的 `data_unit_id`、feature↔evaluation 的 `feature_sufficient_id`）不一致即拒绝；
- **id-set hash**：排序去重、空集合可计算、三个独立 domain 互不相等；
- **`run_instance_id`**：phase/evidence generation/四个 index hash/environment lock 任一改变即改变；
- **`RUN_SEAL`**：字段严格、shard_id 去重并排序、计数非负、自身 hash 不得预先出现、hash 稳定。

## 5. 开发中修复（透明披露）

1. `input_binding` 的 `ref_kind` 白名单漏了 `root` → 补齐（并在测试中锁定）；
2. `scope_design_rows` 扩展后，原 `test_invalid_phase` 用 `SMOKE_NULL` 当非法 phase → 改用 `"NOPE"`，
   并新增 smoke phase 与 NULL 身份互斥/128 reps 的断言；
3. bindings 排序断言初版误判 ASCII 序（`null_M1` < `null_data`）→ 修正测试期望。

## 6. 已知边界

1. 本批**未运行任何科学计算**：smoke 的 3,584/1,024 evaluations 尚未执行（B15b）；
2. 正式 `NULL` 的 expected indexes 需在 B15b 的 ID-only pass 后生成（依赖 concrete IDs）；
3. `ALT`（正式）component set 延后至 H0 phase seal 之后；
4. `source_tree_hash` 已刷新（新增 `src/runs.py` 等）；后续批次改动 `src/`/`configs/`/`audit/`
   需重跑 `build_freeze.py` 与 `build_run_admission.py`（冻结科学内容不变）。

## 7. 方案方复审结论
- run 身份层严格、可重算、无下游字段回灌；smoke 与正式 phase 身份互不混淆；
- 冻结科学内容零变化（`freeze_id`、五类 spec、三类 registry、`SCOPE_DESIGN_NULL/ALT`、REAL 链 tip 全部不变），
  冻结 tag 未移动；0 MC、0 正式 RNG 消费。

**复审：PASS，准予闭合 B15a；等待签发 B15b（G3 blind smoke + §9.4 预算判定 + G4 admission 前置）。**
