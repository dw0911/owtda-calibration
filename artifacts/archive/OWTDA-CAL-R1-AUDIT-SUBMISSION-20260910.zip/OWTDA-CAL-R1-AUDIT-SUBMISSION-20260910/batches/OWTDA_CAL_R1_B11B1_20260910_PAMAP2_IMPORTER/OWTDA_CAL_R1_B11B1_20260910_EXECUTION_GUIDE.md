# B11b1 EXECUTION GUIDE — OW-TDA-CAL-R1 PAMAP2 Protocol importer（L0/数据）

> BATCH_ID：`OWTDA_CAL_R1_B11B1_20260910_PAMAP2_IMPORTER`
> 上游 commit：`c82d5d0`（B10）；目标 commit：`041ced6` + 证据 `0f3dc56`
> 性质：**L0 数据导入实现 + 真实数据冒烟** —— 0 正式 MC、0 正式 RNG 消费。
> 计划依据：§13.2（解析/网格/插值/单位规则）。

## 1. 变更清单

| 文件 | 职责 |
|---|---|
| `src/owtda_cal/pamap2_import.py` | 54 列严格解析（有限性/字面 `NaN`/活动集/精确整数）、全局严格递增、>0.5 s 时钟分段、half-up 100 Hz 网格（tol 1e-4、严格递增 j）、grid-contiguous 分段、NaN run 1..50 四步插值、三轴 bad-row 并集、最大非空段选择、`/9.80665` 单位换算；列 25–27 禁用 |
| `tests/test_pamap2_import.py` | 22 项新测试（含失败路径与边界） |

## 2. 真实数据冒烟（`subject109.dat`，3.9 MB）

| 项 | 值 |
|---|---|
| 解析行数 / final rows | 8,477 / 8,477 |
| clock / grid / final segments | 1 / 1 / 1 |
| dropped bad rows | 0 |
| entrywise / rowwise missing | 0.006016 / 0.006016 |
| chest 均值（g） | [0.0192, 0.9091, −0.3542]（y≈0.91 g，重力方向合理） |
| grid 跨度 | 0 … 8476（连续） |

→ importer 在真实 Protocol 文件上端到端可用；其余 8 个受试者（共约 1.3 GB）将在 B11b2 全量运行并写入 `DATA_MANIFEST.timebase_diagnostics`。

## 3. 验证结果（本批实测）

| 项 | 值 |
|---|---|
| pytest 全量 | **279 passed / 0 failed** |
| ruff | **All checks passed** |
| G0 校验器 | **5/5 PASS**（证据 `identity_check_20260910T005922Z.json`） |
| patch | 17,224 B；SHA256 `79862aa0dde77c6efea34d6f82e5c1e47037ca0556b44abc05ae5df01bb53dc7`；apply check PASS |

## 4. 下一批（B11b2）预告
task builder（bout/候选/zero run/上下文 L∈{20..30} HMAC rejection mapping/sanitized 目录/opaque `task_id`）+ `REAL_DATA_TASK_GATE`（≥8 受试者、≥24 任务、每准入受试者≥1）+ 9/13 commitments（dataset_hash 已定，补 real_task_root_key / real_task_id_salt commitment）。
