# B11b1 VALIDATION REPORT — OW-TDA-CAL-R1 PAMAP2 Protocol importer

> 执行环境：登记主机（Windows 11，f:/BPI/owtda-calibration）
> 日期：2026-09-10
> 结论：**PASS —— 0 缺陷，可签发 B11b2**

## 1. 批次状态

| 项 | 值 |
|---|---|
| 上游 HEAD | `c82d5d0`（B10） |
| 本批代码 commit | `041ced6` |
| 证据 commit | `0f3dc56`（G0 5/5，sha256 `4eba5feb…`） |
| 工作区 | clean，stash=0 |

## 2. 质量门（实测）

| 检查 | 结果 |
|---|---|
| pytest 全量 | **279 passed / 0 failed**（B11b1 新增 22 项） |
| ruff | **All checks passed** |
| validate_identity.py | **5/5 PASS** |
| patch（17,224 B） | SHA256 `79862aa0…`，apply check PASS，sidecar 一致 |

## 3. 规则覆盖（tests 锁定）
- 列数≠54 拒；`Inf` 与大小写变体（`nan`）拒；字面 `NaN` 允许；活动集外/非精确整数拒；
- Δt≤0 → `DATA_IDENTITY_FAIL`；离网格 >1e-4、重复 grid index → `DATA_TIMEBASE_FAIL`；
- >0.5 s 时钟分段、缺失 grid index 分段；
- 插值四步公式 golden（r=3 → 1,2,3）；边缘无界 run 与 >50 run 判 bad；bad-row 三轴并集；
- 单位换算 `/9.80665`。

## 4. 真实数据冒烟
`subject109.dat`：8,477 行、单段、0 bad rows、missing 0.6016%、chest 均值 y≈0.9091 g、grid 0..8476 连续 —— 端到端可用（见 GUIDE §2）。

## 5. 未运行项与原因
- 九个受试者全量导入与 `DATA_MANIFEST.timebase_diagnostics` 写入留 B11b2（可与 task builder 同批跑）；
- task builder/Data Gate/commitments 属 B11b2。

## 6. 方案方复审结论
- §13.2 的解析/时基/插值/切段/单位规则逐条实现并有正反例；
- 真实文件冒烟通过，未见 data identity/timebase 阻断；
- 0 MC、0 正式 RNG 消费；未改动 dataset_hash 与既有 manifest。

**复审：PASS，准予闭合 B11b1，等待签发 B11b2（task builder + REAL_DATA_TASK_GATE）。**
