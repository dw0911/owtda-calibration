# Gate SOURCE-REVISION-ADMISSIBILITY

- **gate_id**: `SOURCE-REVISION-ADMISSIBILITY__20260910T142744Z__dc28e771`
- **status**: **BLOCKED_PENDING_OPERATOR_ACTION**
- **generated**: 2026-09-10T14:27:44Z
- **summary**: 归档内容可按 hash 逐字节验证，但审计受理所需的**不可变 revision** 尚未建立：B15c 变更处于已暂存未提交状态。

## 检查项

| check | pass | detail |
|---|---|---|
| submission_content_hash_pinned | PASS | package_manifest.json + SHA256SUMS.txt（逐对象 sha256） |
| source_tree_hash_reverified | PASS | 0cd15a9676961622e9c203f8f9fbd9c51d1d61566affe3a3c0282f2176015ee6 |
| named_batch_commit_exists | FAIL | B15c changes staged but not committed (HEAD未推进) |
| worktree_clean | FAIL | Plan §20.1 要求空工作区证明；audit_spec §4 阻断 dirty 冻结域 |

## 绑定哈希

```json
{
  "environment_lock_hash": "61f5f50a604efa379e1e67cd9b2fbe466acd6e52e73cb424a321c96f4d72b74e",
  "evidence_generation_id": "G01",
  "freeze_id": "7cb4f85e31394b23f6c9d6bcaa9ce6a7fc7b824b2b5c8fb6b600c9181979322d",
  "run_component_set_hash": {
    "NULL": "96a8b3e5b6fe1fee616b448068b50d39bf977186dabc6d69577e238412a5efe0",
    "SMOKE_ALT": "89298ac17c7ce4f149cecaeb8ee7bf376239eb7fbb535359bab21c7af8c84c6f",
    "SMOKE_NULL": "8614dee622e1bc4aebc4a9524910585c290d92f40a8bccec4e0ae82687be5462"
  },
  "smoke_config_hash": "fc4c54b9023d0194b3d805500f50f21dc999a46a6633eb331d02211673800be0",
  "smoke_generation_id": "S02",
  "source_tree_hash": "0cd15a9676961622e9c203f8f9fbd9c51d1d61566affe3a3c0282f2176015ee6"
}
```

## 证据引用

- `submission/ADMISSION_RECORD.json`
- `source/git_state.json`

## 待决断 / 未闭合

- commit 不改动文件内容 ⇒ 本包全部 sha256 与 source_tree_hash 在提交后仍然有效。
- 若还需使 RUN_COMPONENT_SET 的 compute_git_commit 指向批次 commit，则须重建 manifest 并重跑两 phase smoke（约 19 min，D-5 选项二）。

> JSON 为权威；本 Markdown 由 JSON 渲染。
