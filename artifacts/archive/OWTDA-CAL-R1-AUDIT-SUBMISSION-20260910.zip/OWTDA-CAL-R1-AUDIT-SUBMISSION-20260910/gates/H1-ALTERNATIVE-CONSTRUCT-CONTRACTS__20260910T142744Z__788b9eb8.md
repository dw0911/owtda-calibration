# Gate H1-ALTERNATIVE-CONSTRUCT-CONTRACTS

- **gate_id**: `H1-ALTERNATIVE-CONSTRUCT-CONTRACTS__20260910T142744Z__788b9eb8`
- **status**: **PASS**
- **generated**: 2026-09-10T14:27:44Z
- **summary**: H1 两 alternative 的 RNG 消费形状、变点规则、连续噪声、共享 draw、null signature 回归、身份分层由单元/契约测试锁定（**L0 证据**）。

## 检查项

| check | pass | detail |
|---|---|---|
| h1_contract_tests | PASS | tests/test_h1_dgp.py 36 项 + tests/test_smoke_ids.py 14 项 |
| h1_module_in_frozen_source_scope | PASS | src/owtda_cal/dgp.py 在 freeze source_tree_hash 内 |
| smoke_identity_domain_isolated | PASS | smoke 全部 ID 由 src/owtda_cal/smoke_ids.py 生成，formal ID 零泄漏 |

## 绑定哈希

```json
{
  "environment_lock_hash": "61f5f50a604efa379e1e67cd9b2fbe466acd6e52e73cb424a321c96f4d72b74e",
  "evidence_generation_id": "G01",
  "freeze_id": "7cb4f85e31394b23f6c9d6bcaa9ce6a7fc7b824b2b5c8fb6b600c9181979322d",
  "run_component_set_hash": {
    "NULL": "96a8b3e5b6fe1fee616b448068b50d39bf977186dabc6d69577e238412a5efe0",
    "SMOKE_ALT": "89298ac17c7ce4f149cecaeb8ee7bf376239eb7fbb535359bab21c7af8c84c6f",
    "SMOKE_NULL": "8614dee622e1bc4aebc4a9524910585c290d92f40a8bccec4e0ae82687be5462"
  },
  "smoke_config_hash": "fc4c54b9023d0194b3d805500f50f21dc999a46a6633eb331d02211673800be0",
  "smoke_generation_id": "S02",
  "source_tree_hash": "0cd15a9676961622e9c203f8f9fbd9c51d1d61566affe3a3c0282f2176015ee6"
}
```

## 证据引用

- `repo/tests/test_h1_dgp.py`
- `repo/tests/test_smoke_ids.py`
- `repo/src/owtda_cal/dgp.py`
- `repo/src/owtda_cal/smoke_ids.py`

## 待决断 / 未闭合

- H1 构造效度仅达 L0（单元/契约）；L2 功效结论需正式 H1 run（B15d 及之后）。

> JSON 为权威；本 Markdown 由 JSON 渲染。
