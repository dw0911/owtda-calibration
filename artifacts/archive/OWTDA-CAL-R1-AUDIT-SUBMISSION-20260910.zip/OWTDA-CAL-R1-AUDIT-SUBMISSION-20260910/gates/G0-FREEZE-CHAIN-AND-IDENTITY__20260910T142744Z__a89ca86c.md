# Gate G0-FREEZE-CHAIN-AND-IDENTITY

- **gate_id**: `G0-FREEZE-CHAIN-AND-IDENTITY__20260910T142744Z__a89ca86c`
- **status**: **PASS**
- **generated**: 2026-09-10T14:27:44Z
- **summary**: 冻结链、三类 registry、SCOPE_DESIGN（NULL/ALT，冻结不变）、run 身份（RUN_COMPONENT_SET/RUN_INPUT_BINDINGS）重算闭合。

## 检查项

| check | pass | detail |
|---|---|---|
| scope_spec_hash | PASS | 8b9590b8db80e0ef412ba9aa0413cfa56fb73bdc997f2414189dc84ff48362e4 |
| protocol_content_hash | PASS | 6c1acb3c4bfca8ca6e7ca01fa18d6ad1082477766f00e622ac0271c08f37f5b6 |
| estimand_registry_hash | PASS | d696f2ce5eaa693fd7fdbae764a3f1bfbbf62fb58fb9e0a26fbf7b9d9b19f30a |
| analysis_spec_hash | PASS | 1de8b74332892a6f71593f8b2be3b67b8bc094392296643b1fa84c4a395bba2f |
| compute_spec_hash | PASS | 4082572e2ca96ae86e9a2d854468743b08817970d982f5e158a6e5f135cb903b |
| freeze_id | PASS | 7cb4f85e31394b23f6c9d6bcaa9ce6a7fc7b824b2b5c8fb6b600c9181979322d |
| analysis_binds_estimand_registry | PASS | d696f2ce5eaa693fd7fdbae764a3f1bfbbf62fb58fb9e0a26fbf7b9d9b19f30a |
| scope_design[NULL].bytes | PASS | SCOPE_DESIGN_NULL_bbecccb5f651ec979dca867ed8ebc900c79fde57d75e6f1c8630680a1bc2a04b.csv |
| scope_design[NULL].rows | PASS | 112 |
| scope_design[NULL].row_hash | PASS | bbecccb5f651ec979dca867ed8ebc900c79fde57d75e6f1c8630680a1bc2a04b |
| scope_design[ALT].bytes | PASS | SCOPE_DESIGN_ALT_aebd4f34ab0a5142cb1edc6877cea4d242e5b55f615808d93c42e0d3d524b35f.csv |
| scope_design[ALT].rows | PASS | 32 |
| scope_design[ALT].row_hash | PASS | aebd4f34ab0a5142cb1edc6877cea4d242e5b55f615808d93c42e0d3d524b35f |
| frozen_documents | PASS | 8 entries |
| cycle_free | PASS | freeze_id absent from specs |
| source_tree_hash | PASS | recorded=0cd15a967696 now=0cd15a967696 |
| environment_lock_hash | PASS | 61f5f50a604efa379e1e67cd9b2fbe466acd6e52e73cb424a321c96f4d72b74e |
| seed_registry_entries | PASS | 13 |
| component_registry_entries | PASS | 7 vs 7 |
| seed_registry_sorted | PASS |  |
| component_registry_sorted | PASS |  |
| seed_registry_snapshot_hash | PASS |  |
| component_registry_snapshot_hash | PASS |  |
| secret_registry_snapshot_hash | PASS |  |
| real_root_keys_isolated | PASS |  |
| real_disposition_tip | PASS | REAL_OMITTED_BY_DATA_GATE |
| real_disposition_reason_object | PASS | 71144c331f108d0e3ff5def4fe977a0acf1887e65393ce69541b713b4c2e125f |
| real_truth_sealed | PASS |  |
| status_frozen[PROTOCOL_v1.0.md] | PASS |  |
| status_frozen[METHOD_SPEC_v1.0.md] | PASS |  |
| status_frozen[SAP_v1.0.md] | PASS |  |
| status_frozen[DATA_SPEC_v1.0.md] | PASS |  |
| run_admission_present | PASS | ['NULL', 'SMOKE_ALT', 'SMOKE_NULL'] |
| alt_deferred_until_h0_seal | PASS | formal ALT component set is not generated before the H0 phase seal |
| NULL.component_set_hash | PASS | 96a8b3e5b6fe |
| NULL.component_set_filename_hash | PASS |  |
| NULL.fields_whitelist | PASS | [] |
| NULL.refs_sorted_unique | PASS |  |
| NULL.scope_design_hash | PASS | 112 |
| NULL.bindings_hash | PASS |  |
| NULL.bindings_row_count | PASS |  |
| NULL.source_tree_hash | PASS |  |
| NULL.environment_lock_hash | PASS |  |
| NULL.registry_snapshot_hash | PASS |  |
| NULL.run_config_manifest_hash | PASS |  |
| NULL.parent_null_ok | PASS |  |
| SMOKE_ALT.component_set_hash | PASS | 89298ac17c7c |
| SMOKE_ALT.component_set_filename_hash | PASS |  |
| SMOKE_ALT.fields_whitelist | PASS | [] |
| SMOKE_ALT.refs_sorted_unique | PASS |  |
| SMOKE_ALT.scope_design_hash | PASS | 32 |
| SMOKE_ALT.bindings_hash | PASS |  |
| SMOKE_ALT.bindings_row_count | PASS |  |
| SMOKE_ALT.source_tree_hash | PASS |  |
| SMOKE_ALT.environment_lock_hash | PASS |  |
| SMOKE_ALT.registry_snapshot_hash | PASS |  |
| SMOKE_ALT.run_config_manifest_hash | PASS |  |
| SMOKE_ALT.parent_null_ok | PASS |  |
| SMOKE_NULL.component_set_hash | PASS | 8614dee622e1 |
| SMOKE_NULL.component_set_filename_hash | PASS |  |
| SMOKE_NULL.fields_whitelist | PASS | [] |
| SMOKE_NULL.refs_sorted_unique | PASS |  |
| SMOKE_NULL.scope_design_hash | PASS | 112 |
| SMOKE_NULL.bindings_hash | PASS |  |
| SMOKE_NULL.bindings_row_count | PASS |  |
| SMOKE_NULL.source_tree_hash | PASS |  |
| SMOKE_NULL.environment_lock_hash | PASS |  |
| SMOKE_NULL.registry_snapshot_hash | PASS |  |
| SMOKE_NULL.run_config_manifest_hash | PASS |  |
| SMOKE_NULL.parent_null_ok | PASS |  |
| prior_archive_sha256sums | PASS | verified 23/23; missing/bad=[] |
| archive_manifest | PASS | zip_sha256=match; objects=25; verified=True |
| charter_claim_matrix | PASS | charter_ok=True; claims_ok=True |
| plan_baseline_hash | PASS | sha256=dca49727def3d31d2f367d58dba157e782946b862c28d29dd8508a6a3cc19ab3 |

## 已声明偏离

- **OP-1**：identity_check 在工作区未提交时必然 FAIL（porcelain_empty=False）；本包以逐对象 sha256 + source_tree_hash 锚定内容，并以 SOURCE-REVISION-ADMISSIBILITY gate 显式登记该阻断。

## 绑定哈希

```json
{
  "environment_lock_hash": "61f5f50a604efa379e1e67cd9b2fbe466acd6e52e73cb424a321c96f4d72b74e",
  "evidence_generation_id": "G01",
  "freeze_id": "7cb4f85e31394b23f6c9d6bcaa9ce6a7fc7b824b2b5c8fb6b600c9181979322d",
  "run_component_set_hash": {
    "NULL": "96a8b3e5b6fe1fee616b448068b50d39bf977186dabc6d69577e238412a5efe0",
    "SMOKE_ALT": "89298ac17c7ce4f149cecaeb8ee7bf376239eb7fbb535359bab21c7af8c84c6f",
    "SMOKE_NULL": "8614dee622e1bc4aebc4a9524910585c290d92f40a8bccec4e0ae82687be5462"
  },
  "smoke_config_hash": "fc4c54b9023d0194b3d805500f50f21dc999a46a6633eb331d02211673800be0",
  "smoke_generation_id": "S02",
  "source_tree_hash": "0cd15a9676961622e9c203f8f9fbd9c51d1d61566affe3a3c0282f2176015ee6"
}
```

## 证据引用

- `repo/artifacts/audit/freeze_check_20260910T055828Z.json`
- `repo/artifacts/audit/run_admission_check_20260910T055829Z.json`
- `repo/artifacts/audit/identity_check_20260910T055702Z.json`

## 待决断 / 未闭合

- identity_check.workspace_clean 未纳入本 gate 的 pass 条件，而以 OP-1 具名偏离登记（见 deviations）。

> JSON 为权威；本 Markdown 由 JSON 渲染。
