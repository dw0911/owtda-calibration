# Gate G3-BLIND-SMOKE-BOTH-PHASES

- **gate_id**: `G3-BLIND-SMOKE-BOTH-PHASES__20260910T142744Z__17c61abc`
- **status**: **PASS**
- **generated**: 2026-09-10T14:27:44Z
- **summary**: 两 phase 盲 smoke（S02）：计数、零错误、零缺字段、formal ID 零泄漏、身份闭合、provenance 绑定、代次一致全部达标。

## 检查项

| check | pass | detail |
|---|---|---|
| g3_counts_smoke | PASS | 896/3584/73600 |
| g3_zero_unexplained_errors_smoke | PASS |  |
| g3_zero_missing_fields_smoke | PASS |  |
| g3_no_formal_id_leak_smoke | PASS | checked=180 |
| g3_blind_no_forbidden_aggregates_smoke | PASS |  |
| g3_provenance_bound_smoke | PASS | 8614dee622e1 |
| g3_smoke_generation_smoke | PASS | S02 |
| g3_identity_closure_smoke | PASS | cells=28 units=896 evaluations=3584 |
| g3_counts_smoke_alt | PASS | 256/1024/49152 |
| g3_zero_unexplained_errors_smoke_alt | PASS |  |
| g3_zero_missing_fields_smoke_alt | PASS |  |
| g3_no_formal_id_leak_smoke_alt | PASS | checked=66 |
| g3_blind_no_forbidden_aggregates_smoke_alt | PASS |  |
| g3_provenance_bound_smoke_alt | PASS | 89298ac17c7c |
| g3_smoke_generation_smoke_alt | PASS | S02 |
| g3_identity_closure_smoke_alt | PASS | cells=8 units=256 evaluations=1024 |

## 绑定哈希

```json
{
  "environment_lock_hash": "61f5f50a604efa379e1e67cd9b2fbe466acd6e52e73cb424a321c96f4d72b74e",
  "evidence_generation_id": "G01",
  "freeze_id": "7cb4f85e31394b23f6c9d6bcaa9ce6a7fc7b824b2b5c8fb6b600c9181979322d",
  "run_component_set_hash": {
    "NULL": "96a8b3e5b6fe1fee616b448068b50d39bf977186dabc6d69577e238412a5efe0",
    "SMOKE_ALT": "89298ac17c7ce4f149cecaeb8ee7bf376239eb7fbb535359bab21c7af8c84c6f",
    "SMOKE_NULL": "8614dee622e1bc4aebc4a9524910585c290d92f40a8bccec4e0ae82687be5462"
  },
  "smoke_config_hash": "fc4c54b9023d0194b3d805500f50f21dc999a46a6633eb331d02211673800be0",
  "smoke_generation_id": "S02",
  "source_tree_hash": "0cd15a9676961622e9c203f8f9fbd9c51d1d61566affe3a3c0282f2176015ee6"
}
```

## 证据引用

- `repo/artifacts/audit/smoke_RC.json`
- `repo/artifacts/audit/smoke_alt_RC.json`
- `repo/artifacts/smoke/SMOKE_NULL/evaluation_rows_w8_r32.jsonl`
- `repo/artifacts/smoke/SMOKE_ALT/evaluation_rows_w8_r32.jsonl`

> JSON 为权威；本 Markdown 由 JSON 渲染。
