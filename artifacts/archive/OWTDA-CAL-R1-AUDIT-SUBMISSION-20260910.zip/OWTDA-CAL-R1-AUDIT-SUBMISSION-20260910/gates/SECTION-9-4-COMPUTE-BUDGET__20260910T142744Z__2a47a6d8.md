# Gate SECTION-9-4-COMPUTE-BUDGET

- **gate_id**: `SECTION-9-4-COMPUTE-BUDGET__20260910T142744Z__2a47a6d8`
- **status**: **PASS**
- **generated**: 2026-09-10T14:27:44Z
- **summary**: t_H0=22.842 h ≤ 192 h、t_H1=4.731 h ≤ 76.8 h、t_core=27.573 h ≤ 268.8 h；RAM ≤ 24 GiB、swap 增量为 0、磁盘 ≤ 0.8×F_free、open_runs=0。

## 检查项

| check | pass | detail |
|---|---|---|
| wall_gate_h0 | PASS | t_H0_hat=22.842h |
| wall_gate_h1 | PASS | t_H1_hat=4.731h |
| wall_gate_core | PASS | t_core_hat=27.573h |
| memory_gate_total_rss | PASS | peak_total=1495216128 bytes |
| memory_gate_no_swap_growth | PASS | growth=0 bytes |
| disk_gate | PASS | est_peak=386.1 MiB free=455.6 GiB |
| open_runs_zero | PASS | open_runs=0 |

## 绑定哈希

```json
{
  "environment_lock_hash": "61f5f50a604efa379e1e67cd9b2fbe466acd6e52e73cb424a321c96f4d72b74e",
  "evidence_generation_id": "G01",
  "freeze_id": "7cb4f85e31394b23f6c9d6bcaa9ce6a7fc7b824b2b5c8fb6b600c9181979322d",
  "run_component_set_hash": {
    "NULL": "96a8b3e5b6fe1fee616b448068b50d39bf977186dabc6d69577e238412a5efe0",
    "SMOKE_ALT": "89298ac17c7ce4f149cecaeb8ee7bf376239eb7fbb535359bab21c7af8c84c6f",
    "SMOKE_NULL": "8614dee622e1bc4aebc4a9524910585c290d92f40a8bccec4e0ae82687be5462"
  },
  "smoke_config_hash": "fc4c54b9023d0194b3d805500f50f21dc999a46a6633eb331d02211673800be0",
  "smoke_generation_id": "S02",
  "source_tree_hash": "0cd15a9676961622e9c203f8f9fbd9c51d1d61566affe3a3c0282f2176015ee6"
}
```

## 证据引用

- `repo/artifacts/audit/admission_precheck_RC.json`

> JSON 为权威；本 Markdown 由 JSON 渲染。
