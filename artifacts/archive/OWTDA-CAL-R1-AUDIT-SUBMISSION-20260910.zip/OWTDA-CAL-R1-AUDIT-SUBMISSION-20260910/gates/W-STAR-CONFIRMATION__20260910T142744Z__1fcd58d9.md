# Gate W-STAR-CONFIRMATION

- **gate_id**: `W-STAR-CONFIRMATION__20260910T142744Z__1fcd58d9`
- **status**: **FAIL_UNCONFIRMED**
- **generated**: 2026-09-10T14:27:44Z
- **summary**: 冻结 w*=8；扫描（replicates=8）选择 [12]；payload 在所有 worker 数下逐位一致。

## 检查项

| check | pass | detail |
|---|---|---|
| SMOKE_NULL_w1_payload_identical | PASS | 1016.31 s / 36.2 win/s / rss=178540544 / swap=0 |
| SMOKE_NULL_w4_payload_identical | PASS | 288.65 s / 127.5 win/s / rss=847134720 / swap=0 |
| SMOKE_NULL_w8_payload_identical | PASS | 204.92 s / 179.6 win/s / rss=1530560512 / swap=0 |
| SMOKE_NULL_w10_payload_identical | PASS | 207.40 s / 177.4 win/s / rss=1866756096 / swap=0 |
| SMOKE_NULL_w12_payload_identical | PASS | 189.61 s / 194.1 win/s / rss=2197065728 / swap=0 |
| SMOKE_ALT_w1_payload_identical | PASS | 310.95 s / 79.0 win/s / rss=170692608 / swap=0 |
| SMOKE_ALT_w4_payload_identical | PASS | 91.01 s / 270.0 win/s / rss=820854784 / swap=0 |
| SMOKE_ALT_w8_payload_identical | PASS | 64.61 s / 380.4 win/s / rss=1471627264 / swap=0 |
| SMOKE_ALT_w10_payload_identical | PASS | 64.64 s / 380.2 win/s / rss=1794985984 / swap=3710976 |
| SMOKE_ALT_w12_payload_identical | PASS | 60.78 s / 404.3 win/s / rss=2116337664 / swap=0 |

## 绑定哈希

```json
{
  "environment_lock_hash": "61f5f50a604efa379e1e67cd9b2fbe466acd6e52e73cb424a321c96f4d72b74e",
  "evidence_generation_id": "G01",
  "freeze_id": "7cb4f85e31394b23f6c9d6bcaa9ce6a7fc7b824b2b5c8fb6b600c9181979322d",
  "frozen_w_star": 8,
  "measured_selection": [
    12
  ],
  "run_component_set_hash": {
    "NULL": "96a8b3e5b6fe1fee616b448068b50d39bf977186dabc6d69577e238412a5efe0",
    "SMOKE_ALT": "89298ac17c7ce4f149cecaeb8ee7bf376239eb7fbb535359bab21c7af8c84c6f",
    "SMOKE_NULL": "8614dee622e1bc4aebc4a9524910585c290d92f40a8bccec4e0ae82687be5462"
  },
  "smoke_config_hash": "fc4c54b9023d0194b3d805500f50f21dc999a46a6633eb331d02211673800be0",
  "smoke_generation_id": "S02",
  "source_tree_hash": "0cd15a9676961622e9c203f8f9fbd9c51d1d61566affe3a3c0282f2176015ee6"
}
```

## 证据引用

- `repo/artifacts/audit/worker_sweep_RC.json`

## 待决断 / 未闭合

- w* 决策未闭合（D-1）：measured=12 vs frozen=8（H0 +8.1%、H1 +6.3%，超 §9.4 的 2% 并列阈值）。w_star 属 COMPUTE_SPEC，改动将经 compute_spec_hash 改变 freeze_id 与全部 SCOPE_DESIGN/合成身份，等价于重新冻结。

> JSON 为权威；本 Markdown 由 JSON 渲染。
