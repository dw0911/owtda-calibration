# OWTDA-CAL-R1-AUDIT-SUBMISSION-20260910

OW-TDA-CAL-R1 已完成实验的审计提交包（自包含、逐字节可验证）。

## 锚点

- revision（运行期 HEAD）：`52ad45aa3f80d6424658c43a47f2879df5fb8841`，工作区 clean = **False**
- `freeze_id`：`7cb4f85e31394b23f6c9d6bcaa9ce6a7fc7b824b2b5c8fb6b600c9181979322d`
- `source_tree_hash`：`0cd15a9676961622e9c203f8f9fbd9c51d1d61566affe3a3c0282f2176015ee6`
- `environment_lock_hash`：`61f5f50a604efa379e1e67cd9b2fbe466acd6e52e73cb424a321c96f4d72b74e`
- `smoke_config_hash`：`fc4c54b9023d0194b3d805500f50f21dc999a46a6633eb331d02211673800be0`
- 冻结 tag：`v1.0-freeze-owtda-cal-r1` → `e16222f`（未移动）

## 目录

| 目录 | 内容 |
|---|---|
| `repo/` | 被审计工作树（git 跟踪内容，已排除 secrets/ 与既往归档） |
| `source/` | 冻结源域 manifest、复算的 `source_tree_hash`、git 状态 |
| `gates/` | Gate 对象（JSON 权威 + 渲染 Markdown） |
| `submission/` | 受理记录、审计请求、问题与待决断登记 |
| `superseded/` | 被 B15c 作废的 S01 smoke 证据与原因 |
| `batches/` | 各批次交付四件套（B01..B15c，源自 `_incoming/`） |
| `SHA256SUMS.txt` | 除自身与 `package_manifest.json` 外全部对象的 sha256 |
| `package_manifest.json` | 逐对象目录（path / source_path / role / size / sha256） |

## 验证方法

```powershell
Expand-Archive <zip> <out>
python -c "import hashlib,pathlib;root=pathlib.Path('<out>/OWTDA-CAL-R1-AUDIT-SUBMISSION-20260910');bad=[l.split('  ',1)[1] for l in (root/'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines() if l.strip() and hashlib.sha256((root/l.split('  ',1)[1]).read_bytes()).hexdigest()!=l.split('  ',1)[0]];print('mismatched',len(bad),bad[:5])"
```

## Gate 判定（gates/）

| gate | status |
|---|---|
| `G0-FREEZE-CHAIN-AND-IDENTITY` | **PASS** |
| `G3-BLIND-SMOKE-BOTH-PHASES` | **PASS** |
| `SECTION-9-4-COMPUTE-BUDGET` | **PASS** |
| `W-STAR-CONFIRMATION` | **FAIL_UNCONFIRMED** |
| `H1-ALTERNATIVE-CONSTRUCT-CONTRACTS` | **PASS** |
| `SOURCE-REVISION-ADMISSIBILITY` | **BLOCKED_PENDING_OPERATOR_ACTION** |

> Gate JSON 为权威；Markdown 由 JSON 渲染。
> 生成时间：2026-09-10T14:27:44Z（`scripts/build_audit_submission.py`）。
