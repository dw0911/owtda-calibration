# 被作废对象

F-B15c-1：B15b 的 smoke runner 借用 formal 身份函数（cells.* / scope.logical_*）与 formal 流 kind/字段（null_*、{data_generation_id, DGP_family, master_replicate_id}），违反 Plan §16（smoke 独立身份域）、§9.3（stream_kind 必须 smoke_ 前缀）与 §15.2（smoke 字段表）。按 §9.3 umbrella 规则，新增 H1 DGP 使 smoke_generation_id 由 S01 整体提升为 S02 并重跑两 phase，故 S01 运行证据全部作废（此处保留以备审计追溯）。对应修复见 B15c。
